// Dados de demonstração — um workspace realista para estudar os fluxos.
import { addDays, format } from 'date-fns'

const d = (n) => format(addDays(new Date(), n), 'yyyy-MM-dd')
const ago = (days, hours = 0) => Date.now() - days * 86400000 - hours * 3600000

const st = (id, name, color, type, order) => ({ id, name, color, type, order })

export function buildSeed() {
  const members = [
    { id: 'u1', name: 'Você', email: 'voce@tasklab.dev', color: '#6d5dfc', role: 'owner', title: 'Head de Operações', capacity: 6 },
    { id: 'u2', name: 'Marina Costa', email: 'marina@tasklab.dev', color: '#ec4899', role: 'admin', title: 'Designer', capacity: 6 },
    { id: 'u3', name: 'Rafael Lima', email: 'rafael@tasklab.dev', color: '#10b981', role: 'member', title: 'Dev Front-end', capacity: 8 },
    { id: 'u4', name: 'Júlia Souza', email: 'julia@tasklab.dev', color: '#f59e0b', role: 'member', title: 'Copywriter', capacity: 5 },
    { id: 'u5', name: 'Pedro Alves', email: 'pedro@tasklab.dev', color: '#3b82f6', role: 'guest', title: 'Freelancer', capacity: 4 },
  ]

  const mktStatuses = [
    st('s_m1', 'A FAZER', '#a1a1aa', 'notstarted', 0),
    st('s_m2', 'EM ANDAMENTO', '#3b82f6', 'active', 1),
    st('s_m3', 'EM REVISÃO', '#f59e0b', 'active', 2),
    st('s_m4', 'CONCLUÍDO', '#10b981', 'done', 3),
    st('s_m5', 'FECHADO', '#16a34a', 'closed', 4),
  ]
  const prodStatuses = [
    st('s_p1', 'BACKLOG', '#a1a1aa', 'notstarted', 0),
    st('s_p2', 'A FAZER', '#64748b', 'notstarted', 1),
    st('s_p3', 'EM PROGRESSO', '#6d5dfc', 'active', 2),
    st('s_p4', 'CODE REVIEW', '#ec4899', 'active', 3),
    st('s_p5', 'QA', '#f97316', 'active', 4),
    st('s_p6', 'CONCLUÍDO', '#10b981', 'done', 5),
    st('s_p7', 'FECHADO', '#16a34a', 'closed', 6),
  ]
  const persStatuses = [
    st('s_x1', 'PENDENTE', '#a1a1aa', 'notstarted', 0),
    st('s_x2', 'FAZENDO', '#3b82f6', 'active', 1),
    st('s_x3', 'FEITO', '#10b981', 'closed', 2),
  ]

  const spaces = [
    { id: 'sp1', name: 'Marketing', color: '#ec4899', icon: 'Megaphone', statuses: mktStatuses, private: false, members: ['u1', 'u2', 'u4', 'u5'] },
    { id: 'sp2', name: 'Produto', color: '#6d5dfc', icon: 'Rocket', statuses: prodStatuses, private: false, members: ['u1', 'u2', 'u3'] },
    { id: 'sp3', name: 'Pessoal', color: '#10b981', icon: 'User', statuses: persStatuses, private: true, members: ['u1'] },
  ]
  const folders = [
    { id: 'f1', spaceId: 'sp1', name: 'Campanhas', color: '#ec4899', statuses: null },
    { id: 'f2', spaceId: 'sp2', name: 'Sprints', color: '#6d5dfc', statuses: null },
  ]
  const lists = [
    { id: 'l1', spaceId: 'sp1', folderId: 'f1', name: 'Lançamento Q4', color: '#ec4899', statuses: null, description: 'Tudo que precisa sair para o lançamento do produto em novembro.' },
    { id: 'l2', spaceId: 'sp1', folderId: 'f1', name: 'Conteúdo Social', color: '#f97316', statuses: null, description: '' },
    { id: 'l3', spaceId: 'sp1', folderId: null, name: 'Backlog de ideias', color: '#a1a1aa', statuses: null, description: '' },
    { id: 'l4', spaceId: 'sp2', folderId: 'f2', name: 'Sprint 12', color: '#6d5dfc', statuses: null, description: '' },
    { id: 'l5', spaceId: 'sp2', folderId: 'f2', name: 'Sprint 13', color: '#3b82f6', statuses: null, description: '' },
    { id: 'l6', spaceId: 'sp2', folderId: null, name: 'Bugs', color: '#ef4444', statuses: [
      st('s_b1', 'REPORTADO', '#ef4444', 'notstarted', 0), st('s_b2', 'TRIAGEM', '#f59e0b', 'active', 1),
      st('s_b3', 'CORRIGINDO', '#6d5dfc', 'active', 2), st('s_b4', 'RESOLVIDO', '#10b981', 'done', 3), st('s_b5', 'FECHADO', '#16a34a', 'closed', 4),
    ], description: 'Bugs reportados pelo time e por clientes (via formulário).' },
    { id: 'l7', spaceId: 'sp3', folderId: null, name: 'Minhas tarefas', color: '#10b981', statuses: null, description: '' },
  ]

  const fields = [
    { id: 'cf1', name: 'Canal', type: 'dropdown', locType: 'space', locId: 'sp1', config: { options: [
      { id: 'o1', name: 'Instagram', color: '#ec4899' }, { id: 'o2', name: 'YouTube', color: '#ef4444' },
      { id: 'o3', name: 'Email', color: '#3b82f6' }, { id: 'o4', name: 'Blog', color: '#10b981' }] } },
    { id: 'cf2', name: 'Orçamento', type: 'money', locType: 'space', locId: 'sp1', config: { currency: 'BRL' } },
    { id: 'cf3', name: 'Aprovado', type: 'checkbox', locType: 'space', locId: 'sp1', config: {} },
    { id: 'cf4', name: 'Link do criativo', type: 'url', locType: 'space', locId: 'sp1', config: {} },
    { id: 'cf5', name: 'Avaliação', type: 'rating', locType: 'folder', locId: 'f1', config: { max: 5, emoji: '⭐' } },
    { id: 'cf6', name: 'Orçamento c/ imposto', type: 'formula', locType: 'space', locId: 'sp1', config: { expr: '{Orçamento} * 1.15', currency: 'BRL' } },
    { id: 'cf7', name: 'Severidade', type: 'dropdown', locType: 'list', locId: 'l6', config: { options: [
      { id: 'sv1', name: 'Crítica', color: '#ef4444' }, { id: 'sv2', name: 'Alta', color: '#f97316' },
      { id: 'sv3', name: 'Média', color: '#f59e0b' }, { id: 'sv4', name: 'Baixa', color: '#a1a1aa' }] } },
    { id: 'cf8', name: 'Componente', type: 'labels', locType: 'space', locId: 'sp2', config: { options: [
      { id: 'c1', name: 'Frontend', color: '#6d5dfc' }, { id: 'c2', name: 'API', color: '#10b981' },
      { id: 'c3', name: 'Mobile', color: '#3b82f6' }, { id: 'c4', name: 'Infra', color: '#64748b' }] } },
    { id: 'cf9', name: 'Progresso manual', type: 'progress', locType: 'list', locId: 'l1', config: {} },
    { id: 'cf10', name: 'Revisor', type: 'people', locType: 'space', locId: 'sp2', config: {} },
    { id: 'cf11', name: 'Navegador', type: 'text', locType: 'list', locId: 'l6', config: {} },
    { id: 'cf12', name: 'Email do cliente', type: 'email', locType: 'list', locId: 'l6', config: {} },
  ]

  const tags = [
    { name: 'urgente', color: '#ef4444' }, { name: 'design', color: '#ec4899' }, { name: 'copy', color: '#f59e0b' },
    { name: 'frontend', color: '#6d5dfc' }, { name: 'api', color: '#10b981' }, { name: 'hotfix', color: '#dc2626' },
    { name: 'ideia', color: '#06b6d4' }, { name: 'vídeo', color: '#f97316' },
  ]

  const taskTypes = [
    { id: 'task', name: 'Tarefa', icon: 'CircleDot', color: '#6d5dfc' },
    { id: 'milestone', name: 'Marco', icon: 'Diamond', color: '#f59e0b' },
    { id: 'bug', name: 'Bug', icon: 'Bug', color: '#ef4444' },
    { id: 'meeting', name: 'Reunião', icon: 'Users', color: '#3b82f6' },
  ]

  let num = 100
  const T = (o) => ({
    id: o.id, num: ++num, name: o.name, description: o.description || '', listId: o.listId, extraListIds: o.extraListIds || [],
    parentId: o.parentId || null, statusId: o.statusId, priority: o.priority ?? null, assignees: o.assignees || [],
    watchers: o.watchers || o.assignees || [], tags: o.tags || [], startDate: o.startDate || null, dueDate: o.dueDate || null,
    timeEstimate: o.timeEstimate || null, points: o.points ?? null, typeId: o.typeId || 'task', checklists: o.checklists || [],
    blockedBy: o.blockedBy || [], links: o.links || [], attachments: o.attachments || [], cf: o.cf || {}, recurrence: o.recurrence || null,
    timeEntries: o.timeEntries || [], order: o.order ?? num, createdAt: o.createdAt || (o.closedAt ? o.closedAt - 6 * 86400000 : ago(22 - ((num * 7) % 21), num % 12)), updatedAt: ago(num % 5),
    createdBy: o.createdBy || 'u1', closedAt: o.closedAt || null, archived: false, deletedAt: null,
  })
  const cl = (name, items) => ({ id: 'ck_' + Math.random().toString(36).slice(2, 8), name, items: items.map(([text, done, assignee]) => ({ id: 'ci_' + Math.random().toString(36).slice(2, 8), text, done: !!done, assignee: assignee || null })) })
  const te = (userId, daysAgo, minutes, note = '') => ({ id: 'te_' + Math.random().toString(36).slice(2, 8), userId, start: ago(daysAgo, 3), minutes, note, billable: true })

  const tasks = [
    // ---- Lançamento Q4
    T({ id: 't1', name: 'Definir posicionamento do lançamento', listId: 'l1', statusId: 's_m4', priority: 2, assignees: ['u1'], startDate: d(-12), dueDate: d(-8), points: 3, closedAt: ago(8), description: '<p>Documento de posicionamento com <b>proposta de valor</b>, público e diferenciais.</p>', cf: { cf1: 'o4', cf2: 1500, cf3: true, cf5: 4, cf9: 100 }, timeEntries: [te('u1', 9, 180, 'Workshop')] }),
    T({ id: 't2', name: 'Criar key visual da campanha', listId: 'l1', statusId: 's_m3', priority: 2, assignees: ['u2'], tags: ['design'], startDate: d(-6), dueDate: d(1), points: 5, timeEstimate: 600, blockedBy: ['t1'], cf: { cf1: 'o1', cf2: 4000, cf4: 'https://exemplo.com/kv', cf5: 5, cf9: 80 }, timeEntries: [te('u2', 4, 240), te('u2', 2, 150)], checklists: [cl('Entregáveis', [['Moodboard', 1], ['3 rotas criativas', 1], ['Versão final', 0, 'u2'], ['Adaptações de formato', 0]])] }),
    T({ id: 't3', name: 'Roteiro do vídeo de lançamento', listId: 'l1', statusId: 's_m2', priority: 1, assignees: ['u4'], tags: ['copy', 'vídeo'], startDate: d(-3), dueDate: d(0), points: 3, timeEstimate: 300, blockedBy: ['t1'], cf: { cf1: 'o2', cf2: 2500, cf9: 40 } }),
    T({ id: 't4', name: 'Gravar vídeo com influenciador', listId: 'l1', statusId: 's_m1', priority: 2, assignees: ['u5', 'u4'], tags: ['vídeo'], startDate: d(2), dueDate: d(6), points: 8, timeEstimate: 900, blockedBy: ['t3'], cf: { cf1: 'o2', cf2: 12000 } }),
    T({ id: 't5', name: 'Landing page do lançamento', listId: 'l1', extraListIds: ['l4'], statusId: 's_m2', priority: 1, assignees: ['u3', 'u2'], tags: ['frontend', 'design'], startDate: d(-2), dueDate: d(4), points: 8, timeEstimate: 1200, blockedBy: ['t2'], cf: { cf1: 'o4', cf2: 3000, cf9: 30 } }),
    T({ id: 't6', name: 'Sequência de emails de pré-lançamento', listId: 'l1', statusId: 's_m1', priority: 3, assignees: ['u4'], tags: ['copy'], startDate: d(3), dueDate: d(8), points: 5, cf: { cf1: 'o3', cf2: 800 } }),
    T({ id: 't7', name: 'Lançamento oficial 🚀', listId: 'l1', statusId: 's_m1', priority: 1, assignees: ['u1'], typeId: 'milestone', startDate: d(12), dueDate: d(12), blockedBy: ['t4', 't5', 't6'] }),
    T({ id: 't8', name: 'Revisar métricas da semana 1', listId: 'l1', statusId: 's_m1', priority: 4, assignees: ['u1'], dueDate: d(19), typeId: 'meeting' }),
    // subtarefas de t5
    T({ id: 't5a', name: 'Wireframe da LP', listId: 'l1', parentId: 't5', statusId: 's_m4', assignees: ['u2'], dueDate: d(-1), closedAt: ago(1) }),
    T({ id: 't5b', name: 'Implementar seções', listId: 'l1', parentId: 't5', statusId: 's_m2', assignees: ['u3'], dueDate: d(2) }),
    T({ id: 't5c', name: 'Integrar formulário de captura', listId: 'l1', parentId: 't5', statusId: 's_m1', assignees: ['u3'], dueDate: d(3) }),
    T({ id: 't5d', name: 'Teste A/B de headline', listId: 'l1', parentId: 't5', statusId: 's_m1', assignees: ['u4'], dueDate: d(4) }),
    // ---- Conteúdo social
    T({ id: 't9', name: 'Carrossel: 5 erros comuns', listId: 'l2', statusId: 's_m4', priority: 3, assignees: ['u2', 'u4'], tags: ['design', 'copy'], dueDate: d(-4), closedAt: ago(4), cf: { cf1: 'o1', cf3: true, cf5: 4 } }),
    T({ id: 't10', name: 'Reels bastidores', listId: 'l2', statusId: 's_m2', priority: 3, assignees: ['u5'], tags: ['vídeo'], dueDate: d(1), cf: { cf1: 'o1' } }),
    T({ id: 't11', name: 'Post de depoimento de cliente', listId: 'l2', statusId: 's_m1', priority: 4, assignees: ['u4'], dueDate: d(3), cf: { cf1: 'o1' } }),
    T({ id: 't12', name: 'Live de perguntas e respostas', listId: 'l2', statusId: 's_m1', priority: 2, assignees: ['u1', 'u5'], dueDate: d(9), typeId: 'meeting', cf: { cf1: 'o2' } }),
    T({ id: 't13', name: 'Newsletter semanal', listId: 'l2', statusId: 's_m1', priority: 3, assignees: ['u4'], dueDate: d(5), recurrence: { freq: 'weekly', interval: 1, mode: 'new' }, cf: { cf1: 'o3' } }),
    T({ id: 't14', name: 'Thread sobre tendências', listId: 'l2', statusId: 's_m3', priority: 4, assignees: ['u4'], dueDate: d(-1), tags: ['copy'] }),
    // ---- Backlog
    T({ id: 't15', name: 'Podcast com clientes', listId: 'l3', statusId: 's_m1', tags: ['ideia'], assignees: [] }),
    T({ id: 't16', name: 'Programa de embaixadores', listId: 'l3', statusId: 's_m1', tags: ['ideia'], priority: 4 }),
    T({ id: 't17', name: 'Calculadora interativa de ROI', listId: 'l3', statusId: 's_m1', tags: ['ideia', 'frontend'] }),
    // ---- Sprint 12
    T({ id: 't18', name: 'Autenticação com magic link', listId: 'l4', statusId: 's_p6', priority: 2, assignees: ['u3'], tags: ['api'], startDate: d(-10), dueDate: d(-5), points: 5, closedAt: ago(5), cf: { cf8: ['c2'], cf10: ['u1'] }, timeEntries: [te('u3', 7, 300), te('u3', 6, 240)] }),
    T({ id: 't19', name: 'Tela de onboarding', listId: 'l4', statusId: 's_p4', priority: 2, assignees: ['u3', 'u2'], tags: ['frontend'], startDate: d(-5), dueDate: d(1), points: 8, timeEstimate: 960, cf: { cf8: ['c1'], cf10: ['u1'] }, timeEntries: [te('u3', 3, 200), te('u2', 2, 90)], checklists: [cl('Critérios de aceite', [['Responsivo', 1], ['Acessível (AA)', 0], ['Eventos de analytics', 0, 'u3']])] }),
    T({ id: 't20', name: 'API de relatórios', listId: 'l4', statusId: 's_p3', priority: 1, assignees: ['u3'], tags: ['api'], startDate: d(-3), dueDate: d(2), points: 13, timeEstimate: 1500, cf: { cf8: ['c2', 'c4'] } }),
    T({ id: 't21', name: 'Dark mode no app', listId: 'l4', statusId: 's_p5', priority: 3, assignees: ['u2'], tags: ['frontend', 'design'], startDate: d(-4), dueDate: d(0), points: 3, cf: { cf8: ['c1', 'c3'] } }),
    T({ id: 't22', name: 'Migrar banco para nova região', listId: 'l4', statusId: 's_p2', priority: 2, assignees: ['u3'], startDate: d(3), dueDate: d(7), points: 8, blockedBy: ['t20'], cf: { cf8: ['c4'] } }),
    // ---- Sprint 13
    T({ id: 't23', name: 'Notificações push', listId: 'l5', statusId: 's_p1', priority: 3, assignees: ['u3'], startDate: d(8), dueDate: d(14), points: 8, cf: { cf8: ['c3'] } }),
    T({ id: 't24', name: 'Exportar CSV', listId: 'l5', statusId: 's_p1', priority: 4, assignees: [], startDate: d(9), dueDate: d(12), points: 3 }),
    T({ id: 't25', name: 'Busca global', listId: 'l5', statusId: 's_p2', priority: 2, assignees: ['u3', 'u2'], startDate: d(8), dueDate: d(16), points: 13 }),
    // ---- Bugs
    T({ id: 't26', name: 'Botão de salvar não responde no Safari', listId: 'l6', statusId: 's_b3', priority: 1, assignees: ['u3'], typeId: 'bug', tags: ['hotfix'], dueDate: d(0), cf: { cf7: 'sv1', cf11: 'Safari 18', cf12: 'cliente@empresa.com' } }),
    T({ id: 't27', name: 'Data errada no fuso UTC-3', listId: 'l6', statusId: 's_b2', priority: 2, assignees: ['u3'], typeId: 'bug', dueDate: d(2), cf: { cf7: 'sv2', cf11: 'Chrome' } }),
    T({ id: 't28', name: 'Ícone cortado no Android', listId: 'l6', statusId: 's_b1', priority: 3, typeId: 'bug', cf: { cf7: 'sv3', cf11: 'App Android' } }),
    T({ id: 't29', name: 'Typo na página de preços', listId: 'l6', statusId: 's_b4', priority: 4, assignees: ['u4'], typeId: 'bug', closedAt: ago(2), cf: { cf7: 'sv4' } }),
    // ---- Pessoal
    T({ id: 't30', name: 'Revisar OKRs do trimestre', listId: 'l7', statusId: 's_x2', priority: 2, assignees: ['u1'], dueDate: d(0), timeEstimate: 90 }),
    T({ id: 't31', name: '1:1 com Marina', listId: 'l7', statusId: 's_x1', priority: 3, assignees: ['u1'], dueDate: d(1), typeId: 'meeting', recurrence: { freq: 'weekly', interval: 1, mode: 'reopen' } }),
    T({ id: 't32', name: 'Ler relatório de concorrentes', listId: 'l7', statusId: 's_x1', priority: 4, assignees: ['u1'], dueDate: d(-2) }),
  ]
  const workspace = { name: 'Workspace de Estudo', prefix: 'TL', counter: num, clickApps: { priorities: true, tags: true, timeTracking: true, timeEstimates: true, points: true, multipleAssignees: true, customTaskIds: true, milestones: true, taskTypes: true } }

  const comments = [
    { id: 'c_1', taskId: 't2', userId: 'u1', text: 'Ficou muito bom! @Marina Costa consegue uma versão com fundo escuro também?', createdAt: ago(1, 4), reactions: { '👍': ['u3'] }, parentId: null, resolved: false, assignedTo: 'u2' },
    { id: 'c_2', taskId: 't2', userId: 'u2', text: 'Consigo sim, subo hoje à tarde.', createdAt: ago(1, 2), reactions: {}, parentId: 'c_1', resolved: false },
    { id: 'c_3', taskId: 't19', userId: 'u3', text: 'PR aberto, falta só o review.', createdAt: ago(0, 5), reactions: {}, parentId: null, resolved: false },
    { id: 'c_4', taskId: 't26', userId: 'u4', text: 'Cliente reportou de novo hoje cedo. @Você', createdAt: ago(0, 2), reactions: { '🔥': ['u1', 'u3'] }, parentId: null, resolved: false },
  ]

  const activity = tasks.map((t) => ({ id: 'a_' + t.id, taskId: t.id, userId: t.createdBy, text: 'criou esta tarefa', createdAt: t.createdAt }))

  const notifications = [
    { id: 'n1', userId: 'u1', taskId: 't26', actorId: 'u4', kind: 'mention', text: 'mencionou você em um comentário', createdAt: ago(0, 2), read: false, cleared: false, later: false },
    { id: 'n2', userId: 'u1', taskId: 't7', actorId: 'u2', kind: 'assign', text: 'atribuiu você a esta tarefa', createdAt: ago(1, 6), read: false, cleared: false, later: false },
    { id: 'n3', userId: 'u1', taskId: 't19', actorId: 'u3', kind: 'status', text: 'mudou o status para CODE REVIEW', createdAt: ago(0, 5), read: true, cleared: false, later: false },
    { id: 'n4', userId: 'u2', taskId: 't2', actorId: 'u1', kind: 'mention', text: 'mencionou você em um comentário', createdAt: ago(1, 4), read: false, cleared: false, later: false },
  ]

  const views = [
    { id: 'v_l1_list', locType: 'list', locId: 'l1', type: 'list', name: 'Lista', pinned: true, config: { columns: ['assignee', 'dueDate', 'priority', 'cf:cf1', 'cf:cf2', 'progress'] } },
    { id: 'v_l1_board', locType: 'list', locId: 'l1', type: 'board', name: 'Quadro', pinned: false, config: {} },
    { id: 'v_l1_gantt', locType: 'list', locId: 'l1', type: 'gantt', name: 'Gantt', pinned: false, config: {} },
    { id: 'v_l2_cal', locType: 'list', locId: 'l2', type: 'calendar', name: 'Calendário editorial', pinned: false, config: {} },
    { id: 'v_l4_table', locType: 'list', locId: 'l4', type: 'table', name: 'Tabela', pinned: false, config: { columns: ['status', 'assignee', 'dueDate', 'priority', 'points', 'timeEstimate', 'timeTracked', 'cf:cf8', 'cf:cf10'] } },
    { id: 'v_l6_form', locType: 'list', locId: 'l6', type: 'form', name: 'Reportar bug', pinned: false, config: { form: {
      title: 'Reportar um bug', description: 'Conte o que aconteceu — o time de produto recebe na lista Bugs.', submitLabel: 'Enviar bug', assignee: 'u3', statusId: 's_b1', typeId: 'bug',
      fields: [
        { key: 'name', label: 'Título do bug', required: true },
        { key: 'description', label: 'O que aconteceu?', required: true },
        { key: 'cf:cf7', label: 'Severidade', required: true },
        { key: 'cf:cf11', label: 'Navegador / dispositivo', required: false },
        { key: 'cf:cf12', label: 'Seu email', required: false, showIf: { key: 'cf:cf7', value: 'sv1' } },
        { key: 'priority', label: 'Prioridade', required: false },
      ] } } },
    { id: 'v_sp2_wl', locType: 'space', locId: 'sp2', type: 'workload', name: 'Carga de trabalho', pinned: false, config: { workloadMetric: 'points' } },
    { id: 'v_sp1_tl', locType: 'space', locId: 'sp1', type: 'timeline', name: 'Timeline', pinned: false, config: { groupBy: 'assignee' } },
  ]

  const automations = [
    { id: 'au1', name: 'Comentar ao concluir', locType: 'space', locId: 'sp1', active: true, trigger: { type: 'status_changed', params: { toStatus: 'CONCLUÍDO' } }, conditions: [], actions: [{ type: 'add_comment', params: { text: '✅ Tarefa "{{task.name}}" concluída — automação registrou a entrega.' } }, { type: 'set_cf', params: { field: 'cf3', value: true } }], runs: 0 },
    { id: 'au2', name: 'Bug crítico vai pro Rafael', locType: 'list', locId: 'l6', active: true, trigger: { type: 'task_created', params: {} }, conditions: [{ field: 'priority', op: 'is', value: '1' }], actions: [{ type: 'add_assignee', params: { user: 'u3' } }, { type: 'add_tag', params: { tag: 'hotfix' } }, { type: 'set_due_date', params: { days: 0 } }], runs: 0 },
    { id: 'au3', name: 'Subtarefas prontas → revisão', locType: 'space', locId: 'sp1', active: true, trigger: { type: 'subtasks_resolved', params: {} }, conditions: [], actions: [{ type: 'change_status', params: { status: 'EM REVISÃO' } }], runs: 0 },
    { id: 'au4', name: 'Code review → adiciona revisor como seguidor', locType: 'space', locId: 'sp2', active: true, trigger: { type: 'status_changed', params: { toStatus: 'CODE REVIEW' } }, conditions: [], actions: [{ type: 'add_watcher', params: { user: 'u1' } }, { type: 'notify', params: { user: 'u1', text: 'Tarefa pronta para code review' } }], runs: 0 },
  ]

  const docs = [
    { id: 'd1', title: 'Wiki do time', icon: '📘', parentId: null, locType: 'space', locId: 'sp1', createdBy: 'u1', updatedAt: ago(2), wiki: true,
      content: '<h1>Wiki do time de Marketing</h1><p>Bem-vindo! Aqui ficam processos, padrões e links úteis.</p><h2>Rituais</h2><ul><li>Planning toda segunda às 10h</li><li>Review de criativos quarta</li><li>Retro quinzenal</li></ul><blockquote>Regra de ouro: toda demanda nasce como tarefa.</blockquote>' },
    { id: 'd2', title: 'Onboarding', icon: '🚀', parentId: 'd1', locType: 'space', locId: 'sp1', createdBy: 'u1', updatedAt: ago(3),
      content: '<h2>Primeira semana</h2><ul class="checklist"><li class="done">Acessos às ferramentas</li><li>Ler a wiki</li><li>Shadowing com o time</li></ul>' },
    { id: 'd3', title: 'Padrão de nomenclatura', icon: '🏷️', parentId: 'd1', locType: 'space', locId: 'sp1', createdBy: 'u4', updatedAt: ago(5),
      content: '<p>Formato: <b>[CANAL] Tema — versão</b></p><pre>[IG] Carrossel erros comuns — v2</pre>' },
    { id: 'd4', title: 'RFC: Sistema de relatórios', icon: '🧩', parentId: null, locType: 'space', locId: 'sp2', createdBy: 'u3', updatedAt: ago(1),
      content: '<h1>RFC: Sistema de relatórios</h1><h3>Contexto</h3><p>Precisamos de relatórios agendados.</p><h3>Proposta</h3><ol><li>Fila de jobs</li><li>Geração em CSV/PDF</li><li>Envio por email</li></ol>' },
  ]

  const dashboards = [
    { id: 'db1', name: 'Visão geral', createdBy: 'u1', cards: [
      { id: 'k1', type: 'calc', title: 'Tarefas abertas', w: 1, config: { scope: { locType: 'everything' }, metric: 'count', onlyOpen: true } },
      { id: 'k2', type: 'calc', title: 'Atrasadas', w: 1, config: { scope: { locType: 'everything' }, metric: 'overdue' } },
      { id: 'k3', type: 'calc', title: 'Sprint points (Produto)', w: 1, config: { scope: { locType: 'space', locId: 'sp2' }, metric: 'points' } },
      { id: 'k4', type: 'status', title: 'Tarefas por status — Marketing', w: 1, config: { scope: { locType: 'space', locId: 'sp1' }, chart: 'pie' } },
      { id: 'k5', type: 'assignee', title: 'Tarefas abertas por responsável', w: 2, config: { scope: { locType: 'everything' }, chart: 'bar' } },
      { id: 'k6', type: 'burnup', title: 'Criadas x concluídas (14 dias)', w: 2, config: { scope: { locType: 'everything' } } },
      { id: 'k7', type: 'time', title: 'Tempo rastreado por pessoa', w: 1, config: { scope: { locType: 'everything' } } },
      { id: 'k8', type: 'tasklist', title: 'Atrasadas e de hoje', w: 2, config: { scope: { locType: 'everything' }, filter: 'due' } },
      { id: 'k9', type: 'goals', title: 'Metas', w: 1, config: {} },
      { id: 'k10', type: 'priority', title: 'Por prioridade', w: 1, config: { scope: { locType: 'everything' } } },
      { id: 'k11', type: 'text', title: 'Notas', w: 1, config: { text: 'Foco da semana: lançamento Q4 e zerar bugs críticos.' } },
    ] },
  ]

  const goals = [
    { id: 'g1', name: 'Lançar produto no Q4', folder: 'Metas Q4', owner: 'u1', color: '#6d5dfc', dueDate: d(30), description: 'Entregar tudo do lançamento com qualidade.', targets: [
      { id: 'gt1', name: 'Tarefas do lançamento concluídas', type: 'tasks', taskIds: ['t1', 't2', 't3', 't4', 't5', 't6', 't7'] },
      { id: 'gt2', name: 'Leads na lista de espera', type: 'number', start: 0, target: 5000, current: 1840, unit: 'leads' },
      { id: 'gt3', name: 'LP no ar', type: 'boolean', done: false },
    ] },
    { id: 'g2', name: 'Receita do trimestre', folder: 'Metas Q4', owner: 'u1', color: '#10b981', dueDate: d(80), description: '', targets: [
      { id: 'gt4', name: 'Receita nova', type: 'currency', start: 0, target: 250000, current: 97000 },
    ] },
    { id: 'g3', name: 'Zerar bugs críticos', folder: 'Qualidade', owner: 'u3', color: '#ef4444', dueDate: d(14), description: '', targets: [
      { id: 'gt5', name: 'Bugs resolvidos', type: 'tasks', taskIds: ['t26', 't27', 't28', 't29'] },
    ] },
  ]

  const templates = [
    { id: 'tpl1', kind: 'task', name: 'Checklist de publicação', createdAt: ago(20), data: {
      name: 'Publicar conteúdo', description: '<p>Use este template para qualquer peça que vai ao ar.</p>', priority: 3, tags: ['copy'],
      checklists: [{ name: 'Antes de publicar', items: ['Revisão ortográfica', 'Aprovação do líder', 'UTMs configuradas', 'Agendado no horário certo'] }],
      subtasks: ['Escrever copy', 'Criar arte', 'Agendar publicação'] } },
  ]

  const reminders = [
    { id: 'r1', userId: 'u1', text: 'Enviar status do lançamento para a diretoria', dueDate: d(0), done: false },
    { id: 'r2', userId: 'u1', text: 'Renovar licença da ferramenta de design', dueDate: d(3), done: false },
  ]

  return {
    workspace, members, spaces, folders, lists, tasks, fields, tags, taskTypes, comments, activity, notifications,
    views, automations, automationLog: [], docs, dashboards, goals, templates, reminders,
    favorites: [{ type: 'list', id: 'l1' }, { type: 'doc', id: 'd1' }],
  }
}
