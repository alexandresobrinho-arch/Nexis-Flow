// Store central (Zustand + localStorage). Toda mutação de tarefa passa por updateTask/createTask,
// que geram histórico de atividade, notificações e disparam o motor de automações.
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { addDays, addMonths, addWeeks } from 'date-fns'
import { buildSeed } from './seed'
import { uid, now, todayStr, dayStr, parseDay, clone, PRIORITIES } from '../lib/utils'
import { getTask, getStatusesForList, getList, isClosed, subtasksOf, getMember, getFieldsForList } from '../lib/selectors'
import { automationsFor } from '../lib/automations'

const STORAGE_VERSION = 3
const nameOf = (s, id) => (id === 'automation' ? 'Automação' : getMember(s, id)?.name || 'Alguém')
const isClosedStatus = (st) => st && ['done', 'closed'].includes(st.type)

function shiftByRecurrence(day, rec) {
  if (!day) return null
  const d = parseDay(day)
  const n = rec.interval || 1
  if (rec.freq === 'daily') return dayStr(addDays(d, n))
  if (rec.freq === 'weekly') return dayStr(addWeeks(d, n))
  return dayStr(addMonths(d, n))
}

const uiDefaults = { openTaskId: null, paletteOpen: false, quickCreate: null, toasts: [], modal: null }

export const useStore = create(
  persist(
    (set, get) => {
      // ---------- helpers internos ----------
      const log = (taskId, userId, text) => ({ id: uid('a'), taskId, userId, text, createdAt: now() })
      const notifs = (s, userIds, base, actor) => {
        const uniq = [...new Set(userIds)].filter((u) => u && u !== actor && getMember(s, u))
        return uniq.map((userId) => ({ id: uid('n'), userId, actorId: actor, read: false, cleared: false, later: false, createdAt: now(), ...base }))
      }
      const toast = (text) => {
        const id = uid('toast')
        set((s) => ({ toasts: [...s.toasts, { id, text }] }))
        setTimeout(() => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), 2800)
      }

      // ---------- motor de automações ----------
      const emit = (taskId, events, depth = 0) => {
        if (depth > 4 || !events.length) return
        for (const ev of events) {
          const s = get()
          const task = getTask(s, taskId)
          if (!task) return
          const autos = automationsFor(s, ev, task)
          for (const a of autos) runActions(a, taskId, depth + 1)
        }
      }

      const runActions = (auto, taskId, depth) => {
        const meta = { actor: 'automation', depth }
        const results = []
        try {
          for (const act of auto.actions) {
            const s = get()
            const t = getTask(s, taskId)
            if (!t) break
            const p = act.params || {}
            const A = get()
            switch (act.type) {
              case 'change_status': {
                const st = getStatusesForList(s, t.listId).find((x) => x.name === p.status || x.id === p.status)
                if (st) A.updateTask(taskId, { statusId: st.id }, meta)
                break
              }
              case 'change_priority': A.updateTask(taskId, { priority: p.priority ? Number(p.priority) : null }, meta); break
              case 'add_assignee': if (p.user && !t.assignees.includes(p.user)) A.updateTask(taskId, { assignees: [...t.assignees, p.user] }, meta); break
              case 'remove_assignee': A.updateTask(taskId, { assignees: t.assignees.filter((x) => x !== p.user) }, meta); break
              case 'remove_all_assignees': A.updateTask(taskId, { assignees: [] }, meta); break
              case 'assign_creator': if (!t.assignees.includes(t.createdBy)) A.updateTask(taskId, { assignees: [...t.assignees, t.createdBy] }, meta); break
              case 'add_watcher': if (p.user && !t.watchers.includes(p.user)) A.updateTask(taskId, { watchers: [...t.watchers, p.user] }, meta); break
              case 'add_tag': if (p.tag && !t.tags.includes(p.tag)) A.updateTask(taskId, { tags: [...t.tags, p.tag] }, meta); break
              case 'remove_tag': A.updateTask(taskId, { tags: t.tags.filter((x) => x !== p.tag) }, meta); break
              case 'set_due_date': A.updateTask(taskId, { dueDate: dayStr(addDays(new Date(), Number(p.days) || 0)) }, meta); break
              case 'set_start_date': A.updateTask(taskId, { startDate: dayStr(addDays(new Date(), Number(p.days) || 0)) }, meta); break
              case 'clear_due_date': A.updateTask(taskId, { dueDate: null }, meta); break
              case 'set_cf': if (p.field) A.updateTask(taskId, { cf: { ...t.cf, [p.field]: p.value } }, meta); break
              case 'add_comment': A.addComment(taskId, (p.text || '').replace(/\{\{task\.name\}\}/g, t.name).replace(/\{\{task\.status\}\}/g, getStatusesForList(s, t.listId).find((x) => x.id === t.statusId)?.name || ''), null, meta); break
              case 'create_subtask': A.createTask({ name: (p.name || 'Subtarefa').replace(/\{\{task\.name\}\}/g, t.name), listId: t.listId, parentId: t.id }, meta); break
              case 'create_task': if (p.list) A.createTask({ name: (p.name || 'Nova tarefa').replace(/\{\{task\.name\}\}/g, t.name), listId: p.list }, meta); break
              case 'move_to_list': if (p.list && p.list !== t.listId) A.moveTask(taskId, p.list, meta); break
              case 'add_to_list': if (p.list && p.list !== t.listId && !t.extraListIds.includes(p.list)) A.updateTask(taskId, { extraListIds: [...t.extraListIds, p.list] }, meta); break
              case 'duplicate': A.duplicateTask(taskId, meta); break
              case 'apply_template': if (p.template) A.applyTemplateToTask(p.template, taskId, meta); break
              case 'set_type': if (p.typeId) A.updateTask(taskId, { typeId: p.typeId }, meta); break
              case 'notify': set((st) => ({ notifications: [...notifs(st, [p.user], { taskId, kind: 'automation', text: p.text || `Automação "${auto.name}"` }, 'automation'), ...st.notifications] })); break
              case 'archive': A.updateTask(taskId, { archived: true }, meta); break
              default: break
            }
            results.push(act.type)
          }
          set((s) => ({
            automations: s.automations.map((a) => (a.id === auto.id ? { ...a, runs: (a.runs || 0) + 1, lastRun: now() } : a)),
            automationLog: [{ id: uid('al'), automationId: auto.id, taskId, at: now(), ok: true, message: results.join(', ') }, ...s.automationLog].slice(0, 300),
          }))
        } catch (e) {
          set((s) => ({ automationLog: [{ id: uid('al'), automationId: auto.id, taskId, at: now(), ok: false, message: String(e.message || e) }, ...s.automationLog].slice(0, 300) }))
        }
      }

      return {
        ...buildSeed(),
        ...uiDefaults,
        currentUserId: 'u1',
        theme: 'light',
        sidebarCollapsed: false,
        expanded: { sp1: true, f1: true, sp2: true },
        route: { page: 'home' },
        timer: null,

        // ---------- navegação / UI ----------
        navigate: (route) => set({ route }),
        openTask: (id) => set({ openTaskId: id }),
        closeTask: () => set({ openTaskId: null }),
        setPalette: (v) => set({ paletteOpen: v }),
        setQuickCreate: (v) => set({ quickCreate: v }),
        setModal: (modal) => set({ modal }),
        toast,
        toggleExpanded: (id) => set((s) => ({ expanded: { ...s.expanded, [id]: !s.expanded[id] } })),
        setTheme: (theme) => set({ theme }),
        toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
        setCurrentUser: (id) => set({ currentUserId: id }),
        toggleFavorite: (type, id) => set((s) => {
          const has = s.favorites.some((f) => f.type === type && f.id === id)
          return { favorites: has ? s.favorites.filter((f) => !(f.type === type && f.id === id)) : [...s.favorites, { type, id }] }
        }),
        toggleClickApp: (key) => set((s) => ({ workspace: { ...s.workspace, clickApps: { ...s.workspace.clickApps, [key]: !s.workspace.clickApps[key] } } })),
        updateWorkspace: (patch) => set((s) => ({ workspace: { ...s.workspace, ...patch } })),

        // ---------- tarefas ----------
        createTask: (data, meta = {}) => {
          const s = get()
          const actor = meta.actor || s.currentUserId
          const listId = data.listId
          const sts = getStatusesForList(s, listId)
          const id = uid('t')
          const num = s.workspace.counter + 1
          const siblings = s.tasks.filter((t) => t.listId === listId && t.parentId === (data.parentId || null))
          const task = {
            id, num, name: data.name?.trim() || 'Tarefa sem nome', description: data.description || '', listId, extraListIds: data.extraListIds || [],
            parentId: data.parentId || null, statusId: data.statusId && sts.some((x) => x.id === data.statusId) ? data.statusId : sts[0]?.id,
            priority: data.priority ?? null, assignees: data.assignees || [], watchers: [...new Set([actor, ...(data.assignees || [])])].filter((x) => x !== 'automation'),
            tags: data.tags || [], startDate: data.startDate || null, dueDate: data.dueDate || null, timeEstimate: data.timeEstimate || null,
            points: data.points ?? null, typeId: data.typeId || 'task', checklists: data.checklists || [], blockedBy: data.blockedBy || [], links: [],
            attachments: [], cf: data.cf || {}, recurrence: data.recurrence || null, timeEntries: [], order: siblings.reduce((m, t) => Math.max(m, t.order || 0), 0) + 1,
            createdAt: now(), updatedAt: now(), createdBy: actor, closedAt: null, archived: false, deletedAt: null,
          }
          set((st) => ({
            tasks: [...st.tasks, task],
            workspace: { ...st.workspace, counter: num },
            activity: [...st.activity, log(id, actor, data.parentId ? 'criou esta subtarefa' : 'criou esta tarefa')],
            notifications: [...notifs(st, task.assignees, { taskId: id, kind: 'assign', text: 'atribuiu você a esta tarefa' }, actor), ...st.notifications],
            tags: ensureTags(st.tags, task.tags),
          }))
          emit(id, [{ type: 'task_created' }], meta.depth || 0)
          return id
        },

        updateTask: (id, patch, meta = {}) => {
          const s = get()
          const old = getTask(s, id)
          if (!old) return
          const actor = meta.actor || s.currentUserId
          const next = { ...old, ...patch, updatedAt: now() }
          const acts = []
          const events = []
          let newNotifs = []
          const watchers = new Set(next.watchers)
          const who = nameOf(s, actor)
          const sts = getStatusesForList(s, next.listId)
          let justClosed = false

          if ('name' in patch && patch.name !== old.name) acts.push(`renomeou de "${old.name}" para "${patch.name}"`)
          if ('description' in patch && patch.description !== old.description) acts.push('atualizou a descrição')
          if ('statusId' in patch && patch.statusId !== old.statusId) {
            const from = sts.find((x) => x.id === old.statusId)
            const to = sts.find((x) => x.id === patch.statusId)
            if (isClosedStatus(to) && !isClosedStatus(from)) { next.closedAt = now(); justClosed = true }
            if (!isClosedStatus(to)) next.closedAt = null
            acts.push(`mudou o status de ${from?.name || '—'} para ${to?.name || '—'}`)
            events.push({ type: 'status_changed', fromName: from?.name, toName: to?.name })
            newNotifs.push(...notifs(s, [...watchers, ...next.assignees], { taskId: id, kind: 'status', text: `mudou o status para ${to?.name}` }, actor))
          }
          if ('priority' in patch && patch.priority !== old.priority) {
            acts.push(`definiu a prioridade como ${patch.priority ? PRIORITIES[patch.priority].label : 'nenhuma'}`)
            events.push({ type: 'priority_changed', to: patch.priority })
          }
          if ('assignees' in patch) {
            const added = patch.assignees.filter((x) => !old.assignees.includes(x))
            const removed = old.assignees.filter((x) => !patch.assignees.includes(x))
            added.forEach((u) => { acts.push(`atribuiu a ${nameOf(s, u)}`); events.push({ type: 'assignee_added', user: u }); watchers.add(u) })
            removed.forEach((u) => { acts.push(`removeu ${nameOf(s, u)}`); events.push({ type: 'assignee_removed', user: u }) })
            newNotifs.push(...notifs(s, added, { taskId: id, kind: 'assign', text: 'atribuiu você a esta tarefa' }, actor))
          }
          if ('tags' in patch) {
            patch.tags.filter((x) => !old.tags.includes(x)).forEach((tag) => { acts.push(`adicionou a tag ${tag}`); events.push({ type: 'tag_added', tag }) })
            old.tags.filter((x) => !patch.tags.includes(x)).forEach((tag) => { acts.push(`removeu a tag ${tag}`); events.push({ type: 'tag_removed', tag }) })
          }
          if ('dueDate' in patch && patch.dueDate !== old.dueDate) { acts.push(patch.dueDate ? `mudou a entrega para ${patch.dueDate.split('-').reverse().join('/')}` : 'removeu a data de entrega'); events.push({ type: 'due_date_changed' }); next._dueFired = null }
          if ('startDate' in patch && patch.startDate !== old.startDate) { acts.push(patch.startDate ? `mudou o início para ${patch.startDate.split('-').reverse().join('/')}` : 'removeu a data de início'); events.push({ type: 'start_date_changed' }); next._startFired = null }
          if ('timeEstimate' in patch && patch.timeEstimate !== old.timeEstimate) acts.push('alterou a estimativa de tempo')
          if ('points' in patch && patch.points !== old.points) acts.push(`definiu sprint points: ${patch.points ?? '—'}`)
          if ('typeId' in patch && patch.typeId !== old.typeId) { acts.push(`mudou o tipo para ${s.taskTypes.find((x) => x.id === patch.typeId)?.name}`); events.push({ type: 'type_changed', to: patch.typeId }) }
          if ('archived' in patch && patch.archived !== old.archived) acts.push(patch.archived ? 'arquivou a tarefa' : 'desarquivou a tarefa')
          if ('cf' in patch) {
            Object.keys({ ...old.cf, ...patch.cf }).forEach((k) => {
              if (JSON.stringify(old.cf?.[k]) !== JSON.stringify(patch.cf?.[k])) {
                const f = s.fields.find((x) => x.id === k)
                acts.push(`alterou o campo ${f?.name || k}`)
                events.push({ type: 'cf_changed', fieldId: k })
              }
            })
          }
          if ('blockedBy' in patch) {
            patch.blockedBy.filter((x) => !old.blockedBy.includes(x)).forEach((b) => acts.push(`adicionou dependência: aguardando "${getTask(s, b)?.name}"`))
          }
          if ('extraListIds' in patch) patch.extraListIds.filter((x) => !old.extraListIds.includes(x)).forEach((l) => acts.push(`adicionou também à lista ${getList(s, l)?.name}`))
          if ('listId' in patch && patch.listId !== old.listId) {
            const newSts = getStatusesForList(s, patch.listId)
            const oldSt = getStatusesForList(s, old.listId).find((x) => x.id === old.statusId)
            const match = newSts.find((x) => x.name === oldSt?.name) || newSts.find((x) => x.type === oldSt?.type) || newSts[0]
            next.statusId = match?.id
            next.extraListIds = next.extraListIds.filter((x) => x !== patch.listId)
            acts.push(`moveu de ${getList(s, old.listId)?.name} para ${getList(s, patch.listId)?.name}`)
            events.push({ type: 'task_moved' })
          }
          next.watchers = [...watchers].filter((x) => x !== 'automation')
          set((st) => ({
            tasks: st.tasks.map((t) => (t.id === id ? next : 'listId' in patch && t.parentId === id ? { ...t, listId: patch.listId, statusId: getStatusesForList(st, patch.listId).find((x) => x.name === getStatusesForList(st, t.listId).find((y) => y.id === t.statusId)?.name)?.id || getStatusesForList(st, patch.listId)[0]?.id } : t)),
            activity: [...st.activity, ...acts.map((a) => log(id, actor, a))],
            notifications: [...newNotifs, ...st.notifications],
            tags: 'tags' in patch ? ensureTags(st.tags, patch.tags) : st.tags,
          }))
          if (meta.silent) return
          // efeitos colaterais de fechar
          if (justClosed) {
            const s2 = get()
            if (next.recurrence) get().handleRecurrence(id)
            if (next.parentId) {
              const sibs = subtasksOf(s2, next.parentId)
              if (sibs.length && sibs.every((x) => isClosed(s2, x))) emit(next.parentId, [{ type: 'subtasks_resolved' }], meta.depth || 0)
            }
            s2.tasks.filter((x) => (x.blockedBy || []).includes(id)).forEach((x) => {
              if (x.blockedBy.every((b) => { const bt = getTask(s2, b); return !bt || isClosed(s2, bt) })) {
                set((st) => ({ notifications: [...notifs(st, x.assignees, { taskId: x.id, kind: 'unblocked', text: 'desbloqueou esta tarefa (dependência concluída)' }, actor), ...st.notifications] }))
                emit(x.id, [{ type: 'task_unblocked' }], meta.depth || 0)
              }
            })
          }
          emit(id, events, meta.depth || 0)
          void who
        },

        handleRecurrence: (id) => {
          const s = get()
          const t = getTask(s, id)
          if (!t?.recurrence) return
          const sts = getStatusesForList(s, t.listId)
          const first = sts.find((x) => x.type === 'notstarted') || sts[0]
          const dueDate = shiftByRecurrence(t.dueDate || todayStr(), t.recurrence)
          const startDate = t.startDate ? shiftByRecurrence(t.startDate, t.recurrence) : null
          const checklists = t.checklists.map((c) => ({ ...c, items: c.items.map((i) => ({ ...i, done: false })) }))
          if (t.recurrence.mode === 'reopen') {
            set((st) => ({
              tasks: st.tasks.map((x) => (x.id === id ? { ...x, statusId: first.id, dueDate, startDate, checklists, closedAt: null } : x)),
              activity: [...st.activity, log(id, 'automation', `recorrência: reabriu a tarefa com entrega em ${dueDate.split('-').reverse().join('/')}`)],
            }))
          } else {
            const nid = get().createTask({ ...clone(t), name: t.name, dueDate, startDate, checklists, statusId: first.id, cf: t.cf }, { actor: 'automation' })
            set((st) => ({
              tasks: st.tasks.map((x) => (x.id === id ? { ...x, recurrence: null } : x)),
              activity: [...st.activity, log(nid, 'automation', 'criada pela recorrência')],
            }))
          }
          toast('Tarefa recorrente: próxima ocorrência agendada')
        },

        moveTask: (id, listId, meta) => get().updateTask(id, { listId }, meta),

        reorderTask: (id, order) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, order } : t)) })),

        duplicateTask: (id, meta = {}) => {
          const s = get()
          const t = getTask(s, id)
          if (!t) return
          const copyOne = (src, parentId, root) => get().createTask({ ...clone(src), name: root ? `${src.name} (cópia)` : src.name, parentId, checklists: src.checklists.map((c) => ({ ...c, id: uid('ck'), items: c.items.map((i) => ({ ...i, id: uid('ci') })) })) }, meta)
          const nid = copyOne(t, t.parentId, true)
          subtasksOf(s, id).forEach((sub) => copyOne(sub, nid, false))
          toast('Tarefa duplicada')
          return nid
        },

        deleteTask: (id) => {
          const ids = new Set([id])
          get().tasks.forEach((t) => { if (ids.has(t.parentId)) ids.add(t.id) })
          set((s) => ({ tasks: s.tasks.map((t) => (ids.has(t.id) ? { ...t, deletedAt: now() } : t)), openTaskId: s.openTaskId && ids.has(s.openTaskId) ? null : s.openTaskId }))
          toast('Tarefa movida para a lixeira')
        },
        restoreTask: (id) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === id || (t.parentId === id && t.deletedAt) ? { ...t, deletedAt: null } : t)) })),
        purgeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id && t.parentId !== id).map((t) => ({ ...t, blockedBy: t.blockedBy.filter((b) => b !== id), links: t.links.filter((b) => b !== id) })) })),
        emptyTrash: () => set((s) => {
          const gone = new Set(s.tasks.filter((t) => t.deletedAt).map((t) => t.id))
          return { tasks: s.tasks.filter((t) => !gone.has(t.id)).map((t) => ({ ...t, blockedBy: t.blockedBy.filter((b) => !gone.has(b)) })) }
        }),

        bulkUpdate: (ids, patchFn) => ids.forEach((id) => { const t = getTask(get(), id); if (t) get().updateTask(id, typeof patchFn === 'function' ? patchFn(t) : patchFn) }),

        // dependências e relacionamentos
        addDependency: (taskId, blockerId) => {
          const t = getTask(get(), taskId)
          if (!t || taskId === blockerId || t.blockedBy.includes(blockerId)) return
          const b = getTask(get(), blockerId)
          if (b?.blockedBy.includes(taskId)) { toast('Dependência circular não permitida'); return }
          get().updateTask(taskId, { blockedBy: [...t.blockedBy, blockerId] })
        },
        removeDependency: (taskId, blockerId) => {
          const t = getTask(get(), taskId)
          if (t) get().updateTask(taskId, { blockedBy: t.blockedBy.filter((x) => x !== blockerId) })
        },
        toggleLink: (a, b) => set((s) => ({
          tasks: s.tasks.map((t) => {
            if (t.id === a) return { ...t, links: t.links.includes(b) ? t.links.filter((x) => x !== b) : [...t.links, b] }
            if (t.id === b) return { ...t, links: t.links.includes(a) ? t.links.filter((x) => x !== a) : [...t.links, a] }
            return t
          }),
        })),

        // checklists
        addChecklist: (taskId, name = 'Checklist') => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: [...t.checklists, { id: uid('ck'), name, items: [] }] } : t)) })),
        updateChecklist: (taskId, ckId, patch) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.map((c) => (c.id === ckId ? { ...c, ...patch } : c)) } : t)) })),
        deleteChecklist: (taskId, ckId) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.filter((c) => c.id !== ckId) } : t)) })),
        addChecklistItem: (taskId, ckId, text) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.map((c) => (c.id === ckId ? { ...c, items: [...c.items, { id: uid('ci'), text, done: false, assignee: null }] } : c)) } : t)) })),
        updateChecklistItem: (taskId, ckId, itemId, patch) => {
          set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.map((c) => (c.id === ckId ? { ...c, items: c.items.map((i) => (i.id === itemId ? { ...i, ...patch } : i)) } : c)) } : t)) }))
          if ('done' in patch && patch.done) {
            const t = getTask(get(), taskId)
            const items = t.checklists.flatMap((c) => c.items)
            if (items.length && items.every((i) => i.done)) emit(taskId, [{ type: 'checklists_resolved' }])
          }
          if ('assignee' in patch && patch.assignee) set((s) => ({ notifications: [...notifs(s, [patch.assignee], { taskId, kind: 'assign', text: 'atribuiu um item de checklist a você' }, s.currentUserId), ...s.notifications] }))
        },
        deleteChecklistItem: (taskId, ckId, itemId) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.map((c) => (c.id === ckId ? { ...c, items: c.items.filter((i) => i.id !== itemId) } : c)) } : t)) })),
        moveChecklistItem: (taskId, ckId, from, to) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, checklists: t.checklists.map((c) => { if (c.id !== ckId) return c; const items = [...c.items]; const [x] = items.splice(from, 1); items.splice(to, 0, x); return { ...c, items } }) } : t)) })),

        // anexos
        addAttachment: (taskId, att) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, attachments: [...t.attachments, { id: uid('at'), createdAt: now(), ...att }] } : t)), activity: [...s.activity, log(taskId, s.currentUserId, `anexou ${att.name}`)] })),
        removeAttachment: (taskId, attId) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, attachments: t.attachments.filter((a) => a.id !== attId) } : t)) })),

        // ---------- comentários ----------
        addComment: (taskId, text, parentId = null, meta = {}) => {
          const s = get()
          const actor = meta.actor || s.currentUserId
          const t = getTask(s, taskId)
          if (!t || !text.trim()) return
          const mentioned = s.members.filter((m) => text.includes('@' + m.name)).map((m) => m.id)
          const c = { id: uid('c'), taskId, userId: actor, text, createdAt: now(), reactions: {}, parentId, resolved: false, assignedTo: meta.assignedTo || null }
          set((st) => ({
            comments: [...st.comments, c],
            tasks: st.tasks.map((x) => (x.id === taskId && actor !== 'automation' ? { ...x, watchers: [...new Set([...x.watchers, actor])] } : x)),
            notifications: [
              ...notifs(st, mentioned, { taskId, kind: 'mention', text: 'mencionou você em um comentário' }, actor),
              ...notifs(st, t.watchers.filter((w) => !mentioned.includes(w)), { taskId, kind: 'comment', text: `comentou: "${text.slice(0, 60)}${text.length > 60 ? '…' : ''}"` }, actor),
              ...(meta.assignedTo ? notifs(st, [meta.assignedTo], { taskId, kind: 'assign', text: 'atribuiu um comentário a você' }, actor) : []),
              ...st.notifications,
            ],
          }))
          if (actor !== 'automation') emit(taskId, [{ type: 'comment_added' }], meta.depth || 0)
        },
        updateComment: (id, patch) => set((s) => ({ comments: s.comments.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
        deleteComment: (id) => set((s) => ({ comments: s.comments.filter((c) => c.id !== id && c.parentId !== id) })),
        toggleReaction: (id, emoji) => set((s) => ({
          comments: s.comments.map((c) => {
            if (c.id !== id) return c
            const users = c.reactions[emoji] || []
            const nu = users.includes(s.currentUserId) ? users.filter((u) => u !== s.currentUserId) : [...users, s.currentUserId]
            const reactions = { ...c.reactions, [emoji]: nu }
            if (!nu.length) delete reactions[emoji]
            return { ...c, reactions }
          }),
        })),

        // ---------- time tracking ----------
        startTimer: (taskId) => {
          if (get().timer) get().stopTimer()
          set((s) => ({ timer: { taskId, userId: s.currentUserId, start: now() } }))
        },
        stopTimer: (note = '') => {
          const tm = get().timer
          if (!tm) return
          const minutes = Math.max(1, Math.round((now() - tm.start) / 60000))
          get().addTimeEntry(tm.taskId, { userId: tm.userId, start: tm.start, minutes, note })
          set({ timer: null })
        },
        addTimeEntry: (taskId, entry) => set((s) => ({
          tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, timeEntries: [...t.timeEntries, { id: uid('te'), billable: true, note: '', ...entry }] } : t)),
          activity: [...s.activity, log(taskId, entry.userId || s.currentUserId, `registrou ${entry.minutes} min de tempo`)],
        })),
        updateTimeEntry: (taskId, entryId, patch) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, timeEntries: t.timeEntries.map((e) => (e.id === entryId ? { ...e, ...patch } : e)) } : t)) })),
        deleteTimeEntry: (taskId, entryId) => set((s) => ({ tasks: s.tasks.map((t) => (t.id === taskId ? { ...t, timeEntries: t.timeEntries.filter((e) => e.id !== entryId) } : t)) })),

        // ---------- datas: gatilhos "data chega" ----------
        checkDateTriggers: () => {
          const s = get()
          const today = todayStr()
          const due = s.tasks.filter((t) => !t.deletedAt && !t.archived && t.dueDate && t.dueDate <= today && t._dueFired !== t.dueDate && !isClosed(s, t))
          const start = s.tasks.filter((t) => !t.deletedAt && !t.archived && t.startDate && t.startDate <= today && t._startFired !== t.startDate && !isClosed(s, t))
          if (!due.length && !start.length) return
          set((st) => ({
            tasks: st.tasks.map((t) => {
              let x = t
              if (due.some((d) => d.id === t.id)) x = { ...x, _dueFired: t.dueDate }
              if (start.some((d) => d.id === t.id)) x = { ...x, _startFired: t.startDate }
              return x
            }),
          }))
          due.forEach((t) => emit(t.id, [{ type: 'due_date_arrives' }]))
          start.forEach((t) => emit(t.id, [{ type: 'start_date_arrives' }]))
        },

        // ---------- hierarquia ----------
        addSpace: (data) => {
          const id = uid('sp')
          const statuses = data.statuses || [
            { id: uid('s'), name: 'A FAZER', color: '#a1a1aa', type: 'notstarted', order: 0 },
            { id: uid('s'), name: 'EM ANDAMENTO', color: '#3b82f6', type: 'active', order: 1 },
            { id: uid('s'), name: 'CONCLUÍDO', color: '#10b981', type: 'closed', order: 2 },
          ]
          set((s) => ({ spaces: [...s.spaces, { id, name: data.name, color: data.color || '#6d5dfc', icon: data.icon || 'Layers', statuses, private: !!data.private, members: [s.currentUserId] }], expanded: { ...s.expanded, [id]: true } }))
          return id
        },
        updateSpace: (id, patch) => set((s) => ({ spaces: s.spaces.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
        deleteSpace: (id) => set((s) => {
          const lists = s.lists.filter((l) => l.spaceId === id).map((l) => l.id)
          const folders = s.folders.filter((f) => f.spaceId === id).map((f) => f.id)
          const locs = new Set([id, ...lists, ...folders])
          return {
            spaces: s.spaces.filter((x) => x.id !== id), folders: s.folders.filter((f) => f.spaceId !== id), lists: s.lists.filter((l) => l.spaceId !== id),
            tasks: s.tasks.map((t) => (lists.includes(t.listId) ? { ...t, deletedAt: now() } : t)),
            views: s.views.filter((v) => !locs.has(v.locId)), fields: s.fields.filter((f) => !locs.has(f.locId)), automations: s.automations.filter((a) => !locs.has(a.locId)),
            route: locs.has(s.route.locId) ? { page: 'home' } : s.route,
          }
        }),
        addFolder: (spaceId, name) => { const id = uid('f'); set((s) => ({ folders: [...s.folders, { id, spaceId, name, color: null, statuses: null }], expanded: { ...s.expanded, [id]: true, [spaceId]: true } })); return id },
        updateFolder: (id, patch) => set((s) => ({ folders: s.folders.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
        deleteFolder: (id) => set((s) => {
          const lists = s.lists.filter((l) => l.folderId === id).map((l) => l.id)
          const locs = new Set([id, ...lists])
          return {
            folders: s.folders.filter((f) => f.id !== id), lists: s.lists.filter((l) => l.folderId !== id),
            tasks: s.tasks.map((t) => (lists.includes(t.listId) ? { ...t, deletedAt: now() } : t)),
            views: s.views.filter((v) => !locs.has(v.locId)), fields: s.fields.filter((f) => !locs.has(f.locId)),
            route: locs.has(s.route.locId) ? { page: 'home' } : s.route,
          }
        }),
        addList: (spaceId, folderId, name, extra = {}) => {
          const id = uid('l')
          set((s) => ({ lists: [...s.lists, { id, spaceId, folderId: folderId || null, name, color: extra.color || '#a1a1aa', statuses: extra.statuses || null, description: extra.description || '' }], expanded: { ...s.expanded, [spaceId]: true, ...(folderId ? { [folderId]: true } : {}) } }))
          return id
        },
        updateList: (id, patch) => set((s) => ({ lists: s.lists.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
        deleteList: (id) => set((s) => ({
          lists: s.lists.filter((l) => l.id !== id), tasks: s.tasks.map((t) => (t.listId === id ? { ...t, deletedAt: now() } : { ...t, extraListIds: t.extraListIds.filter((x) => x !== id) })),
          views: s.views.filter((v) => v.locId !== id), fields: s.fields.filter((f) => f.locId !== id), route: s.route.locId === id ? { page: 'home' } : s.route,
        })),
        duplicateList: (id) => {
          const s = get()
          const l = getList(s, id)
          const nid = get().addList(l.spaceId, l.folderId, `${l.name} (cópia)`, { color: l.color, statuses: l.statuses ? l.statuses.map((x) => ({ ...x })) : null, description: l.description })
          const map = {}
          const tops = s.tasks.filter((t) => t.listId === id && !t.parentId && !t.deletedAt)
          tops.forEach((t) => {
            const n = get().createTask({ ...clone(t), listId: nid, blockedBy: [] })
            map[t.id] = n
            subtasksOf(s, t.id).forEach((sub) => get().createTask({ ...clone(sub), listId: nid, parentId: n, blockedBy: [] }))
          })
          toast('Lista duplicada')
          return nid
        },
        setStatuses: (locType, locId, statuses) => {
          const key = { space: 'spaces', folder: 'folders', list: 'lists' }[locType]
          set((s) => ({ [key]: s[key].map((x) => (x.id === locId ? { ...x, statuses } : x)) }))
          // remapeia tarefas cujo status sumiu
          const s = get()
          s.tasks.forEach((t) => {
            const sts = getStatusesForList(s, t.listId)
            if (!sts.some((x) => x.id === t.statusId)) set((st) => ({ tasks: st.tasks.map((x) => (x.id === t.id ? { ...x, statusId: sts[0]?.id } : x)) }))
          })
        },

        // ---------- custom fields ----------
        addField: (field) => { const id = uid('cf'); set((s) => ({ fields: [...s.fields, { id, config: {}, ...field }] })); return id },
        updateField: (id, patch) => set((s) => ({ fields: s.fields.map((f) => (f.id === id ? { ...f, ...patch } : f)) })),
        deleteField: (id) => set((s) => ({
          fields: s.fields.filter((f) => f.id !== id),
          tasks: s.tasks.map((t) => { if (!(id in (t.cf || {}))) return t; const cf = { ...t.cf }; delete cf[id]; return { ...t, cf } }),
          views: s.views.map((v) => ({ ...v, config: { ...v.config, columns: (v.config.columns || []).filter((c) => c !== `cf:${id}`) } })),
        })),
        setFieldValue: (taskId, fieldId, value) => { const t = getTask(get(), taskId); if (t) get().updateTask(taskId, { cf: { ...t.cf, [fieldId]: value } }) },

        // ---------- views ----------
        ensureDefaultViews: (locType, locId) => {
          const s = get()
          if (s.views.some((v) => v.locType === locType && v.locId === locId)) return
          const base = [{ id: uid('v'), locType, locId, type: 'list', name: 'Lista', pinned: true, config: {} }]
          if (locType !== 'everything') base.push({ id: uid('v'), locType, locId, type: 'board', name: 'Quadro', pinned: false, config: {} })
          set((st) => ({ views: [...st.views, ...base] }))
        },
        addView: (locType, locId, type, name, config = {}) => {
          const id = uid('v')
          set((s) => ({ views: [...s.views, { id, locType, locId, type, name, pinned: false, config }] }))
          return id
        },
        updateView: (id, patch) => set((s) => ({ views: s.views.map((v) => (v.id === id ? { ...v, ...patch } : v)) })),
        updateViewConfig: (id, patch) => set((s) => ({ views: s.views.map((v) => (v.id === id ? { ...v, config: { ...v.config, ...patch } } : v)) })),
        deleteView: (id) => set((s) => ({ views: s.views.filter((v) => v.id !== id) })),
        duplicateView: (id) => {
          const v = get().views.find((x) => x.id === id)
          const nid = uid('v')
          set((s) => ({ views: [...s.views, { ...clone(v), id: nid, name: `${v.name} (cópia)`, pinned: false }] }))
          return nid
        },

        // ---------- automações ----------
        addAutomation: (a) => { const id = uid('au'); set((s) => ({ automations: [...s.automations, { id, active: true, runs: 0, conditions: [], actions: [], ...a }] })); return id },
        updateAutomation: (id, patch) => set((s) => ({ automations: s.automations.map((a) => (a.id === id ? { ...a, ...patch } : a)) })),
        deleteAutomation: (id) => set((s) => ({ automations: s.automations.filter((a) => a.id !== id) })),

        // ---------- notificações ----------
        markNotif: (id, patch) => set((s) => ({ notifications: s.notifications.map((n) => (n.id === id ? { ...n, ...patch } : n)) })),
        markAllRead: () => set((s) => ({ notifications: s.notifications.map((n) => (n.userId === s.currentUserId ? { ...n, read: true } : n)) })),
        clearAllNotifs: () => set((s) => ({ notifications: s.notifications.map((n) => (n.userId === s.currentUserId && !n.later ? { ...n, cleared: true, read: true } : n)) })),

        // ---------- docs ----------
        addDoc: (data = {}) => {
          const id = uid('d')
          set((s) => ({ docs: [...s.docs, { id, title: data.title || 'Documento sem título', icon: data.icon || '📄', parentId: data.parentId || null, locType: data.locType || 'everything', locId: data.locId || null, content: data.content || '', createdBy: s.currentUserId, updatedAt: now(), wiki: false }] }))
          return id
        },
        updateDoc: (id, patch) => set((s) => ({ docs: s.docs.map((d) => (d.id === id ? { ...d, ...patch, updatedAt: now() } : d)) })),
        deleteDoc: (id) => set((s) => {
          const ids = new Set([id])
          let grew = true
          while (grew) { grew = false; s.docs.forEach((d) => { if (ids.has(d.parentId) && !ids.has(d.id)) { ids.add(d.id); grew = true } }) }
          return { docs: s.docs.filter((d) => !ids.has(d.id)), route: ids.has(s.route.docId) ? { page: 'docs' } : s.route }
        }),

        // ---------- dashboards ----------
        addDashboard: (name) => { const id = uid('db'); set((s) => ({ dashboards: [...s.dashboards, { id, name, createdBy: s.currentUserId, cards: [] }] })); return id },
        updateDashboard: (id, patch) => set((s) => ({ dashboards: s.dashboards.map((d) => (d.id === id ? { ...d, ...patch } : d)) })),
        deleteDashboard: (id) => set((s) => ({ dashboards: s.dashboards.filter((d) => d.id !== id), route: { page: 'dashboards' } })),
        addCard: (dashId, card) => set((s) => ({ dashboards: s.dashboards.map((d) => (d.id === dashId ? { ...d, cards: [...d.cards, { id: uid('k'), w: 1, config: {}, ...card }] } : d)) })),
        updateCard: (dashId, cardId, patch) => set((s) => ({ dashboards: s.dashboards.map((d) => (d.id === dashId ? { ...d, cards: d.cards.map((c) => (c.id === cardId ? { ...c, ...patch } : c)) } : d)) })),
        removeCard: (dashId, cardId) => set((s) => ({ dashboards: s.dashboards.map((d) => (d.id === dashId ? { ...d, cards: d.cards.filter((c) => c.id !== cardId) } : d)) })),
        setCards: (dashId, cards) => set((s) => ({ dashboards: s.dashboards.map((d) => (d.id === dashId ? { ...d, cards } : d)) })),

        // ---------- goals ----------
        addGoal: (g) => { const id = uid('g'); set((s) => ({ goals: [...s.goals, { id, owner: s.currentUserId, color: '#6d5dfc', targets: [], description: '', folder: 'Geral', ...g }] })); return id },
        updateGoal: (id, patch) => set((s) => ({ goals: s.goals.map((g) => (g.id === id ? { ...g, ...patch } : g)) })),
        deleteGoal: (id) => set((s) => ({ goals: s.goals.filter((g) => g.id !== id) })),
        addTarget: (goalId, t) => set((s) => ({ goals: s.goals.map((g) => (g.id === goalId ? { ...g, targets: [...g.targets, { id: uid('gt'), ...t }] } : g)) })),
        updateTarget: (goalId, tid, patch) => set((s) => ({ goals: s.goals.map((g) => (g.id === goalId ? { ...g, targets: g.targets.map((t) => (t.id === tid ? { ...t, ...patch } : t)) } : g)) })),
        deleteTarget: (goalId, tid) => set((s) => ({ goals: s.goals.map((g) => (g.id === goalId ? { ...g, targets: g.targets.filter((t) => t.id !== tid) } : g)) })),

        // ---------- templates ----------
        saveTaskTemplate: (taskId, name) => {
          const s = get()
          const t = getTask(s, taskId)
          const data = {
            name: t.name, description: t.description, priority: t.priority, tags: t.tags, timeEstimate: t.timeEstimate, points: t.points, typeId: t.typeId, cf: t.cf,
            checklists: t.checklists.map((c) => ({ name: c.name, items: c.items.map((i) => i.text) })),
            subtasks: subtasksOf(s, taskId).map((x) => x.name),
          }
          set((st) => ({ templates: [...st.templates, { id: uid('tpl'), kind: 'task', name: name || t.name, createdAt: now(), data }] }))
          toast('Template salvo')
        },
        saveListTemplate: (listId, name) => {
          const s = get()
          const l = getList(s, listId)
          const tops = s.tasks.filter((t) => t.listId === listId && !t.parentId && !t.deletedAt)
          const data = {
            name: l.name, description: l.description, color: l.color, statuses: getStatusesForList(s, listId).map((x) => ({ ...x })),
            fields: getFieldsForList(s, listId).filter((f) => f.locType === 'list').map((f) => ({ name: f.name, type: f.type, config: f.config })),
            tasks: tops.map((t) => ({ name: t.name, description: t.description, priority: t.priority, tags: t.tags, checklists: t.checklists.map((c) => ({ name: c.name, items: c.items.map((i) => i.text) })), subtasks: subtasksOf(s, t.id).map((x) => x.name) })),
          }
          set((st) => ({ templates: [...st.templates, { id: uid('tpl'), kind: 'list', name: name || l.name, createdAt: now(), data }] }))
          toast('Template de lista salvo')
        },
        deleteTemplate: (id) => set((s) => ({ templates: s.templates.filter((t) => t.id !== id) })),
        createTaskFromTemplate: (tplId, listId, parentId = null) => {
          const tpl = get().templates.find((t) => t.id === tplId)
          if (!tpl) return
          const d = tpl.data
          const id = get().createTask({
            name: d.name, description: d.description, priority: d.priority, tags: d.tags || [], timeEstimate: d.timeEstimate, points: d.points, typeId: d.typeId, cf: d.cf || {}, listId, parentId,
            checklists: (d.checklists || []).map((c) => ({ id: uid('ck'), name: c.name, items: c.items.map((text) => ({ id: uid('ci'), text, done: false, assignee: null })) })),
          })
          ;(d.subtasks || []).forEach((name) => get().createTask({ name, listId, parentId: id }))
          return id
        },
        applyTemplateToTask: (tplId, taskId, meta = {}) => {
          const tpl = get().templates.find((t) => t.id === tplId)
          const t = getTask(get(), taskId)
          if (!tpl || !t) return
          const d = tpl.data
          set((s) => ({
            tasks: s.tasks.map((x) => (x.id === taskId ? {
              ...x, description: x.description || d.description, tags: [...new Set([...x.tags, ...(d.tags || [])])],
              checklists: [...x.checklists, ...(d.checklists || []).map((c) => ({ id: uid('ck'), name: c.name, items: c.items.map((text) => ({ id: uid('ci'), text, done: false, assignee: null })) }))],
            } : x)),
          }))
          ;(d.subtasks || []).forEach((name) => get().createTask({ name, listId: t.listId, parentId: taskId }, meta))
        },
        createListFromTemplate: (tplId, spaceId, folderId, name) => {
          const tpl = get().templates.find((t) => t.id === tplId)
          const d = tpl.data
          const statuses = d.statuses.map((x) => ({ ...x, id: uid('s') }))
          const lid = get().addList(spaceId, folderId, name || d.name, { color: d.color, description: d.description, statuses })
          ;(d.fields || []).forEach((f) => get().addField({ ...f, locType: 'list', locId: lid }))
          ;(d.tasks || []).forEach((t) => {
            const id = get().createTask({ name: t.name, description: t.description, priority: t.priority, tags: t.tags, listId: lid, checklists: t.checklists.map((c) => ({ id: uid('ck'), name: c.name, items: c.items.map((text) => ({ id: uid('ci'), text, done: false, assignee: null })) })) })
            t.subtasks.forEach((n) => get().createTask({ name: n, listId: lid, parentId: id }))
          })
          return lid
        },

        // ---------- lembretes ----------
        addReminder: (text, dueDate) => set((s) => ({ reminders: [...s.reminders, { id: uid('r'), userId: s.currentUserId, text, dueDate, done: false }] })),
        updateReminder: (id, patch) => set((s) => ({ reminders: s.reminders.map((r) => (r.id === id ? { ...r, ...patch } : r)) })),
        deleteReminder: (id) => set((s) => ({ reminders: s.reminders.filter((r) => r.id !== id) })),

        // ---------- membros / tags / tipos ----------
        addMember: (m) => { const id = uid('u'); set((s) => ({ members: [...s.members, { id, role: 'member', capacity: 8, title: '', ...m }] })); return id },
        updateMember: (id, patch) => set((s) => ({ members: s.members.map((m) => (m.id === id ? { ...m, ...patch } : m)) })),
        removeMember: (id) => set((s) => ({
          members: s.members.filter((m) => m.id !== id),
          tasks: s.tasks.map((t) => ({ ...t, assignees: t.assignees.filter((x) => x !== id), watchers: t.watchers.filter((x) => x !== id) })),
          currentUserId: s.currentUserId === id ? s.members[0].id : s.currentUserId,
        })),
        updateTag: (name, patch) => set((s) => ({
          tags: s.tags.map((t) => (t.name === name ? { ...t, ...patch } : t)),
          tasks: patch.name && patch.name !== name ? s.tasks.map((t) => ({ ...t, tags: t.tags.map((x) => (x === name ? patch.name : x)) })) : s.tasks,
        })),
        deleteTag: (name) => set((s) => ({ tags: s.tags.filter((t) => t.name !== name), tasks: s.tasks.map((t) => ({ ...t, tags: t.tags.filter((x) => x !== name) })) })),
        addTaskType: (tt) => set((s) => ({ taskTypes: [...s.taskTypes, { id: uid('tt'), icon: 'CircleDot', color: '#64748b', ...tt }] })),
        updateTaskType: (id, patch) => set((s) => ({ taskTypes: s.taskTypes.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
        deleteTaskType: (id) => set((s) => ({ taskTypes: s.taskTypes.filter((t) => t.id !== id), tasks: s.tasks.map((t) => (t.typeId === id ? { ...t, typeId: 'task' } : t)) })),

        // ---------- dados ----------
        exportData: () => {
          const s = get()
          const keys = ['workspace', 'members', 'spaces', 'folders', 'lists', 'tasks', 'fields', 'tags', 'taskTypes', 'comments', 'activity', 'notifications', 'views', 'automations', 'automationLog', 'docs', 'dashboards', 'goals', 'templates', 'reminders', 'favorites']
          return JSON.stringify(Object.fromEntries(keys.map((k) => [k, s[k]])), null, 2)
        },
        importData: (json) => {
          const data = JSON.parse(json)
          if (!data.tasks || !data.spaces) throw new Error('Arquivo inválido')
          set({ ...data, ...uiDefaults, route: { page: 'home' }, timer: null })
        },
        resetDemo: () => set({ ...buildSeed(), ...uiDefaults, route: { page: 'home' }, timer: null, currentUserId: 'u1' }),
        clearAll: () => set((s) => ({
          spaces: [], folders: [], lists: [], tasks: [], fields: [], comments: [], activity: [], notifications: [], views: [], automations: [], automationLog: [],
          docs: [], dashboards: [], goals: [], templates: [], reminders: [], favorites: [], route: { page: 'home' }, timer: null, ...uiDefaults, workspace: { ...s.workspace, counter: 0 },
        })),
      }
    },
    {
      name: 'tasklab-store',
      version: STORAGE_VERSION,
      migrate: () => ({}), // versão antiga => volta para o seed
      partialize: (s) => Object.fromEntries(Object.entries(s).filter(([k, v]) => typeof v !== 'function' && !(k in uiDefaults))),
    },
  ),
)

function ensureTags(tags, names) {
  const missing = (names || []).filter((n) => !tags.some((t) => t.name === n))
  if (!missing.length) return tags
  const colors = ['#6d5dfc', '#06b6d4', '#84cc16', '#f97316', '#a855f7', '#64748b']
  return [...tags, ...missing.map((name, i) => ({ name, color: colors[(tags.length + i) % colors.length] }))]
}

// atalho para ler o estado fora de componentes
export const S = () => useStore.getState()
