import React, { useState } from 'react'
import { ChevronLeft, ChevronRight, Plus, Download, Clock } from 'lucide-react'
import { addDays, addWeeks, startOfWeek, format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { Avatar, Popover, StatusDot, Tabs, Empty } from '../components/ui'
import { TaskPickerMenu } from '../components/TaskDetail'
import { taskStatus, taskPath, getTask, getMember } from '../lib/selectors'
import { dayStr, fmtMinutes, parseDuration, download, cx, todayStr, fmtDateTime } from '../lib/utils'

export default function TimesheetsPage() {
  const s = useStore()
  const [cursor, setCursor] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }))
  const [user, setUser] = useState(s.currentUserId)
  const [tab, setTab] = useState('grid')
  const [extraRows, setExtraRows] = useState([])
  const days = Array.from({ length: 7 }, (_, i) => dayStr(addDays(cursor, i)))
  const entries = []
  s.tasks.forEach((t) => !t.deletedAt && (t.timeEntries || []).forEach((e) => { const d = dayStr(new Date(e.start)); if ((user === 'all' || e.userId === user) && d >= days[0] && d <= days[6]) entries.push({ ...e, day: d, task: t }) }))
  const taskIds = [...new Set([...entries.map((e) => e.task.id), ...extraRows])]
  const sum = (f) => entries.filter(f).reduce((a, e) => a + e.minutes, 0)
  const total = sum(() => true)
  const billable = sum((e) => e.billable)
  const addCell = (taskId, day) => {
    const v = prompt(`Adicionar tempo em ${day.split('-').reverse().join('/')} (ex: 1h 30m)`)
    const m = parseDuration(v)
    if (m) s.addTimeEntry(taskId, { userId: user === 'all' ? s.currentUserId : user, start: new Date(day + 'T09:00').getTime(), minutes: m, note: '' })
  }
  const exportCsv = () => {
    const rows = [['Data', 'Pessoa', 'Tarefa', 'Local', 'Minutos', 'Duração', 'Faturável', 'Nota'], ...entries.sort((a, b) => a.start - b.start).map((e) => [e.day, getMember(s, e.userId)?.name, e.task.name, taskPath(s, e.task), e.minutes, fmtMinutes(e.minutes), e.billable ? 'sim' : 'não', e.note])]
    download('planilha-de-horas.csv', '﻿' + rows.map((r) => r.map((x) => `"${String(x ?? '').replace(/"/g, '""')}"`).join(',')).join('\n'), 'text/csv')
  }
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-6xl p-6">
        <div className="flex flex-wrap items-center gap-2">
          <h1 className="text-xl font-bold">Planilhas de horas</h1>
          <div className="flex-1" />
          <select className="input !w-auto" value={user} onChange={(e) => setUser(e.target.value)}><option value="all">Todos</option>{s.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
          <button className="btn btn-outline" onClick={() => setCursor(startOfWeek(new Date(), { weekStartsOn: 1 }))}>Esta semana</button>
          <button className="btn btn-ghost !p-1" onClick={() => setCursor(addWeeks(cursor, -1))}><ChevronLeft size={16} /></button>
          <button className="btn btn-ghost !p-1" onClick={() => setCursor(addWeeks(cursor, 1))}><ChevronRight size={16} /></button>
          <span className="font-semibold">{format(cursor, 'd MMM', { locale: ptBR })} – {format(addDays(cursor, 6), 'd MMM yyyy', { locale: ptBR })}</span>
          <button className="btn btn-outline" onClick={exportCsv}><Download size={14} />CSV</button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <div className="card p-4"><div className="text-2xl font-bold">{fmtMinutes(total) || '0m'}</div><div className="text-[12px] text-zinc-500">Total da semana</div></div>
          <div className="card p-4"><div className="text-2xl font-bold">{fmtMinutes(billable) || '0m'}</div><div className="text-[12px] text-zinc-500">Faturável</div></div>
          <div className="card p-4"><div className="text-2xl font-bold">{taskIds.length}</div><div className="text-[12px] text-zinc-500">Tarefas com tempo</div></div>
        </div>
        <div className="mt-4"><Tabs value={tab} onChange={setTab} tabs={[['grid', 'Grade semanal'], ['entries', 'Registros', entries.length]]} /></div>
        {tab === 'grid' ? (
          <table className="mt-3 w-full border-collapse">
            <thead>
              <tr className="text-[11px] text-zinc-400">
                <th className="py-2 text-left font-medium">Tarefa</th>
                {days.map((d) => <th key={d} className={cx('w-20 font-medium', d === todayStr() && 'text-accent')}>{format(new Date(d + 'T12:00'), 'EEE d', { locale: ptBR })}</th>)}
                <th className="w-20 font-medium">Total</th>
              </tr>
            </thead>
            <tbody>
              {taskIds.map((id) => {
                const t = getTask(s, id)
                if (!t) return null
                return (
                  <tr key={id} className="border-t border-zinc-100 dark:border-zinc-800">
                    <td className="py-2"><button className="flex items-center gap-2 text-left" onClick={() => s.openTask(id)}><StatusDot status={taskStatus(s, t)} size={8} /><span className="truncate font-medium">{t.name}</span></button><div className="pl-5 text-[11px] text-zinc-400">{taskPath(s, t)}</div></td>
                    {days.map((d) => {
                      const m = sum((e) => e.task.id === id && e.day === d)
                      return <td key={d} className="text-center"><button onClick={() => addCell(id, d)} className={cx('h-8 w-16 rounded-md', m ? 'bg-accent-50 font-semibold text-accent dark:bg-accent/15' : 'text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800')}>{m ? fmtMinutes(m) : '+'}</button></td>
                    })}
                    <td className="text-center font-semibold">{fmtMinutes(sum((e) => e.task.id === id)) || '—'}</td>
                  </tr>
                )
              })}
              <tr className="border-t border-zinc-200 dark:border-zinc-700">
                <td className="py-2">
                  <Popover trigger={<button className="btn btn-ghost text-accent"><Plus size={14} />Adicionar tarefa à planilha</button>}>{(c) => <TaskPickerMenu exclude={taskIds} onPick={(id) => setExtraRows([...extraRows, id])} close={c} />}</Popover>
                </td>
                {days.map((d) => <td key={d} className="text-center font-semibold">{fmtMinutes(sum((e) => e.day === d)) || ''}</td>)}
                <td className="text-center font-bold">{fmtMinutes(total) || '0m'}</td>
              </tr>
            </tbody>
          </table>
        ) : (
          <div className="mt-3">
            {!entries.length && <Empty icon={Clock} title="Sem registros nesta semana" text="Use o cronômetro dentro de uma tarefa ou clique numa célula da grade." />}
            {entries.sort((a, b) => b.start - a.start).map((e) => (
              <div key={e.id} className="group flex items-center gap-3 border-b border-zinc-100 py-2 dark:border-zinc-800">
                <Avatar userId={e.userId} size={22} />
                <button className="flex-1 truncate text-left font-medium hover:text-accent" onClick={() => s.openTask(e.task.id)}>{e.task.name}</button>
                <span className="text-[12px] text-zinc-400">{e.note}</span>
                <span className="text-[12px] text-zinc-500">{fmtDateTime(e.start)}</span>
                <button onClick={() => s.updateTimeEntry(e.task.id, e.id, { billable: !e.billable })} className={cx('text-[12px] font-bold', e.billable ? 'text-emerald-500' : 'text-zinc-300')} title="Faturável">$</button>
                <span className="w-16 text-right font-semibold">{fmtMinutes(e.minutes)}</span>
                <button className="text-[11px] text-zinc-400 opacity-0 hover:text-red-500 group-hover:opacity-100" onClick={() => s.deleteTimeEntry(e.task.id, e.id)}>remover</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
