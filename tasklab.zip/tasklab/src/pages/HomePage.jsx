import React, { useState } from 'react'
import { Sun, Bell, Plus, Trash2, MessageSquare, Clock, CheckCircle2, AlertTriangle, CalendarDays } from 'lucide-react'
import { addDays } from 'date-fns'
import { useStore } from '../store/store'
import { StatusDot, Popover, StatusMenu, PriorityFlag, Avatar, Tabs, DateButton } from '../components/ui'
import { taskStatus, isClosed, taskPath, getMember, getTask, timeTracked } from '../lib/selectors'
import { setStatus, memberName } from '../lib/actions'
import { todayStr, dayStr, fmtDay, dueTone, cx, fmtRelative, fmtMinutes } from '../lib/utils'

export function MiniTaskRow({ t }) {
  const s = useStore()
  const closed = isClosed(s, t)
  return (
    <div className="group flex items-center gap-2 rounded-md px-2 py-2 hover:bg-zinc-50 dark:hover:bg-zinc-900">
      <Popover trigger={<button><StatusDot status={taskStatus(s, t)} /></button>}>{(c) => <StatusMenu listId={t.listId} value={t.statusId} onChange={(id) => setStatus(t.id, id)} close={c} />}</Popover>
      <button className="min-w-0 flex-1 text-left" onClick={() => s.openTask(t.id)}>
        <div className={cx('truncate font-medium', closed && 'text-zinc-400 line-through')}>{t.name}</div>
        <div className="truncate text-[11px] text-zinc-400">{taskPath(s, t)}</div>
      </button>
      <PriorityFlag p={t.priority} size={13} />
      <span className={cx('w-20 text-right text-[12px]', dueTone(t.dueDate, closed))}>{t.dueDate ? fmtDay(t.dueDate) : ''}</span>
    </div>
  )
}

export default function HomePage() {
  const s = useStore()
  const me = getMember(s, s.currentUserId)
  const [tab, setTab] = useState('today')
  const [rem, setRem] = useState('')
  const today = todayStr()
  const mine = s.tasks.filter((t) => !t.deletedAt && !t.archived && t.assignees.includes(s.currentUserId))
  const open = mine.filter((t) => !isClosed(s, t))
  const overdue = open.filter((t) => t.dueDate && t.dueDate < today)
  const todayT = open.filter((t) => t.dueDate === today || (t.startDate && t.startDate <= today && t.dueDate && t.dueDate > today))
  const next = open.filter((t) => t.dueDate && t.dueDate > today && !todayT.includes(t)).sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  const nodate = open.filter((t) => !t.dueDate)
  const done = mine.filter((t) => isClosed(s, t) && t.closedAt && Date.now() - t.closedAt < 14 * 86400000).sort((a, b) => b.closedAt - a.closedAt)
  const assignedComments = s.comments.filter((c) => c.assignedTo === s.currentUserId && !c.resolved)
  const reminders = s.reminders.filter((r) => r.userId === s.currentUserId).sort((a, b) => a.done - b.done || (a.dueDate || '').localeCompare(b.dueDate || ''))
  const trackedToday = s.tasks.reduce((a, t) => a + (t.timeEntries || []).filter((e) => e.userId === s.currentUserId && dayStr(new Date(e.start)) === today).reduce((x, e) => x + e.minutes, 0), 0)
  const hour = new Date().getHours()
  const greet = hour < 12 ? 'Bom dia' : hour < 18 ? 'Boa tarde' : 'Boa noite'
  const lists = { today: [...overdue, ...todayT], next, nodate, done }
  const recent = [...s.tasks].filter((t) => !t.deletedAt).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 6)

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-6xl p-6">
        <div className="flex items-end gap-3">
          <div>
            <div className="flex items-center gap-2 text-zinc-400"><Sun size={16} />{new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
            <h1 className="mt-1 text-2xl font-bold">{greet}, {me?.name.split(' ')[0]}</h1>
          </div>
        </div>
        <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            [AlertTriangle, 'Atrasadas', overdue.length, 'text-red-500'],
            [CalendarDays, 'Para hoje', todayT.length, 'text-amber-500'],
            [CheckCircle2, 'Concluídas (14d)', done.length, 'text-emerald-500'],
            [Clock, 'Rastreado hoje', fmtMinutes(trackedToday) || '0m', 'text-accent'],
          ].map(([I, l, v, c]) => (
            <div key={l} className="card flex items-center gap-3 p-4"><I size={22} className={c} /><div><div className="text-xl font-bold">{v}</div><div className="text-[12px] text-zinc-500">{l}</div></div></div>
          ))}
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-3">
          <div className="card p-4 lg:col-span-2">
            <div className="mb-2 flex items-center"><h2 className="font-semibold">Meu trabalho</h2><div className="flex-1" /><button className="btn btn-ghost text-accent" onClick={() => s.setQuickCreate({ assignees: [s.currentUserId] })}><Plus size={14} />Tarefa</button></div>
            <Tabs value={tab} onChange={setTab} tabs={[['today', 'Hoje e atrasadas', lists.today.length], ['next', 'Próximas', next.length], ['nodate', 'Sem data', nodate.length], ['done', 'Concluídas', done.length]]} />
            <div className="mt-2">
              {tab === 'today' && overdue.length > 0 && <div className="label px-2 pt-2 text-red-500">Atrasadas</div>}
              {lists[tab].map((t, i) => (
                <React.Fragment key={t.id}>
                  {tab === 'today' && i === overdue.length && overdue.length > 0 && <div className="label px-2 pt-2">Hoje</div>}
                  <MiniTaskRow t={t} />
                </React.Fragment>
              ))}
              {!lists[tab].length && <div className="py-10 text-center text-zinc-400">Nada por aqui 🎉</div>}
            </div>
          </div>

          <div className="space-y-6">
            <div className="card p-4">
              <h2 className="mb-2 flex items-center gap-2 font-semibold"><Bell size={15} />Lembretes</h2>
              <div className="flex gap-1">
                <input className="input" placeholder="Novo lembrete…" value={rem} onChange={(e) => setRem(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && rem.trim()) { s.addReminder(rem.trim(), today); setRem('') } }} />
              </div>
              <div className="mt-2 space-y-0.5">
                {reminders.map((r) => (
                  <div key={r.id} className="group flex items-center gap-2 rounded px-1 py-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-900">
                    <input type="checkbox" checked={r.done} onChange={(e) => s.updateReminder(r.id, { done: e.target.checked })} className="accent-[#6d5dfc]" />
                    <span className={cx('flex-1', r.done && 'text-zinc-400 line-through')}>{r.text}</span>
                    <DateButton value={r.dueDate} onChange={(d) => s.updateReminder(r.id, { dueDate: d })} tone={dueTone(r.dueDate, r.done)} className="text-[11px]" />
                    <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={() => s.deleteReminder(r.id)}><Trash2 size={12} /></button>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-4">
              <h2 className="mb-2 flex items-center gap-2 font-semibold"><MessageSquare size={15} />Comentários atribuídos a mim</h2>
              {assignedComments.map((c) => (
                <button key={c.id} onClick={() => s.openTask(c.taskId)} className="block w-full rounded px-2 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-900">
                  <div className="flex items-center gap-1.5 text-[11px] text-zinc-400"><Avatar userId={c.userId} size={14} />{memberName(c.userId)} · {getTask(s, c.taskId)?.name}</div>
                  <div className="line-clamp-2">{c.text}</div>
                </button>
              ))}
              {!assignedComments.length && <div className="text-zinc-400">Nenhum comentário pendente.</div>}
            </div>
            <div className="card p-4">
              <h2 className="mb-2 font-semibold">Atualizadas recentemente</h2>
              {recent.map((t) => <button key={t.id} onClick={() => s.openTask(t.id)} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-900"><StatusDot status={taskStatus(s, t)} size={8} /><span className="flex-1 truncate">{t.name}</span><span className="text-[11px] text-zinc-400">{fmtRelative(t.updatedAt)}</span></button>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
