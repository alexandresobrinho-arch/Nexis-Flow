import React, { useState } from 'react'
import { FileText, Plus, ChevronRight, Trash2, Star, BookOpen, Download, ArrowLeft, Search, MoreHorizontal, FilePlus } from 'lucide-react'
import { useStore } from '../store/store'
import { Avatar, Popover, Confirm, Tabs, Empty } from '../components/ui'
import RichEditor from '../components/RichEditor'
import { locationName } from '../lib/selectors'
import { memberName } from '../lib/actions'
import { fmtRelative, cx, download, stripHtml } from '../lib/utils'

const ICONS = ['📄', '📘', '📝', '🚀', '🏷️', '🧩', '📊', '💡', '✅', '📌', '🎯', '🗂️', '⚙️', '🔥', '🧠', '📣']

function rootOf(docs, d) { let cur = d; while (cur?.parentId) cur = docs.find((x) => x.id === cur.parentId) || null; return cur || d }

function Tree({ docs, parentId, depth, activeId, go }) {
  const s = useStore()
  const kids = docs.filter((d) => d.parentId === parentId)
  const [open, setOpen] = useState({})
  return kids.map((d) => {
    const has = docs.some((x) => x.parentId === d.id)
    const isOpen = open[d.id] !== false
    return (
      <div key={d.id}>
        <div className={cx('group flex items-center gap-1 rounded-md py-1 pr-1', d.id === activeId ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800')} style={{ paddingLeft: 4 + depth * 14 }}>
          {has ? <button onClick={() => setOpen({ ...open, [d.id]: !isOpen })} className="text-zinc-400"><ChevronRight size={12} className={cx('transition-transform', isOpen && 'rotate-90')} /></button> : <span className="w-3" />}
          <button className="flex flex-1 items-center gap-1.5 truncate text-left" onClick={() => go(d.id)}><span>{d.icon}</span><span className="truncate">{d.title}</span></button>
          <button title="Subpágina" className="hidden text-zinc-400 hover:text-accent group-hover:block" onClick={() => go(s.addDoc({ parentId: d.id, locType: d.locType, locId: d.locId, title: 'Nova página' }))}><Plus size={12} /></button>
        </div>
        {has && isOpen && <Tree docs={docs} parentId={d.id} depth={depth + 1} activeId={activeId} go={go} />}
      </div>
    )
  })
}

function DocEditor({ doc }) {
  const s = useStore()
  const [confirm, setConfirm] = useState(false)
  const root = rootOf(s.docs, doc)
  const go = (id) => s.navigate({ page: 'docs', docId: id })
  const children = s.docs.filter((d) => d.parentId === doc.id)
  const fav = s.favorites.some((f) => f.type === 'doc' && f.id === doc.id)
  const words = stripHtml(doc.content).split(' ').filter(Boolean).length
  const breadcrumbs = []
  let cur = doc
  while (cur) { breadcrumbs.unshift(cur); cur = s.docs.find((x) => x.id === cur.parentId) }
  return (
    <div className="flex h-full">
      <aside className="w-60 shrink-0 overflow-y-auto border-r border-zinc-200 p-2 dark:border-zinc-800">
        <button className="btn btn-ghost mb-2 w-full !justify-start" onClick={() => s.navigate({ page: 'docs' })}><ArrowLeft size={14} />Todos os docs</button>
        <div className="mb-1 flex items-center gap-1.5 px-1 font-semibold"><span>{root.icon}</span><span className="truncate">{root.title}</span></div>
        <div className={cx('rounded-md px-1 py-1', root.id === doc.id && 'bg-accent-50 text-accent dark:bg-accent/15')}><button className="w-full text-left text-[12px]" onClick={() => go(root.id)}>Página inicial</button></div>
        <Tree docs={s.docs} parentId={root.id} depth={0} activeId={doc.id} go={go} />
        <button className="btn btn-ghost mt-1 w-full !justify-start text-zinc-400" onClick={() => go(s.addDoc({ parentId: root.id, locType: root.locType, locId: root.locId, title: 'Nova página' }))}><Plus size={13} />Adicionar página</button>
      </aside>
      <div className="min-w-0 flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 flex items-center gap-2 border-b border-zinc-100 bg-white/90 px-6 py-2 text-[12px] text-zinc-500 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/90">
          {breadcrumbs.map((b, i) => <React.Fragment key={b.id}>{i > 0 && <ChevronRight size={11} />}<button className="hover:text-accent" onClick={() => go(b.id)}>{b.icon} {b.title}</button></React.Fragment>)}
          <div className="flex-1" />
          <span>{words} palavras · editado {fmtRelative(doc.updatedAt)}</span>
          <button onClick={() => s.toggleFavorite('doc', doc.id)} className={fav ? 'text-amber-400' : 'hover:text-amber-400'}><Star size={15} fill={fav ? 'currentColor' : 'none'} /></button>
          <Popover align="end" trigger={<button className="btn btn-ghost !p-1"><MoreHorizontal size={16} /></button>}>
            {(c) => (
              <div className="menu w-60">
                <button className="menu-item" onClick={() => { s.updateDoc(doc.id, { wiki: !doc.wiki }); c() }}><BookOpen size={14} />{doc.wiki ? 'Remover marca de Wiki' : 'Marcar como Wiki'}</button>
                <button className="menu-item" onClick={() => { go(s.addDoc({ parentId: doc.id, locType: doc.locType, locId: doc.locId, title: 'Nova página' })); c() }}><FilePlus size={14} />Nova subpágina</button>
                <div className="px-2 py-1">
                  <div className="label mb-1">Localização</div>
                  <select className="input" value={`${doc.locType}:${doc.locId || ''}`} onChange={(e) => { const [locType, locId] = e.target.value.split(':'); s.updateDoc(doc.id, { locType, locId: locId || null }) }}>
                    <option value="everything:">Workspace</option>
                    {s.spaces.map((sp) => <option key={sp.id} value={`space:${sp.id}`}>Space: {sp.name}</option>)}
                    {s.lists.map((l) => <option key={l.id} value={`list:${l.id}`}>Lista: {l.name}</option>)}
                  </select>
                </div>
                <button className="menu-item" onClick={() => { download(`${doc.title}.html`, `<!doctype html><meta charset="utf-8"><title>${doc.title}</title><h1>${doc.title}</h1>${doc.content}`, 'text/html'); c() }}><Download size={14} />Exportar HTML</button>
                <button className="menu-item text-red-500" onClick={() => setConfirm(true)}><Trash2 size={14} />Excluir {children.length ? 'com subpáginas' : ''}</button>
                <Confirm open={confirm} onClose={() => { setConfirm(false); c() }} onConfirm={() => s.deleteDoc(doc.id)} title={`Excluir "${doc.title}"?`} />
              </div>
            )}
          </Popover>
        </div>
        <div className="mx-auto max-w-3xl px-8 py-10">
          <Popover trigger={<button className="mb-2 rounded-lg p-1 text-5xl hover:bg-zinc-100 dark:hover:bg-zinc-800">{doc.icon}</button>}>
            {(c) => <div className="menu grid grid-cols-8 gap-1 p-2">{ICONS.map((i) => <button key={i} className="rounded p-1 text-xl hover:bg-zinc-100 dark:hover:bg-zinc-800" onClick={() => { s.updateDoc(doc.id, { icon: i }); c() }}>{i}</button>)}</div>}
          </Popover>
          <input key={doc.id} className="w-full bg-transparent text-4xl font-bold outline-none placeholder:text-zinc-300" placeholder="Sem título" defaultValue={doc.title} onChange={(e) => s.updateDoc(doc.id, { title: e.target.value || 'Sem título' })} />
          <div className="mt-2 flex items-center gap-2 text-[12px] text-zinc-400">
            <Avatar userId={doc.createdBy} size={18} />{memberName(doc.createdBy)} · {locationName(s, doc.locType, doc.locId) || 'Workspace'}{doc.wiki && <span className="rounded bg-emerald-100 px-1.5 font-semibold text-emerald-700 dark:bg-emerald-500/15">WIKI</span>}
          </div>
          <div className="mt-6">
            <RichEditor docKey={doc.id} html={doc.content} onChange={(content) => s.updateDoc(doc.id, { content })} minHeight={300} />
          </div>
          {children.length > 0 && (
            <div className="mt-10 border-t border-zinc-100 pt-4 dark:border-zinc-800">
              <div className="label mb-2">Subpáginas</div>
              <div className="grid grid-cols-2 gap-2">{children.map((c) => <button key={c.id} onClick={() => go(c.id)} className="card flex items-center gap-2 p-3 text-left hover:border-accent"><span className="text-xl">{c.icon}</span><span className="truncate font-medium">{c.title}</span></button>)}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default function DocsPage() {
  const s = useStore()
  const [tab, setTab] = useState('all')
  const [q, setQ] = useState('')
  const doc = s.docs.find((d) => d.id === s.route.docId)
  if (doc) return <DocEditor doc={doc} />
  const roots = s.docs.filter((d) => !d.parentId).filter((d) => tab === 'all' || (tab === 'mine' && d.createdBy === s.currentUserId) || (tab === 'wiki' && d.wiki) || (tab === 'fav' && s.favorites.some((f) => f.type === 'doc' && f.id === d.id)))
    .filter((d) => !q || d.title.toLowerCase().includes(q.toLowerCase()) || stripHtml(d.content).toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => b.updatedAt - a.updatedAt)
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-5xl p-6">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold">Docs</h1>
          <div className="flex-1" />
          <div className="relative w-64"><Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-400" /><input className="input !pl-7" placeholder="Buscar em docs…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <button className="btn btn-primary" onClick={() => s.navigate({ page: 'docs', docId: s.addDoc({}) })}><Plus size={14} />Novo doc</button>
        </div>
        <div className="mt-4"><Tabs value={tab} onChange={setTab} tabs={[['all', 'Todos'], ['mine', 'Criados por mim'], ['wiki', 'Wikis'], ['fav', 'Favoritos']]} /></div>
        {!roots.length ? <Empty icon={FileText} title="Nenhum doc" text="Docs suportam páginas aninhadas, wikis e comandos com /." /> : (
          <table className="mt-3 w-full">
            <thead><tr className="text-left text-[11px] uppercase text-zinc-400"><th className="py-2 font-medium">Nome</th><th className="font-medium">Localização</th><th className="font-medium">Páginas</th><th className="font-medium">Criado por</th><th className="font-medium">Atualizado</th></tr></thead>
            <tbody>
              {roots.map((d) => (
                <tr key={d.id} className="cursor-pointer border-t border-zinc-100 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-900" onClick={() => s.navigate({ page: 'docs', docId: d.id })}>
                  <td className="py-2.5"><span className="mr-2">{d.icon}</span><span className="font-medium">{d.title}</span>{d.wiki && <span className="ml-2 rounded bg-emerald-100 px-1.5 text-[10px] font-semibold text-emerald-700 dark:bg-emerald-500/15">WIKI</span>}</td>
                  <td className="text-zinc-500">{locationName(s, d.locType, d.locId) || 'Workspace'}</td>
                  <td className="text-zinc-500">{1 + s.docs.filter((x) => rootOf(s.docs, x).id === d.id && x.id !== d.id).length}</td>
                  <td><Avatar userId={d.createdBy} size={20} /></td>
                  <td className="text-zinc-500">{fmtRelative(d.updatedAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
