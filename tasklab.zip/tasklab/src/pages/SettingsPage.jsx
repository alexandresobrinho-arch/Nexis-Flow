import React, { useRef, useState } from 'react'
import { Plus, Trash2, Download, Upload, RotateCcw, Eraser } from 'lucide-react'
import { useStore } from '../store/store'
import { Tabs, Toggle, Avatar, Popover, ColorPicker, TagChip, Icon, Confirm, ICONS } from '../components/ui'
import { download, PALETTE } from '../lib/utils'

const CLICKAPPS = [
  ['priorities', 'Prioridades', 'Bandeiras Urgente/Alta/Normal/Baixa nas tarefas'],
  ['tags', 'Tags', 'Rótulos coloridos compartilhados no workspace'],
  ['multipleAssignees', 'Múltiplos responsáveis', 'Permite mais de uma pessoa por tarefa'],
  ['timeTracking', 'Controle de tempo', 'Cronômetro, registros manuais e planilhas de horas'],
  ['timeEstimates', 'Estimativas de tempo', 'Quanto tempo a tarefa deve levar'],
  ['points', 'Sprint points', 'Pontuação de esforço (Fibonacci)'],
  ['customTaskIds', 'IDs personalizados', 'Exibe IDs como TL-123'],
  ['taskTypes', 'Tipos de tarefa', 'Tarefa, Marco, Bug, Reunião e tipos próprios'],
]

const SHORTCUTS = [['Ctrl/⌘ + K', 'Busca e comandos'], ['/', 'Abrir busca'], ['T', 'Nova tarefa'], ['[', 'Recolher/expandir barra lateral'], ['Esc', 'Fechar janela/menu'], ['Ctrl + Enter', 'Enviar comentário'], ['/ (em docs e descrições)', 'Menu de blocos'], ['Ctrl/⌘ + K (no editor)', 'Inserir link']]

export default function SettingsPage() {
  const s = useStore()
  const [tab, setTab] = useState('workspace')
  const [confirm, setConfirm] = useState(null)
  const file = useRef(null)
  const ws = s.workspace
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-4xl p-6">
        <h1 className="text-xl font-bold">Configurações</h1>
        <div className="mt-4"><Tabs value={tab} onChange={setTab} tabs={[['workspace', 'Workspace'], ['members', 'Membros', s.members.length], ['tags', 'Tags', s.tags.length], ['types', 'Tipos de tarefa'], ['data', 'Dados'], ['keys', 'Atalhos']]} /></div>

        {tab === 'workspace' && (
          <div className="mt-4 space-y-6">
            <div className="grid grid-cols-2 gap-3">
              <div><div className="label mb-1">Nome do workspace</div><input className="input" value={ws.name} onChange={(e) => s.updateWorkspace({ name: e.target.value })} /></div>
              <div><div className="label mb-1">Prefixo dos IDs</div><input className="input uppercase" value={ws.prefix} onChange={(e) => s.updateWorkspace({ prefix: e.target.value.toUpperCase().slice(0, 5) })} /></div>
            </div>
            <div>
              <h2 className="font-semibold">ClickApps</h2>
              <p className="text-[12px] text-zinc-500">Liga/desliga recursos no workspace inteiro — a interface se adapta.</p>
              <div className="mt-3 grid gap-2 md:grid-cols-2">
                {CLICKAPPS.map(([k, l, d]) => (
                  <div key={k} className="card flex items-center gap-3 p-3"><div className="flex-1"><div className="font-medium">{l}</div><div className="text-[12px] text-zinc-500">{d}</div></div><Toggle checked={!!ws.clickApps[k]} onChange={() => s.toggleClickApp(k)} /></div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === 'members' && (
          <div className="mt-4">
            <div className="mb-2 flex justify-end"><button className="btn btn-primary" onClick={() => { const name = prompt('Nome do membro'); if (name) s.addMember({ name, email: `${name.split(' ')[0].toLowerCase()}@tasklab.dev`, color: PALETTE[s.members.length % PALETTE.length] }) }}><Plus size={14} />Convidar membro</button></div>
            <table className="w-full">
              <thead><tr className="text-left text-[11px] uppercase text-zinc-400"><th className="py-2 font-medium">Pessoa</th><th className="font-medium">Cargo</th><th className="font-medium">Papel</th><th className="font-medium">Capacidade (h/dia)</th><th /></tr></thead>
              <tbody>
                {s.members.map((m) => (
                  <tr key={m.id} className="border-t border-zinc-100 dark:border-zinc-800">
                    <td className="py-2">
                      <div className="flex items-center gap-2">
                        <Popover trigger={<button><Avatar userId={m.id} size={30} /></button>}>{(c) => <div className="menu"><ColorPicker value={m.color} onChange={(color) => { s.updateMember(m.id, { color }); c() }} /></div>}</Popover>
                        <div><input className="bg-transparent font-medium outline-none" value={m.name} onChange={(e) => s.updateMember(m.id, { name: e.target.value })} /><input className="block w-full bg-transparent text-[11px] text-zinc-400 outline-none" value={m.email} onChange={(e) => s.updateMember(m.id, { email: e.target.value })} /></div>
                      </div>
                    </td>
                    <td><input className="input !py-1" value={m.title || ''} onChange={(e) => s.updateMember(m.id, { title: e.target.value })} /></td>
                    <td><select className="input !w-28 !py-1" value={m.role} onChange={(e) => s.updateMember(m.id, { role: e.target.value })}><option value="owner">Dono</option><option value="admin">Admin</option><option value="member">Membro</option><option value="guest">Convidado</option></select></td>
                    <td><input type="number" className="input !w-20 !py-1" value={m.capacity ?? 8} onChange={(e) => s.updateMember(m.id, { capacity: Number(e.target.value) })} /></td>
                    <td className="text-right">{m.role !== 'owner' && <button className="btn btn-ghost !p-1 text-red-500" onClick={() => setConfirm({ title: `Remover ${m.name}?`, run: () => s.removeMember(m.id) })}><Trash2 size={14} /></button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-3 text-[12px] text-zinc-500">Dica: use o avatar no topo para “simular como” outro membro — notificações, “Eu” nos filtros e o Início mudam de perspectiva.</p>
          </div>
        )}

        {tab === 'tags' && (
          <div className="mt-4 space-y-1">
            {s.tags.map((t) => (
              <div key={t.name} className="flex items-center gap-3 rounded-lg border border-zinc-200 px-3 py-2 dark:border-zinc-800">
                <Popover trigger={<button className="h-5 w-5 rounded" style={{ background: t.color }} />}>{(c) => <div className="menu"><ColorPicker value={t.color} onChange={(color) => { s.updateTag(t.name, { color }); c() }} /></div>}</Popover>
                <TagChip name={t.name} />
                <span className="text-[12px] text-zinc-400">{s.tasks.filter((x) => x.tags.includes(t.name) && !x.deletedAt).length} tarefas</span>
                <div className="flex-1" />
                <button className="btn btn-ghost !py-0.5 text-[12px]" onClick={() => { const n = prompt('Renomear tag', t.name); if (n) s.updateTag(t.name, { name: n.toLowerCase() }) }}>Renomear</button>
                <button className="btn btn-ghost !p-1 text-red-500" onClick={() => setConfirm({ title: `Excluir a tag "${t.name}"?`, run: () => s.deleteTag(t.name) })}><Trash2 size={13} /></button>
              </div>
            ))}
          </div>
        )}

        {tab === 'types' && (
          <div className="mt-4 space-y-1">
            {s.taskTypes.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-lg border border-zinc-200 px-3 py-2 dark:border-zinc-800">
                <Popover trigger={<button className="flex h-7 w-7 items-center justify-center rounded" style={{ background: t.color + '22', color: t.color }}><Icon name={t.icon} size={15} /></button>}>
                  {(c) => <div className="menu w-56"><ColorPicker value={t.color} onChange={(color) => s.updateTaskType(t.id, { color })} /><div className="grid grid-cols-6 gap-1 p-2">{Object.keys(ICONS).map((n) => <button key={n} className="flex h-7 w-7 items-center justify-center rounded hover:bg-zinc-100 dark:hover:bg-zinc-800" onClick={() => { s.updateTaskType(t.id, { icon: n }); c() }}><Icon name={n} size={14} /></button>)}</div></div>}
                </Popover>
                <input className="flex-1 bg-transparent font-medium outline-none" value={t.name} onChange={(e) => s.updateTaskType(t.id, { name: e.target.value })} />
                {t.id !== 'task' && <button className="btn btn-ghost !p-1 text-red-500" onClick={() => s.deleteTaskType(t.id)}><Trash2 size={13} /></button>}
              </div>
            ))}
            <button className="btn btn-ghost text-accent" onClick={() => s.addTaskType({ name: 'Novo tipo' })}><Plus size={14} />Adicionar tipo</button>
          </div>
        )}

        {tab === 'data' && (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <div className="card p-4"><div className="font-semibold">Exportar</div><p className="mb-3 text-[12px] text-zinc-500">Baixa todo o workspace em JSON (backup ou para estudar a estrutura de dados).</p><button className="btn btn-outline" onClick={() => download('tasklab-backup.json', s.exportData())}><Download size={14} />Exportar JSON</button></div>
            <div className="card p-4"><div className="font-semibold">Importar</div><p className="mb-3 text-[12px] text-zinc-500">Substitui os dados atuais por um backup exportado.</p>
              <button className="btn btn-outline" onClick={() => file.current.click()}><Upload size={14} />Importar JSON</button>
              <input ref={file} type="file" accept=".json" className="hidden" onChange={(e) => { const f = e.target.files[0]; if (!f) return; f.text().then((txt) => { try { s.importData(txt); s.toast('Dados importados') } catch (err) { alert('Arquivo inválido: ' + err.message) } }); e.target.value = '' }} />
            </div>
            <div className="card p-4"><div className="font-semibold">Restaurar demonstração</div><p className="mb-3 text-[12px] text-zinc-500">Volta para o workspace de exemplo.</p><button className="btn btn-outline" onClick={() => setConfirm({ title: 'Restaurar dados de demonstração?', text: 'Tudo que você criou será perdido.', run: s.resetDemo })}><RotateCcw size={14} />Restaurar</button></div>
            <div className="card p-4"><div className="font-semibold">Começar do zero</div><p className="mb-3 text-[12px] text-zinc-500">Apaga spaces, tarefas, docs, metas e dashboards (mantém membros e tags).</p><button className="btn btn-danger" onClick={() => setConfirm({ title: 'Apagar todo o conteúdo?', text: 'Não dá para desfazer (exporte antes, se quiser).', run: s.clearAll })}><Eraser size={14} />Apagar tudo</button></div>
          </div>
        )}

        {tab === 'keys' && (
          <div className="mt-4 divide-y divide-zinc-100 dark:divide-zinc-800">
            {SHORTCUTS.map(([k, l]) => <div key={k} className="flex items-center py-2"><span className="flex-1">{l}</span><kbd className="rounded border border-zinc-200 bg-zinc-50 px-2 py-0.5 font-mono text-[12px] dark:border-zinc-700 dark:bg-zinc-800">{k}</kbd></div>)}
          </div>
        )}
      </div>
      <Confirm open={!!confirm} onClose={() => setConfirm(null)} onConfirm={() => confirm.run()} title={confirm?.title} text={confirm?.text} label="Confirmar" />
    </div>
  )
}
