import React, { useState } from 'react'
import { Target, Plus, Trash2, ArrowLeft, CheckSquare, Hash, DollarSign, ToggleLeft, X, Folder } from 'lucide-react'
import { useStore } from '../store/store'
import { Avatar, Popover, UserPickerMenu, DatePickerMenu, ProgressBar, ColorPicker, Empty, Confirm, StatusDot, InlineEdit, Toggle } from '../components/ui'
import { TaskPickerMenu } from '../components/TaskDetail'
import { getTask, isClosed, taskStatus } from '../lib/selectors'
import { fmtDay, money, cx, dueTone } from '../lib/utils'

export function targetProgress(s, t) {
  if (t.type === 'boolean') return t.done ? 100 : 0
  if (t.type === 'tasks') {
    const tasks = (t.taskIds || []).map((id) => getTask(s, id)).filter((x) => x && !x.deletedAt)
    return tasks.length ? Math.round((tasks.filter((x) => isClosed(s, x)).length / tasks.length) * 100) : 0
  }
  const span = (t.target ?? 0) - (t.start ?? 0)
  return span ? Math.max(0, Math.min(100, Math.round((((t.current ?? 0) - (t.start ?? 0)) / span) * 100))) : 0
}
export function goalProgress(s, g) {
  if (!g.targets.length) return 0
  return Math.round(g.targets.reduce((a, t) => a + targetProgress(s, t), 0) / g.targets.length)
}

const T_TYPES = [['number', 'Número', Hash], ['currency', 'Moeda', DollarSign], ['boolean', 'Verdadeiro/Falso', ToggleLeft], ['tasks', 'Tarefas', CheckSquare]]

function TargetRow({ goal, t }) {
  const s = useStore()
  const p = targetProgress(s, t)
  const up = (patch) => s.updateTarget(goal.id, t.id, patch)
  const fmt = (v) => (t.type === 'currency' ? money(v) : `${v ?? 0}${t.unit ? ' ' + t.unit : ''}`)
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2">
        <InlineEdit value={t.name} onSave={(name) => up({ name })} className="flex-1 font-semibold" />
        <span className="text-[11px] text-zinc-400">{T_TYPES.find((x) => x[0] === t.type)?.[1]}</span>
        <span className="w-10 text-right font-bold">{p}%</span>
        <button className="text-zinc-400 hover:text-red-500" onClick={() => s.deleteTarget(goal.id, t.id)}><Trash2 size={13} /></button>
      </div>
      <div className="mt-2"><ProgressBar pct={p} color={goal.color} /></div>
      <div className="mt-3 text-[12px]">
        {(t.type === 'number' || t.type === 'currency') && (
          <div className="flex flex-wrap items-center gap-2 text-zinc-500">
            Atual <input type="number" className="input !w-28 !py-1" value={t.current ?? 0} onChange={(e) => up({ current: Number(e.target.value) })} />
            de <input type="number" className="input !w-24 !py-1" value={t.start ?? 0} onChange={(e) => up({ start: Number(e.target.value) })} />
            até <input type="number" className="input !w-28 !py-1" value={t.target ?? 0} onChange={(e) => up({ target: Number(e.target.value) })} />
            {t.type === 'number' && <input className="input !w-24 !py-1" placeholder="unidade" value={t.unit || ''} onChange={(e) => up({ unit: e.target.value })} />}
            <span className="ml-auto font-medium text-zinc-700 dark:text-zinc-200">{fmt(t.current)} / {fmt(t.target)}</span>
          </div>
        )}
        {t.type === 'boolean' && <label className="flex items-center gap-2"><Toggle checked={!!t.done} onChange={(v) => up({ done: v })} />{t.done ? 'Concluído' : 'Pendente'}</label>}
        {t.type === 'tasks' && (
          <div>
            {(t.taskIds || []).map((id) => getTask(s, id)).filter(Boolean).map((tk) => (
              <div key={tk.id} className="group flex items-center gap-2 py-1">
                <StatusDot status={taskStatus(s, tk)} size={8} />
                <button className={cx('flex-1 truncate text-left', isClosed(s, tk) && 'text-zinc-400 line-through')} onClick={() => s.openTask(tk.id)}>{tk.name}</button>
                <button className="hidden text-zinc-400 group-hover:block" onClick={() => up({ taskIds: t.taskIds.filter((x) => x !== tk.id) })}><X size={12} /></button>
              </div>
            ))}
            <Popover trigger={<button className="mt-1 text-accent">+ Vincular tarefa</button>}>{(c) => <TaskPickerMenu exclude={t.taskIds || []} onPick={(id) => up({ taskIds: [...(t.taskIds || []), id] })} close={c} />}</Popover>
          </div>
        )}
      </div>
    </div>
  )
}

function GoalDetail({ goal }) {
  const s = useStore()
  const [confirm, setConfirm] = useState(false)
  const p = goalProgress(s, goal)
  return (
    <div className="mx-auto max-w-3xl p-6">
      <button className="btn btn-ghost mb-3" onClick={() => s.navigate({ page: 'goals' })}><ArrowLeft size={14} />Metas</button>
      <div className="flex items-start gap-3">
        <Popover trigger={<button className="mt-1 flex h-10 w-10 items-center justify-center rounded-xl text-white" style={{ background: goal.color }}><Target size={20} /></button>}>{(c) => <div className="menu"><ColorPicker value={goal.color} onChange={(color) => { s.updateGoal(goal.id, { color }); c() }} /></div>}</Popover>
        <div className="flex-1">
          <InlineEdit value={goal.name} onSave={(name) => s.updateGoal(goal.id, { name })} className="text-2xl font-bold" />
          <div className="mt-1 flex flex-wrap items-center gap-3 text-[12px] text-zinc-500">
            <Popover trigger={<button className="flex items-center gap-1"><Avatar userId={goal.owner} size={18} />Dono</button>}>{(c) => <UserPickerMenu multiple={false} value={[goal.owner]} onChange={(v) => s.updateGoal(goal.id, { owner: v[0] })} close={c} />}</Popover>
            <Popover trigger={<button className={dueTone(goal.dueDate)}>Prazo: {goal.dueDate ? fmtDay(goal.dueDate, { full: true }) : '—'}</button>}>{(c) => <DatePickerMenu value={goal.dueDate} onChange={(d) => s.updateGoal(goal.id, { dueDate: d })} close={c} />}</Popover>
            <span className="flex items-center gap-1"><Folder size={12} /><input className="w-28 bg-transparent outline-none" defaultValue={goal.folder} onBlur={(e) => s.updateGoal(goal.id, { folder: e.target.value || 'Geral' })} /></span>
          </div>
        </div>
        <div className="text-right"><div className="text-3xl font-bold">{p}%</div><div className="text-[11px] text-zinc-400">progresso</div></div>
      </div>
      <textarea className="input mt-4" placeholder="Descrição da meta" defaultValue={goal.description} onBlur={(e) => s.updateGoal(goal.id, { description: e.target.value })} />
      <div className="mt-3"><ProgressBar pct={p} color={goal.color} h={10} /></div>
      <div className="mb-2 mt-6 flex items-center"><h2 className="font-semibold">Alvos ({goal.targets.length})</h2><div className="flex-1" />
        <Popover align="end" trigger={<button className="btn btn-primary"><Plus size={14} />Alvo</button>}>
          {(c) => <div className="menu w-52">{T_TYPES.map(([k, l, I]) => <button key={k} className="menu-item" onClick={() => { s.addTarget(goal.id, { name: `Novo alvo (${l.toLowerCase()})`, type: k, start: 0, target: 100, current: 0, taskIds: [], done: false }); c() }}><I size={14} />{l}</button>)}</div>}
        </Popover>
      </div>
      <div className="space-y-3">{goal.targets.map((t) => <TargetRow key={t.id} goal={goal} t={t} />)}</div>
      <button className="btn btn-ghost mt-6 text-red-500" onClick={() => setConfirm(true)}><Trash2 size={14} />Excluir meta</button>
      <Confirm open={confirm} onClose={() => setConfirm(false)} onConfirm={() => { s.deleteGoal(goal.id); s.navigate({ page: 'goals' }) }} title="Excluir esta meta?" />
    </div>
  )
}

export default function GoalsPage() {
  const s = useStore()
  const goal = s.goals.find((g) => g.id === s.route.goalId)
  const [folder, setFolder] = useState('all')
  if (goal) return <div className="h-full overflow-y-auto"><GoalDetail goal={goal} /></div>
  const folders = [...new Set(s.goals.map((g) => g.folder || 'Geral'))]
  const list = s.goals.filter((g) => folder === 'all' || g.folder === folder)
  return (
    <div className="flex h-full">
      <aside className="w-52 shrink-0 border-r border-zinc-200 p-3 dark:border-zinc-800">
        <div className="label mb-2 px-2">Pastas de metas</div>
        {[['all', 'Todas'], ...folders.map((f) => [f, f])].map(([k, l]) => <button key={k} onClick={() => setFolder(k)} className={cx('flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left', folder === k ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800')}><Folder size={14} />{l}<span className="ml-auto text-[11px] text-zinc-400">{k === 'all' ? s.goals.length : s.goals.filter((g) => g.folder === k).length}</span></button>)}
      </aside>
      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-4 flex items-center"><h1 className="text-xl font-bold">Metas</h1><div className="flex-1" /><button className="btn btn-primary" onClick={() => s.navigate({ page: 'goals', goalId: s.addGoal({ name: 'Nova meta', folder: folder === 'all' ? 'Geral' : folder }) })}><Plus size={14} />Nova meta</button></div>
        {!list.length && <Empty icon={Target} title="Nenhuma meta" text="Metas agregam alvos numéricos, monetários, sim/não e conjuntos de tarefas." />}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {list.map((g) => {
            const p = goalProgress(s, g)
            return (
              <button key={g.id} onClick={() => s.navigate({ page: 'goals', goalId: g.id })} className="card p-4 text-left transition hover:shadow-md">
                <div className="flex items-center gap-2"><span className="flex h-8 w-8 items-center justify-center rounded-lg text-white" style={{ background: g.color }}><Target size={16} /></span><span className="flex-1 truncate font-semibold">{g.name}</span><span className="text-lg font-bold">{p}%</span></div>
                <div className="mt-3"><ProgressBar pct={p} color={g.color} /></div>
                <div className="mt-3 flex items-center gap-2 text-[12px] text-zinc-500"><Avatar userId={g.owner} size={18} />{g.targets.length} alvos<span className="ml-auto">{g.dueDate ? fmtDay(g.dueDate, { full: true }) : ''}</span></div>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
