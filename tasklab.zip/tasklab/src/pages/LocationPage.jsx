import React, { useEffect, useState } from 'react'
import {
  List as ListIcon, Columns3, Table2, CalendarDays, GanttChart, AlignStartHorizontal, Gauge, FileInput, Plus, MoreHorizontal, Star, Zap, Pin, Copy, Pencil,
  Trash2, X, Users, Flag, CalendarClock, Tag, ArrowRightLeft, Archive, CircleDot, ListChecks, SlidersHorizontal, Layers, Folder, Lock,
} from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, StatusMenu, UserPickerMenu, PriorityMenu, DatePickerMenu, TagMenu, Icon, Confirm } from '../components/ui'
import { LocationMenu } from '../components/Sidebar'
import ViewToolbar from '../components/ViewToolbar'
import { runView, DEFAULT_CONFIG } from '../lib/query'
import { locationName, getList, getSpace, getFolder, getStatusesForLocation, tasksForLocation, getStatusesForList } from '../lib/selectors'
import { setStatus } from '../lib/actions'
import { cx } from '../lib/utils'
import ListView from '../views/ListView'
import BoardView from '../views/BoardView'
import TableView from '../views/TableView'
import CalendarView from '../views/CalendarView'
import GanttView from '../views/GanttView'
import TimelineView from '../views/TimelineView'
import WorkloadView from '../views/WorkloadView'
import FormView from '../views/FormView'

export const VIEW_TYPES = {
  list: { label: 'Lista', icon: ListIcon, C: ListView, desc: 'Tarefas agrupadas em linhas' },
  board: { label: 'Quadro', icon: Columns3, C: BoardView, desc: 'Kanban com arrastar e soltar' },
  table: { label: 'Tabela', icon: Table2, C: TableView, desc: 'Planilha com cálculos e CSV' },
  calendar: { label: 'Calendário', icon: CalendarDays, C: CalendarView, desc: 'Mês/semana por datas' },
  gantt: { label: 'Gantt', icon: GanttChart, C: GanttView, desc: 'Cronograma com dependências' },
  timeline: { label: 'Timeline', icon: AlignStartHorizontal, C: TimelineView, desc: 'Linhas por pessoa ou grupo' },
  workload: { label: 'Carga de trabalho', icon: Gauge, C: WorkloadView, desc: 'Capacidade da equipe' },
  form: { label: 'Formulário', icon: FileInput, C: FormView, desc: 'Coleta respostas como tarefas' },
}

function BulkBar({ ids, clear, locType, locId }) {
  const s = useStore()
  const [confirm, setConfirm] = useState(false)
  const statuses = getStatusesForLocation(s, locType, locId)
  const list = [...ids]
  const B = ({ icon: I, label, ...p }) => <button {...p} className="flex items-center gap-1.5 rounded-md px-2 py-1 hover:bg-white/10"><I size={14} />{label}</button>
  return (
    <div className="fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-1 rounded-xl bg-zinc-900 px-3 py-2 text-white shadow-2xl">
      <span className="mr-2 font-semibold">{ids.size} selecionada(s)</span>
      <Popover side="bottom" trigger={<span><B icon={CircleDot} label="Status" /></span>}>
        {(c) => <StatusMenu statuses={statuses} onChange={(sid) => {
          const name = statuses.find((x) => x.id === sid)?.name
          list.forEach((id) => { const t = s.tasks.find((x) => x.id === id); const st = getStatusesForList(s, t.listId).find((x) => x.name === name); if (st) setStatus(id, st.id) }); c()
        }} close={c} />}
      </Popover>
      <Popover trigger={<span><B icon={Users} label="Responsáveis" /></span>}>
        {(c) => <UserPickerMenu value={[]} onChange={(v) => { s.bulkUpdate(list, (t) => ({ assignees: [...new Set([...t.assignees, ...v])] })); c() }} close={c} multiple={false} />}
      </Popover>
      <Popover trigger={<span><B icon={Flag} label="Prioridade" /></span>}>{(c) => <PriorityMenu onChange={(p) => s.bulkUpdate(list, { priority: p })} close={c} />}</Popover>
      <Popover trigger={<span><B icon={CalendarClock} label="Entrega" /></span>}>{(c) => <DatePickerMenu onChange={(d) => s.bulkUpdate(list, { dueDate: d })} close={c} />}</Popover>
      <Popover trigger={<span><B icon={Tag} label="Tags" /></span>}>
        <TagMenu value={[]} onChange={(tags) => s.bulkUpdate(list, (t) => ({ tags: [...new Set([...t.tags, ...tags])] }))} />
      </Popover>
      <Popover trigger={<span><B icon={ArrowRightLeft} label="Mover" /></span>}>
        {(c) => <div className="menu max-h-72 w-56 overflow-y-auto text-zinc-800 dark:text-zinc-200">{s.lists.map((l) => <button key={l.id} className="menu-item" onClick={() => { list.forEach((id) => s.moveTask(id, l.id)); c(); clear() }}>{l.name}</button>)}</div>}
      </Popover>
      <B icon={Copy} label="Duplicar" onClick={() => { list.forEach((id) => s.duplicateTask(id)); clear() }} />
      <B icon={Archive} label="Arquivar" onClick={() => { s.bulkUpdate(list, { archived: true }); clear() }} />
      <B icon={Trash2} label="Excluir" onClick={() => setConfirm(true)} />
      <button className="ml-2 rounded p-1 hover:bg-white/10" onClick={clear}><X size={15} /></button>
      <Confirm open={confirm} onClose={() => setConfirm(false)} onConfirm={() => { list.forEach((id) => s.deleteTask(id)); clear() }} title={`Excluir ${ids.size} tarefa(s)?`} text="Elas vão para a lixeira." />
    </div>
  )
}

function ViewTab({ v, active, onClick }) {
  const s = useStore()
  const T = VIEW_TYPES[v.type]
  const [confirm, setConfirm] = useState(false)
  return (
    <div className={cx('group flex items-center rounded-md', active ? 'bg-zinc-100 dark:bg-zinc-800' : 'hover:bg-zinc-50 dark:hover:bg-zinc-900')}>
      <button onClick={onClick} className={cx('flex items-center gap-1.5 py-1.5 pl-2.5 pr-1', active ? 'font-semibold text-zinc-900 dark:text-white' : 'text-zinc-500')}>
        <T.icon size={14} />{v.name}{v.pinned && <Pin size={10} className="text-zinc-400" />}
      </button>
      <Popover trigger={<span className="mr-1 hidden rounded p-0.5 text-zinc-400 hover:bg-zinc-200 group-hover:inline-flex dark:hover:bg-zinc-700"><MoreHorizontal size={13} /></span>}>
        {(c) => (
          <div className="menu w-48">
            <button className="menu-item" onClick={() => { const n = prompt('Nome da view', v.name); if (n) s.updateView(v.id, { name: n }); c() }}><Pencil size={13} />Renomear</button>
            <button className="menu-item" onClick={() => { s.updateView(v.id, { pinned: !v.pinned }); c() }}><Pin size={13} />{v.pinned ? 'Desafixar' : 'Fixar'}</button>
            <button className="menu-item" onClick={() => { const id = s.duplicateView(v.id); s.navigate({ ...s.route, viewId: id }); c() }}><Copy size={13} />Duplicar</button>
            <button className="menu-item text-red-500" onClick={() => setConfirm(true)}><Trash2 size={13} />Excluir view</button>
            <Confirm open={confirm} onClose={() => { setConfirm(false); c() }} onConfirm={() => s.deleteView(v.id)} title={`Excluir a view "${v.name}"?`} text="As tarefas não são afetadas." />
          </div>
        )}
      </Popover>
    </div>
  )
}

export default function LocationPage() {
  const s = useStore()
  const { locType, locId } = s.route
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(new Set())
  useEffect(() => { s.ensureDefaultViews(locType, locId); setSelected(new Set()); setSearch('') }, [locType, locId])
  const views = s.views.filter((v) => v.locType === locType && v.locId === locId).sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0))
  const view = views.find((v) => v.id === s.route.viewId) || views[0]
  const item = locType === 'list' ? getList(s, locId) : locType === 'folder' ? getFolder(s, locId) : locType === 'space' ? getSpace(s, locId) : { name: 'Tudo' }
  if (!item) return <div className="p-8 text-zinc-500">Localização não encontrada.</div>
  if (!view) return null
  const T = VIEW_TYPES[view.type]
  const { tasks, config } = runView(s, locType, locId, view.config, s.currentUserId, search)
  const update = (patch) => s.updateViewConfig(view.id, patch)
  const space = locType === 'space' ? item : item.spaceId && getSpace(s, item.spaceId)
  const fav = s.favorites.some((f) => f.type === locType && f.id === locId)
  const autoCount = s.automations.filter((a) => a.locType === locType && a.locId === locId).length
  const total = tasksForLocation(s, locType, locId).length

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 pt-3">
        {locType === 'space' && <span className="flex h-7 w-7 items-center justify-center rounded-lg text-white" style={{ background: item.color }}><Icon name={item.icon} size={15} /></span>}
        {locType === 'folder' && <Folder size={18} style={{ color: item.color || space?.color }} />}
        {locType === 'list' && <span className="h-3 w-3 rounded-full" style={{ background: item.color }} />}
        {locType === 'everything' && <Layers size={18} className="text-zinc-400" />}
        <div className="min-w-0">
          {locType !== 'space' && locType !== 'everything' && <div className="text-[11px] text-zinc-400">{space?.name}{locType === 'list' && item.folderId ? ` / ${getFolder(s, item.folderId)?.name}` : ''}</div>}
          <h1 className="flex items-center gap-2 truncate text-[18px] font-bold">{item.name}{item.private && <Lock size={13} className="text-zinc-400" />}</h1>
        </div>
        {locType !== 'everything' && <button onClick={() => s.toggleFavorite(locType, locId)} className={fav ? 'text-amber-400' : 'text-zinc-300 hover:text-amber-400'}><Star size={16} fill={fav ? 'currentColor' : 'none'} /></button>}
        <span className="text-[12px] text-zinc-400">{total} tarefas</span>
        <div className="flex-1" />
        {locType !== 'everything' && (
          <>
            <button className="btn btn-ghost" onClick={() => s.setModal({ type: 'statuses', locType, locId })}><ListChecks size={14} />Status</button>
            <button className="btn btn-ghost" onClick={() => s.setModal({ type: 'fields', locType, locId })}><SlidersHorizontal size={14} />Campos</button>
            <button className="btn btn-ghost" onClick={() => s.setModal({ type: 'automations', locType, locId })}><Zap size={14} />Automações{autoCount ? <span className="rounded-full bg-accent px-1.5 text-[10px] text-white">{autoCount}</span> : null}</button>
            <Popover align="end" trigger={<button className="btn btn-ghost !p-1.5"><MoreHorizontal size={16} /></button>}>{(c) => <LocationMenu locType={locType} locId={locId} close={c} onRename={() => { const n = prompt('Novo nome', item.name); if (n) (locType === 'space' ? s.updateSpace : locType === 'folder' ? s.updateFolder : s.updateList)(locId, { name: n }) }} />}</Popover>
          </>
        )}
        <button className="btn btn-primary" onClick={() => s.setQuickCreate({ listId: locType === 'list' ? locId : undefined })}><Plus size={14} />Tarefa</button>
      </div>
      {locType === 'list' && (
        <input className="mx-4 mt-1 bg-transparent text-[12px] text-zinc-500 outline-none placeholder:text-zinc-300" placeholder="Adicionar descrição da lista…" defaultValue={item.description} key={item.id} onBlur={(e) => s.updateList(locId, { description: e.target.value })} />
      )}
      <div className="mt-2 flex items-center gap-1 border-b border-zinc-200 px-4 pb-1.5 dark:border-zinc-800">
        {views.map((v) => <ViewTab key={v.id} v={v} active={v.id === view.id} onClick={() => s.navigate({ ...s.route, viewId: v.id })} />)}
        <Popover trigger={<button className="btn btn-ghost !py-1 text-zinc-500"><Plus size={14} />View</button>}>
          {(c) => (
            <div className="menu grid w-[420px] grid-cols-2 gap-1 p-2">
              {Object.entries(VIEW_TYPES).map(([k, t]) => (
                <button key={k} className="menu-item !items-start" onClick={() => {
                  const id = s.addView(locType, locId, k, t.label, k === 'timeline' ? { groupBy: 'assignee' } : k === 'table' ? { columns: ['status', 'assignee', 'dueDate', 'priority', 'timeEstimate', 'points'] } : {})
                  s.navigate({ ...s.route, viewId: id }); c()
                }}>
                  <t.icon size={16} className="mt-0.5 text-accent" /><div><div className="font-medium">{t.label}</div><div className="text-[11px] text-zinc-400">{t.desc}</div></div>
                </button>
              ))}
            </div>
          )}
        </Popover>
      </div>
      <ViewToolbar view={view} config={config} update={update} locType={locType} locId={locId} search={search} setSearch={setSearch} />
      <div className="min-h-0 flex-1">
        <T.C key={view.id} view={view} tasks={tasks} config={config} update={update} locType={locType} locId={locId} selected={selected} setSelected={setSelected} />
      </div>
      {selected.size > 0 && <BulkBar ids={selected} clear={() => setSelected(new Set())} locType={locType} locId={locId} />}
    </div>
  )
}
