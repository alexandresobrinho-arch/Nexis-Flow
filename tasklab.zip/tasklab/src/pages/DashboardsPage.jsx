import React, { useState } from 'react'
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core'
import { SortableContext, useSortable, rectSortingStrategy, arrayMove } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell as PCell, LineChart, Line, CartesianGrid, Legend } from 'recharts'
import { LayoutDashboard, Plus, Trash2, Settings2, GripVertical, MoreHorizontal, Pencil, Hash, PieChart as PieIcon, BarChart3, TrendingUp, Clock, List as ListIcon, Target, Type, Flag } from 'lucide-react'
import { useStore } from '../store/store'
import { Modal, ModalHeader, Popover, StatusDot, Empty, Confirm, ProgressBar, Avatar } from '../components/ui'
import { tasksForLocation, taskStatus, isClosed, getMember, timeTracked, getFieldsForLocation, locationName, isOverdue, taskPath, getTask } from '../lib/selectors'
import { PRIORITIES, fmtMinutes, todayStr, dayStr, fmtDay, cx, money } from '../lib/utils'
import { addDays } from 'date-fns'
import { goalProgress } from './GoalsPage'

// paleta categórica validada (slots 1 e 2) para séries comparadas
const SERIES = { light: ['#2a78d6', '#eb6834'], dark: ['#3987e5', '#d95926'] }

export const CARD_TYPES = {
  calc: { label: 'Cálculo (número)', icon: Hash, w: 1 },
  status: { label: 'Tarefas por status', icon: PieIcon, w: 1 },
  assignee: { label: 'Tarefas por responsável', icon: BarChart3, w: 2 },
  priority: { label: 'Tarefas por prioridade', icon: Flag, w: 1 },
  burnup: { label: 'Criadas x concluídas', icon: TrendingUp, w: 2 },
  time: { label: 'Tempo rastreado', icon: Clock, w: 1 },
  tasklist: { label: 'Lista de tarefas', icon: ListIcon, w: 2 },
  goals: { label: 'Progresso das metas', icon: Target, w: 1 },
  text: { label: 'Texto / notas', icon: Type, w: 1 },
}

function useTheme() { return useStore((s) => s.theme) }
const axisStyle = { fontSize: 11, fill: '#71717a' }

function ChartTip({ active, payload, label, fmt }) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-md border border-zinc-200 bg-white px-2.5 py-1.5 text-[12px] shadow-lg dark:border-zinc-700 dark:bg-zinc-900">
      {label && <div className="mb-0.5 font-semibold">{label}</div>}
      {payload.map((p) => <div key={p.dataKey || p.name} className="flex items-center gap-2"><span className="h-2 w-2 rounded-sm" style={{ background: p.color || p.payload?.color }} /><span className="text-zinc-500">{p.name}</span><span className="ml-auto font-semibold">{fmt ? fmt(p.value) : p.value}</span></div>)}
    </div>
  )
}

function CardBody({ card }) {
  const s = useStore()
  const theme = useTheme()
  const c = card.config || {}
  const scope = c.scope || { locType: 'everything' }
  const tasks = tasksForLocation(s, scope.locType, scope.locId).filter((t) => !c.onlyMine || t.assignees.includes(s.currentUserId))
  const open = tasks.filter((t) => !isClosed(s, t))
  const grid = theme === 'dark' ? '#27272a' : '#f4f4f5'
  switch (card.type) {
    case 'calc': {
      let v
      const metric = c.metric || 'count'
      const base = c.onlyOpen ? open : tasks
      if (metric === 'count') v = base.length
      else if (metric === 'overdue') v = tasks.filter((t) => isOverdue(s, t)).length
      else if (metric === 'closed') v = tasks.filter((t) => isClosed(s, t)).length
      else if (metric === 'points') v = base.reduce((a, t) => a + (t.points || 0), 0)
      else if (metric === 'estimate') v = fmtMinutes(base.reduce((a, t) => a + (t.timeEstimate || 0), 0)) || '0m'
      else if (metric === 'tracked') v = fmtMinutes(base.reduce((a, t) => a + timeTracked(t), 0)) || '0m'
      else if (metric.startsWith('cf:')) { const f = s.fields.find((x) => x.id === metric.slice(3)); const sum = base.reduce((a, t) => a + (Number(t.cf?.[f?.id]) || 0), 0); v = f?.type === 'money' ? money(sum, f.config?.currency) : sum }
      const pct = metric === 'closed' && tasks.length ? Math.round((v / tasks.length) * 100) : null
      return (
        <div className="flex h-full flex-col justify-center">
          <div className={cx('text-4xl font-bold tracking-tight', metric === 'overdue' && v > 0 && 'text-red-500')}>{v}</div>
          <div className="mt-1 text-[12px] text-zinc-500">{locationName(s, scope.locType, scope.locId)}{pct !== null && ` · ${pct}% do total`}</div>
        </div>
      )
    }
    case 'status': {
      const map = {}
      tasks.forEach((t) => { const st = taskStatus(s, t); (map[st.name] ||= { name: st.name, value: 0, color: st.color, order: ['notstarted', 'active', 'done', 'closed'].indexOf(st.type) * 100 + (st.order || 0) }).value++ })
      const data = Object.values(map).sort((a, b) => a.order - b.order)
      if (!data.length) return <div className="text-zinc-400">Sem tarefas</div>
      if (c.chart === 'bar') {
        return (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
              <CartesianGrid vertical={false} stroke={grid} />
              <XAxis dataKey="name" tick={axisStyle} axisLine={false} tickLine={false} interval={0} />
              <YAxis allowDecimals={false} tick={axisStyle} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTip />} cursor={{ fill: grid }} />
              <Bar isAnimationActive={false} dataKey="value" name="Tarefas" radius={[4, 4, 0, 0]} maxBarSize={36}>{data.map((d) => <PCell key={d.name} fill={d.color} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        )
      }
      return (
        <div className="flex h-full items-center gap-3">
          <div className="flex flex-1 justify-center">
              <PieChart width={180} height={180}>
                <Pie isAnimationActive={false} data={data} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="85%" stroke={theme === 'dark' ? '#18181b' : '#fff'} strokeWidth={2}>{data.map((d) => <PCell key={d.name} fill={d.color} />)}</Pie>
                <Tooltip content={<ChartTip />} />
              </PieChart>
          </div>
          <div className="space-y-1 text-[12px]">{data.map((d) => <div key={d.name} className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: d.color }} /><span className="text-zinc-600 dark:text-zinc-300">{d.name}</span><span className="ml-auto pl-2 font-semibold">{d.value}</span></div>)}</div>
        </div>
      )
    }
    case 'assignee': {
      const data = [...s.members, { id: null, name: 'Ninguém' }].map((m) => ({ name: m.name.split(' ')[0], value: open.filter((t) => (m.id ? t.assignees.includes(m.id) : !t.assignees.length)).length })).filter((d) => d.value > 0)
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, bottom: 0, left: 8 }}>
            <CartesianGrid horizontal={false} stroke={grid} />
            <XAxis type="number" allowDecimals={false} tick={axisStyle} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey="name" tick={axisStyle} axisLine={false} tickLine={false} width={70} />
            <Tooltip content={<ChartTip />} cursor={{ fill: grid }} />
            <Bar isAnimationActive={false} dataKey="value" name="Tarefas abertas" fill={theme === 'dark' ? '#9085e9' : '#6250d6'} radius={[0, 4, 4, 0]} maxBarSize={22} />
          </BarChart>
        </ResponsiveContainer>
      )
    }
    case 'priority': {
      const data = [1, 2, 3, 4].map((p) => ({ name: PRIORITIES[p].label, value: open.filter((t) => t.priority === p).length, color: PRIORITIES[p].color }))
      data.push({ name: 'Sem', value: open.filter((t) => !t.priority).length, color: '#d4d4d8' })
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
            <CartesianGrid vertical={false} stroke={grid} />
            <XAxis dataKey="name" tick={axisStyle} axisLine={false} tickLine={false} />
            <YAxis allowDecimals={false} tick={axisStyle} axisLine={false} tickLine={false} />
            <Tooltip content={<ChartTip />} cursor={{ fill: grid }} />
            <Bar isAnimationActive={false} dataKey="value" name="Tarefas abertas" radius={[4, 4, 0, 0]} maxBarSize={36}>{data.map((d) => <PCell key={d.name} fill={d.color} />)}</Bar>
          </BarChart>
        </ResponsiveContainer>
      )
    }
    case 'burnup': {
      const days = c.days || 14
      const data = Array.from({ length: days }, (_, i) => {
        const d = dayStr(addDays(new Date(), i - days + 1))
        return {
          day: fmtDay(d, { full: true }),
          Criadas: tasks.filter((t) => dayStr(new Date(t.createdAt)) <= d).length,
          Concluídas: tasks.filter((t) => t.closedAt && dayStr(new Date(t.closedAt)) <= d).length,
        }
      })
      const [c1, c2] = SERIES[theme === 'dark' ? 'dark' : 'light']
      return (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: -20 }}>
            <CartesianGrid vertical={false} stroke={grid} />
            <XAxis dataKey="day" tick={axisStyle} axisLine={false} tickLine={false} interval="preserveStartEnd" minTickGap={24} />
            <YAxis allowDecimals={false} tick={axisStyle} axisLine={false} tickLine={false} />
            <Tooltip content={<ChartTip />} />
            <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />
            <Line isAnimationActive={false} type="monotone" dataKey="Criadas" stroke={c1} strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
            <Line isAnimationActive={false} type="monotone" dataKey="Concluídas" stroke={c2} strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
          </LineChart>
        </ResponsiveContainer>
      )
    }
    case 'time': {
      const data = s.members.map((m) => ({ name: m.name.split(' ')[0], value: Math.round(tasks.reduce((a, t) => a + (t.timeEntries || []).filter((e) => e.userId === m.id).reduce((x, e) => x + e.minutes, 0), 0) / 6) / 10 })).filter((d) => d.value > 0)
      if (!data.length) return <div className="text-zinc-400">Nenhum tempo registrado</div>
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
            <CartesianGrid vertical={false} stroke={grid} />
            <XAxis dataKey="name" tick={axisStyle} axisLine={false} tickLine={false} />
            <YAxis tick={axisStyle} axisLine={false} tickLine={false} />
            <Tooltip content={<ChartTip fmt={(v) => `${v} h`} />} cursor={{ fill: grid }} />
            <Bar isAnimationActive={false} dataKey="value" name="Horas" fill={theme === 'dark' ? '#3987e5' : '#2a78d6'} radius={[4, 4, 0, 0]} maxBarSize={36} />
          </BarChart>
        </ResponsiveContainer>
      )
    }
    case 'tasklist': {
      const today = todayStr()
      let list = open
      if (c.filter === 'due') list = open.filter((t) => t.dueDate && t.dueDate <= today)
      if (c.filter === 'week') list = open.filter((t) => t.dueDate && t.dueDate <= dayStr(addDays(new Date(), 7)))
      if (c.filter === 'urgent') list = open.filter((t) => t.priority === 1)
      if (c.filter === 'mine') list = open.filter((t) => t.assignees.includes(s.currentUserId))
      list = [...list].sort((a, b) => (a.dueDate || '9').localeCompare(b.dueDate || '9'))
      return (
        <div className="h-full overflow-y-auto">
          {list.map((t) => (
            <button key={t.id} onClick={() => s.openTask(t.id)} className="flex w-full items-center gap-2 rounded px-1 py-1.5 text-left hover:bg-zinc-50 dark:hover:bg-zinc-800/50">
              <StatusDot status={taskStatus(s, t)} size={8} /><span className="flex-1 truncate">{t.name}</span>
              <span className="truncate text-[11px] text-zinc-400">{taskPath(s, t).split(' / ').pop()}</span>
              <span className={cx('w-16 text-right text-[11px]', isOverdue(s, t) ? 'text-red-500' : 'text-zinc-500')}>{t.dueDate ? fmtDay(t.dueDate) : ''}</span>
            </button>
          ))}
          {!list.length && <div className="py-6 text-center text-zinc-400">Nenhuma tarefa 🎉</div>}
        </div>
      )
    }
    case 'goals':
      return <div className="h-full space-y-3 overflow-y-auto">{s.goals.map((g) => { const p = goalProgress(s, g); return <button key={g.id} className="block w-full text-left" onClick={() => s.navigate({ page: 'goals', goalId: g.id })}><div className="mb-1 flex justify-between text-[12px]"><span className="font-medium">{g.name}</span><span>{p}%</span></div><ProgressBar pct={p} color={g.color} /></button> })}</div>
    case 'text':
      return <div className="h-full overflow-y-auto whitespace-pre-wrap leading-relaxed text-zinc-600 dark:text-zinc-300">{c.text || 'Clique em configurar para escrever.'}</div>
    default: return null
  }
}

function CardEditor({ card, onSave, onClose }) {
  const s = useStore()
  const [c, setC] = useState(() => JSON.parse(JSON.stringify(card)))
  const cfg = c.config || {}
  const set = (p) => setC({ ...c, config: { ...cfg, ...p } })
  const scopeVal = `${cfg.scope?.locType || 'everything'}:${cfg.scope?.locId || ''}`
  const numFields = getFieldsForLocation(s, cfg.scope?.locType || 'everything', cfg.scope?.locId).filter((f) => ['number', 'money'].includes(f.type))
  return (
    <Modal open onClose={onClose} width={480}>
      <ModalHeader title="Configurar card" onClose={onClose} />
      <div className="space-y-3 p-4">
        <div><div className="label mb-1">Título</div><input className="input" value={c.title} onChange={(e) => setC({ ...c, title: e.target.value })} /></div>
        <div className="grid grid-cols-2 gap-2">
          <div><div className="label mb-1">Tipo</div><select className="input" value={c.type} onChange={(e) => setC({ ...c, type: e.target.value })}>{Object.entries(CARD_TYPES).map(([k, t]) => <option key={k} value={k}>{t.label}</option>)}</select></div>
          <div><div className="label mb-1">Largura</div><select className="input" value={c.w} onChange={(e) => setC({ ...c, w: Number(e.target.value) })}><option value={1}>1/3</option><option value={2}>2/3</option><option value={3}>Inteira</option></select></div>
        </div>
        {!['goals', 'text'].includes(c.type) && (
          <div><div className="label mb-1">Fonte dos dados</div>
            <select className="input" value={scopeVal} onChange={(e) => { const [locType, locId] = e.target.value.split(':'); set({ scope: { locType, locId: locId || undefined } }) }}>
              <option value="everything:">Workspace inteiro</option>
              {s.spaces.map((sp) => <option key={sp.id} value={`space:${sp.id}`}>Space: {sp.name}</option>)}
              {s.folders.map((f) => <option key={f.id} value={`folder:${f.id}`}>Pasta: {f.name}</option>)}
              {s.lists.map((l) => <option key={l.id} value={`list:${l.id}`}>Lista: {l.name}</option>)}
            </select>
            <label className="mt-2 flex items-center gap-2"><input type="checkbox" checked={!!cfg.onlyMine} onChange={(e) => set({ onlyMine: e.target.checked })} />Somente tarefas atribuídas a mim</label>
          </div>
        )}
        {c.type === 'calc' && (
          <div className="grid grid-cols-2 gap-2">
            <div><div className="label mb-1">Métrica</div>
              <select className="input" value={cfg.metric || 'count'} onChange={(e) => set({ metric: e.target.value })}>
                <option value="count">Contagem de tarefas</option><option value="overdue">Atrasadas</option><option value="closed">Concluídas</option>
                <option value="points">Soma de sprint points</option><option value="estimate">Soma de estimativas</option><option value="tracked">Soma de tempo rastreado</option>
                {numFields.map((f) => <option key={f.id} value={`cf:${f.id}`}>Soma de {f.name}</option>)}
              </select>
            </div>
            <label className="mt-6 flex items-center gap-2"><input type="checkbox" checked={!!cfg.onlyOpen} onChange={(e) => set({ onlyOpen: e.target.checked })} />Somente abertas</label>
          </div>
        )}
        {c.type === 'status' && <div><div className="label mb-1">Gráfico</div><select className="input" value={cfg.chart || 'pie'} onChange={(e) => set({ chart: e.target.value })}><option value="pie">Rosca</option><option value="bar">Barras</option></select></div>}
        {c.type === 'burnup' && <div><div className="label mb-1">Período (dias)</div><input type="number" className="input" value={cfg.days || 14} onChange={(e) => set({ days: Number(e.target.value) })} /></div>}
        {c.type === 'tasklist' && <div><div className="label mb-1">Filtro</div><select className="input" value={cfg.filter || 'due'} onChange={(e) => set({ filter: e.target.value })}><option value="due">Atrasadas e de hoje</option><option value="week">Próximos 7 dias</option><option value="urgent">Urgentes</option><option value="mine">Minhas abertas</option><option value="all">Todas abertas</option></select></div>}
        {c.type === 'text' && <div><div className="label mb-1">Texto</div><textarea className="input min-h-[120px]" value={cfg.text || ''} onChange={(e) => set({ text: e.target.value })} /></div>}
      </div>
      <div className="flex justify-end gap-2 border-t border-zinc-200 px-4 py-3 dark:border-zinc-800"><button className="btn btn-outline" onClick={onClose}>Cancelar</button><button className="btn btn-primary" onClick={() => onSave(c)}>Salvar</button></div>
    </Modal>
  )
}

function SortableCard({ card, dashId }) {
  const s = useStore()
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: card.id })
  const [edit, setEdit] = useState(false)
  const T = CARD_TYPES[card.type] || CARD_TYPES.text
  const small = card.type === 'calc'
  return (
    <div ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition, gridColumn: `span ${card.w || 1}` }} className={cx('card flex flex-col p-4', isDragging && 'z-10 opacity-70 shadow-2xl')}>
      <div className="group mb-2 flex items-center gap-2">
        <span {...attributes} {...listeners} className="cursor-grab text-zinc-300 hover:text-zinc-500"><GripVertical size={14} /></span>
        <T.icon size={14} className="text-zinc-400" />
        <span className="flex-1 truncate font-semibold">{card.title}</span>
        <button className="hidden text-zinc-400 hover:text-accent group-hover:block" onClick={() => setEdit(true)}><Settings2 size={14} /></button>
        <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={() => s.removeCard(dashId, card.id)}><Trash2 size={14} /></button>
      </div>
      <div className={small ? 'h-24' : 'h-60'}><CardBody card={card} /></div>
      {edit && <CardEditor card={card} onClose={() => setEdit(false)} onSave={(c) => { s.updateCard(dashId, card.id, c); setEdit(false) }} />}
    </div>
  )
}

export default function DashboardsPage() {
  const s = useStore()
  const dash = s.dashboards.find((d) => d.id === s.route.dashId) || s.dashboards[0]
  const [adding, setAdding] = useState(false)
  const [confirm, setConfirm] = useState(false)
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }))
  if (!dash) {
    return <Empty icon={LayoutDashboard} title="Nenhum dashboard" text="Dashboards reúnem gráficos e números de qualquer parte do workspace."><button className="btn btn-primary" onClick={() => s.navigate({ page: 'dashboards', dashId: s.addDashboard('Meu dashboard') })}><Plus size={14} />Criar dashboard</button></Empty>
  }
  const onDragEnd = ({ active, over }) => {
    if (!over || active.id === over.id) return
    const from = dash.cards.findIndex((c) => c.id === active.id), to = dash.cards.findIndex((c) => c.id === over.id)
    s.setCards(dash.id, arrayMove(dash.cards, from, to))
  }
  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6">
        <div className="mb-4 flex items-center gap-2">
          <select className="input !w-auto !text-[16px] !font-bold" value={dash.id} onChange={(e) => s.navigate({ page: 'dashboards', dashId: e.target.value })}>{s.dashboards.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
          <button className="btn btn-ghost !p-1" title="Renomear" onClick={() => { const n = prompt('Nome do dashboard', dash.name); if (n) s.updateDashboard(dash.id, { name: n }) }}><Pencil size={14} /></button>
          <button className="btn btn-ghost !p-1 text-red-500" title="Excluir" onClick={() => setConfirm(true)}><Trash2 size={14} /></button>
          <div className="flex-1" />
          <button className="btn btn-outline" onClick={() => s.navigate({ page: 'dashboards', dashId: s.addDashboard('Novo dashboard') })}><Plus size={14} />Dashboard</button>
          <Popover align="end" open={adding} onOpenChange={setAdding} trigger={<button className="btn btn-primary"><Plus size={14} />Adicionar card</button>}>
            <div className="menu w-64">{Object.entries(CARD_TYPES).map(([k, t]) => <button key={k} className="menu-item" onClick={() => { s.addCard(dash.id, { type: k, title: t.label, w: t.w, config: { scope: { locType: 'everything' }, metric: 'count' } }); setAdding(false) }}><t.icon size={14} className="text-accent" />{t.label}</button>)}</div>
          </Popover>
        </div>
        {!dash.cards.length && <Empty icon={LayoutDashboard} title="Dashboard vazio" text="Adicione cards de cálculo, gráficos, listas de tarefas, metas e notas." />}
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
          <SortableContext items={dash.cards.map((c) => c.id)} strategy={rectSortingStrategy}>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">{dash.cards.map((c) => <SortableCard key={c.id} card={c} dashId={dash.id} />)}</div>
          </SortableContext>
        </DndContext>
      </div>
      <Confirm open={confirm} onClose={() => setConfirm(false)} onConfirm={() => s.deleteDashboard(dash.id)} title={`Excluir o dashboard "${dash.name}"?`} />
    </div>
  )
}
