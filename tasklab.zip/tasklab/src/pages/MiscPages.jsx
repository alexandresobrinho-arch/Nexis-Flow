import React, { useState } from 'react'
import { LayoutTemplate, Trash2, RotateCcw, Archive, CheckSquare, List as ListIcon, Plus } from 'lucide-react'
import { useStore } from '../store/store'
import { Empty, Tabs, StatusDot, Confirm } from '../components/ui'
import { taskStatus, taskPath, getList } from '../lib/selectors'
import { fmtRelative } from '../lib/utils'

export function TemplatesPage() {
  const s = useStore()
  const [tab, setTab] = useState('task')
  const [target, setTarget] = useState({})
  const list = s.templates.filter((t) => t.kind === tab)
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-4xl p-6">
        <h1 className="text-xl font-bold">Templates</h1>
        <p className="mt-1 text-zinc-500">Salve tarefas (com subtarefas e checklists) ou listas inteiras (status, campos e tarefas) para reutilizar. Crie pelo menu “…” de uma tarefa ou lista.</p>
        <div className="mt-4"><Tabs value={tab} onChange={setTab} tabs={[['task', 'Tarefas', s.templates.filter((t) => t.kind === 'task').length], ['list', 'Listas', s.templates.filter((t) => t.kind === 'list').length]]} /></div>
        {!list.length && <Empty icon={LayoutTemplate} title="Nenhum template" />}
        <div className="mt-3 space-y-2">
          {list.map((t) => (
            <div key={t.id} className="card flex items-center gap-3 p-4">
              {tab === 'task' ? <CheckSquare size={18} className="text-accent" /> : <ListIcon size={18} className="text-accent" />}
              <div className="min-w-0 flex-1">
                <div className="font-semibold">{t.name}</div>
                <div className="text-[12px] text-zinc-500">
                  {tab === 'task' ? `${t.data.subtasks?.length || 0} subtarefas · ${(t.data.checklists || []).reduce((a, c) => a + c.items.length, 0)} itens de checklist` : `${t.data.tasks.length} tarefas · ${t.data.statuses.length} status · ${t.data.fields.length} campos`}
                  {' · '}criado {fmtRelative(t.createdAt)}
                </div>
              </div>
              {tab === 'task' ? (
                <select className="input !w-48" value={target[t.id] || ''} onChange={(e) => setTarget({ ...target, [t.id]: e.target.value })}>
                  <option value="">Escolha a lista…</option>{s.lists.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
              ) : (
                <select className="input !w-48" value={target[t.id] || ''} onChange={(e) => setTarget({ ...target, [t.id]: e.target.value })}>
                  <option value="">Escolha o Space…</option>{s.spaces.map((sp) => <option key={sp.id} value={sp.id}>{sp.name}</option>)}
                </select>
              )}
              <button className="btn btn-primary" disabled={!target[t.id]} onClick={() => {
                if (tab === 'task') { const id = s.createTaskFromTemplate(t.id, target[t.id]); s.openTask(id) }
                else { const id = s.createListFromTemplate(t.id, target[t.id], null); s.navigate({ page: 'location', locType: 'list', locId: id }) }
              }}><Plus size={14} />Usar</button>
              <button className="btn btn-ghost !p-1.5 text-red-500" onClick={() => s.deleteTemplate(t.id)}><Trash2 size={14} /></button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export function TrashPage() {
  const s = useStore()
  const [tab, setTab] = useState('trash')
  const [confirm, setConfirm] = useState(false)
  const deleted = s.tasks.filter((t) => t.deletedAt && !(t.parentId && s.tasks.find((p) => p.id === t.parentId)?.deletedAt)).sort((a, b) => b.deletedAt - a.deletedAt)
  const archived = s.tasks.filter((t) => t.archived && !t.deletedAt)
  const list = tab === 'trash' ? deleted : archived
  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-4xl p-6">
        <div className="flex items-center"><h1 className="text-xl font-bold">Lixeira e arquivo</h1><div className="flex-1" />{tab === 'trash' && deleted.length > 0 && <button className="btn btn-danger" onClick={() => setConfirm(true)}><Trash2 size={14} />Esvaziar lixeira</button>}</div>
        <div className="mt-4"><Tabs value={tab} onChange={setTab} tabs={[['trash', 'Lixeira', deleted.length], ['archived', 'Arquivadas', archived.length]]} /></div>
        {!list.length && <Empty icon={tab === 'trash' ? Trash2 : Archive} title={tab === 'trash' ? 'Lixeira vazia' : 'Nada arquivado'} />}
        <div className="mt-2">
          {list.map((t) => (
            <div key={t.id} className="flex items-center gap-3 border-b border-zinc-100 py-2.5 dark:border-zinc-800">
              <StatusDot status={taskStatus(s, t)} size={9} />
              <div className="min-w-0 flex-1"><div className="truncate font-medium">{t.name}</div><div className="text-[11px] text-zinc-400">{getList(s, t.listId) ? taskPath(s, t) : 'lista excluída'}{t.deletedAt && ` · excluída ${fmtRelative(t.deletedAt)}`}</div></div>
              {tab === 'trash' ? (
                <>
                  <button className="btn btn-outline" disabled={!getList(s, t.listId)} onClick={() => s.restoreTask(t.id)}><RotateCcw size={13} />Restaurar</button>
                  <button className="btn btn-ghost !p-1.5 text-red-500" title="Excluir para sempre" onClick={() => s.purgeTask(t.id)}><Trash2 size={14} /></button>
                </>
              ) : (
                <>
                  <button className="btn btn-ghost" onClick={() => s.openTask(t.id)}>Abrir</button>
                  <button className="btn btn-outline" onClick={() => s.updateTask(t.id, { archived: false })}><RotateCcw size={13} />Desarquivar</button>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
      <Confirm open={confirm} onClose={() => setConfirm(false)} onConfirm={s.emptyTrash} title="Esvaziar a lixeira?" text="As tarefas serão apagadas para sempre." />
    </div>
  )
}
