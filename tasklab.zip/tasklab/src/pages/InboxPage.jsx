import React, { useState } from 'react'
import { Check, CheckCheck, Clock, X, Inbox as InboxIcon, AtSign, UserPlus, MessageSquare, CircleDot, Zap, Unlock, RotateCcw } from 'lucide-react'
import { useStore } from '../store/store'
import { Avatar, StatusDot, Tabs, Empty } from '../components/ui'
import { getTask, taskStatus, taskPath } from '../lib/selectors'
import { memberName } from '../lib/actions'
import { fmtRelative, cx } from '../lib/utils'

const KIND = { mention: [AtSign, 'Menções', 'text-accent'], assign: [UserPlus, 'Atribuições', 'text-emerald-500'], comment: [MessageSquare, 'Comentários', 'text-sky-500'], status: [CircleDot, 'Status', 'text-amber-500'], automation: [Zap, 'Automações', 'text-violet-500'], unblocked: [Unlock, 'Desbloqueios', 'text-emerald-500'] }

export default function InboxPage() {
  const s = useStore()
  const [tab, setTab] = useState('primary')
  const [kind, setKind] = useState('all')
  const mine = s.notifications.filter((n) => n.userId === s.currentUserId)
  const filtered = mine.filter((n) => {
    if (kind !== 'all' && n.kind !== kind) return false
    if (tab === 'primary') return !n.cleared && !n.later
    if (tab === 'unread') return !n.cleared && !n.read
    if (tab === 'later') return n.later && !n.cleared
    return n.cleared
  }).sort((a, b) => b.createdAt - a.createdAt)
  // agrupa por tarefa (igual ao ClickUp)
  const groups = []
  filtered.forEach((n) => { let g = groups.find((x) => x.taskId === n.taskId); if (!g) groups.push((g = { taskId: n.taskId, items: [] })); g.items.push(n) })
  const count = (f) => mine.filter(f).length
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-6 pt-5">
        <h1 className="text-xl font-bold">Caixa de entrada</h1>
        <div className="flex-1" />
        <select className="input !w-auto" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="all">Todos os tipos</option>
          {Object.entries(KIND).map(([k, [, l]]) => <option key={k} value={k}>{l}</option>)}
        </select>
        <button className="btn btn-outline" onClick={s.markAllRead}><CheckCheck size={14} />Marcar tudo como lido</button>
        <button className="btn btn-outline" onClick={s.clearAllNotifs}><X size={14} />Limpar tudo</button>
      </div>
      <div className="px-6"><Tabs value={tab} onChange={setTab} tabs={[
        ['primary', 'Principal', count((n) => !n.cleared && !n.later && !n.read)], ['unread', 'Não lidas', count((n) => !n.cleared && !n.read)],
        ['later', 'Mais tarde', count((n) => n.later && !n.cleared)], ['cleared', 'Limpas'],
      ]} /></div>
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {!groups.length && <Empty icon={InboxIcon} title="Caixa zerada" text="Notificações de menções, atribuições, comentários e mudanças em tarefas que você segue aparecem aqui." />}
        <div className="mx-auto max-w-3xl space-y-3">
          {groups.map((g) => {
            const t = getTask(s, g.taskId)
            const unread = g.items.some((n) => !n.read)
            return (
              <div key={g.taskId} className={cx('card overflow-hidden', unread && 'border-l-4 border-l-accent')}>
                <button className="flex w-full items-center gap-2 border-b border-zinc-100 px-4 py-2.5 text-left hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-800/40" onClick={() => { if (t) { s.openTask(t.id); g.items.forEach((n) => s.markNotif(n.id, { read: true })) } }}>
                  {t && <StatusDot status={taskStatus(s, t)} size={9} />}
                  <span className="flex-1 truncate font-semibold">{t?.name || 'Tarefa removida'}</span>
                  {t && <span className="truncate text-[11px] text-zinc-400">{taskPath(s, t)}</span>}
                </button>
                {g.items.map((n) => {
                  const [I, , color] = KIND[n.kind] || KIND.comment
                  return (
                    <div key={n.id} className="group flex items-center gap-3 px-4 py-2 hover:bg-zinc-50 dark:hover:bg-zinc-800/40">
                      <span className="relative"><Avatar userId={n.actorId} size={26} /><I size={12} className={cx('absolute -bottom-1 -right-1 rounded-full bg-white p-px dark:bg-zinc-900', color)} /></span>
                      <div className="min-w-0 flex-1">
                        <span className="font-medium">{memberName(n.actorId)}</span> <span className="text-zinc-600 dark:text-zinc-300">{n.text}</span>
                        <div className="text-[11px] text-zinc-400">{fmtRelative(n.createdAt)}</div>
                      </div>
                      {!n.read && <span className="h-2 w-2 rounded-full bg-accent" />}
                      <div className="hidden gap-1 group-hover:flex">
                        <button title={n.read ? 'Marcar como não lida' : 'Marcar como lida'} className="btn btn-ghost !p-1" onClick={() => s.markNotif(n.id, { read: !n.read })}><Check size={14} /></button>
                        {!n.cleared && <button title="Mais tarde" className={cx('btn btn-ghost !p-1', n.later && 'text-accent')} onClick={() => s.markNotif(n.id, { later: !n.later })}><Clock size={14} /></button>}
                        {n.cleared ? <button title="Restaurar" className="btn btn-ghost !p-1" onClick={() => s.markNotif(n.id, { cleared: false })}><RotateCcw size={14} /></button>
                          : <button title="Limpar" className="btn btn-ghost !p-1" onClick={() => s.markNotif(n.id, { cleared: true, read: true })}><X size={14} /></button>}
                      </div>
                    </div>
                  )
                })}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
