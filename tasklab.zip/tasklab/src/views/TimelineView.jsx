import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Crosshair } from 'lucide-react'
import { addDays, format, parseISO, isWeekend } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { Avatar } from '../components/ui'
import { groupTasks, patchForGroup } from '../lib/query'
import { taskStatus, isClosed, getTask } from '../lib/selectors'
import { dayStr, daysBetween, todayStr, cx } from '../lib/utils'
import { addDaysStr } from './shared'

const LANE = 30
const LEFT = 200
const ZOOMS = { day: 40, week: 18, month: 6 }

// distribui barras em faixas sem sobreposição
function lanes(items) {
  const ends = []
  return items.map((it) => {
    let lane = ends.findIndex((e) => e < it.st)
    if (lane < 0) { lane = ends.length; ends.push(it.du) } else ends[lane] = it.du
    return { ...it, lane }
  }).map((x, _, arr) => ({ ...x, laneCount: Math.max(...arr.map((y) => y.lane)) + 1 }))
}

export default function TimelineView({ tasks, config, update, locType, locId }) {
  const s = useStore()
  const zoom = config.ganttZoom || 'day'
  const W = ZOOMS[zoom]
  const groupBy = config.groupBy && config.groupBy !== 'status' ? config.groupBy : 'assignee'
  const scroller = useRef(null)
  const [drag, setDrag] = useState(null)
  const dragRef = useRef(null)
  dragRef.current = drag
  const groups = groupTasks(s, tasks.filter((t) => t.dueDate || t.startDate), groupBy, locType, locId, { includeEmpty: groupBy === 'assignee' })
  if (groupBy === 'assignee') s.members.forEach((m) => { if (!groups.some((g) => g.key === m.id)) groups.push({ key: m.id, label: m.name, color: m.color, tasks: [], meta: { assignee: m.id } }) })
  const range = useMemo(() => {
    let min = dayStr(addDays(new Date(), -7)), max = dayStr(addDays(new Date(), 35))
    tasks.forEach((t) => [t.startDate, t.dueDate].forEach((d) => { if (d && d < min) min = d; if (d && d > max) max = d }))
    const start = addDaysStr(min, -3)
    return { start, days: daysBetween(start, addDaysStr(max, 10)) + 1 }
  }, [tasks])
  const xOf = (d) => daysBetween(range.start, d) * W
  const totalW = range.days * W
  useEffect(() => { if (scroller.current) scroller.current.scrollLeft = Math.max(0, xOf(todayStr()) - 200) }, [zoom])

  useEffect(() => {
    if (!drag) return
    const move = (e) => setDrag((d) => d && { ...d, delta: Math.round((e.clientX - d.x0) / W) })
    const up = (e) => {
      const d = dragRef.current
      setDrag(null)
      if (!d) return
      const t = getTask(s, d.taskId)
      if (!t) return
      const patch = {}
      if (d.delta) {
        const st = t.startDate || t.dueDate, du = t.dueDate || t.startDate
        patch.startDate = t.startDate ? addDaysStr(st, d.delta) : null
        patch.dueDate = addDaysStr(du, d.delta)
      }
      const el = document.elementFromPoint(e.clientX, e.clientY)?.closest('[data-tl-group]')
      const gk = el?.getAttribute('data-tl-group')
      if (gk && gk !== d.groupKey) {
        const g = groups.find((x) => x.key === gk)
        if (groupBy === 'assignee' && g) {
          patch.assignees = [...t.assignees.filter((a) => a !== d.groupKey), ...(g.meta.assignee && !t.assignees.includes(g.meta.assignee) ? [g.meta.assignee] : [])]
        } else if (g) Object.assign(patch, patchForGroup(s, t, groupBy, g) || {})
      }
      if (Object.keys(patch).length) s.updateTask(t.id, patch)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up, { once: true })
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up) }
  }, [!!drag])

  const days = Array.from({ length: range.days }, (_, i) => addDays(parseISO(range.start), i))
  const todayX = xOf(todayStr())
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-2">
        <div className="flex rounded-md border border-zinc-200 p-0.5 dark:border-zinc-700">
          {[['day', 'Dia'], ['week', 'Semana'], ['month', 'Mês']].map(([k, l]) => <button key={k} onClick={() => update({ ganttZoom: k })} className={cx('rounded px-2 py-0.5', zoom === k && 'bg-zinc-100 font-semibold dark:bg-zinc-800')}>{l}</button>)}
        </div>
        <button className="btn btn-outline !py-1" onClick={() => { scroller.current.scrollLeft = Math.max(0, todayX - 200) }}><Crosshair size={13} />Hoje</button>
        <span className="text-[11px] text-zinc-400">Arraste na horizontal para reagendar e entre linhas para reatribuir. Agrupado por: {groupBy === 'assignee' ? 'responsável' : groupBy}</span>
      </div>
      <div ref={scroller} className="flex-1 overflow-auto border-t border-zinc-200 dark:border-zinc-800">
        <div style={{ width: LEFT + totalW }} className="relative select-none">
          <div className="sticky top-0 z-20 flex bg-white dark:bg-zinc-950">
            <div className="sticky left-0 z-30 border-b border-r border-zinc-200 bg-white dark:border-zinc-800 dark:bg-zinc-950" style={{ width: LEFT, minWidth: LEFT, height: 40 }} />
            <div className="relative border-b border-zinc-200 dark:border-zinc-800" style={{ width: totalW, height: 40 }}>
              {days.map((d, i) => (zoom === 'day' || (zoom === 'week' && d.getDay() === 1) || (zoom === 'month' && d.getDate() === 1)) && (
                <div key={i} className={cx('absolute bottom-1 text-center text-[10px]', dayStr(d) === todayStr() ? 'font-bold text-accent' : 'text-zinc-400')} style={{ left: i * W, width: zoom === 'day' ? W : W * 7 }}>
                  {zoom === 'day' ? <>{format(d, 'EEE', { locale: ptBR })}<br />{format(d, 'd/MM')}</> : format(d, 'd MMM', { locale: ptBR })}
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="pointer-events-none absolute top-0 bottom-0" style={{ left: LEFT, width: totalW }}>
              {zoom !== 'month' && days.map((d, i) => isWeekend(d) && <div key={i} className="absolute top-0 bottom-0 bg-zinc-50 dark:bg-zinc-900/50" style={{ left: i * W, width: W }} />)}
              <div className="absolute top-0 bottom-0 z-10 w-0.5 bg-accent" style={{ left: todayX + W / 2 }} />
            </div>
            {groups.map((g) => {
              const items = lanes(g.tasks.map((t) => {
                let st = t.startDate || t.dueDate, du = t.dueDate || t.startDate
                if (drag?.taskId === t.id && drag.delta) { st = addDaysStr(st, drag.delta); du = addDaysStr(du, drag.delta) }
                return { t, st, du }
              }).sort((a, b) => a.st.localeCompare(b.st)))
              const h = Math.max(1, items[0]?.laneCount || 1) * LANE + 12
              return (
                <div key={g.key} className="relative flex" style={{ height: h }}>
                  <div className="sticky left-0 z-10 flex items-center gap-2 border-b border-r border-zinc-200 bg-white px-3 dark:border-zinc-800 dark:bg-zinc-950" style={{ width: LEFT, minWidth: LEFT }}>
                    {groupBy === 'assignee' && g.meta?.assignee ? <Avatar userId={g.key} size={22} /> : <span className="h-2.5 w-2.5 rounded-full" style={{ background: g.color }} />}
                    <span className="truncate font-medium">{g.label}</span><span className="text-[11px] text-zinc-400">{g.tasks.length}</span>
                  </div>
                  <div data-tl-group={g.key} className="relative border-b border-zinc-200 dark:border-zinc-800" style={{ width: totalW }}>
                    {items.map(({ t, st, du, lane }) => {
                      const sts = taskStatus(s, t)
                      return (
                        <div key={t.id} onPointerDown={(e) => { e.preventDefault(); setDrag({ taskId: t.id, groupKey: g.key, x0: e.clientX, delta: 0 }) }} onDoubleClick={() => s.openTask(t.id)}
                          title={`${t.name} — duplo clique para abrir`}
                          className={cx('absolute flex h-[24px] cursor-grab items-center gap-1 overflow-hidden rounded-md px-2 text-[11px] font-medium text-white shadow-sm', isClosed(s, t) && 'opacity-60', drag?.taskId === t.id && 'ring-2 ring-accent/60')}
                          style={{ left: xOf(st) + 1, width: Math.max((daysBetween(st, du) + 1) * W - 2, 10), top: 6 + lane * LANE, background: sts.color }}>
                          <span className="truncate">{t.name}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
