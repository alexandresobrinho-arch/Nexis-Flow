import React, { useState } from 'react'
import { DndContext, PointerSensor, useSensor, useSensors, useDraggable, useDroppable, DragOverlay } from '@dnd-kit/core'
import { ChevronRight, GripVertical, Plus, MoreHorizontal } from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, StatusDot, StatusMenu, Icon } from '../components/ui'
import { Cell, columnLabel, columnWidth } from '../components/TaskCells'
import { groupTasks, patchForGroup, applyFilters } from '../lib/query'
import { taskStatus, subtasksOf, isClosed } from '../lib/selectors'
import { setStatus } from '../lib/actions'
import { cx } from '../lib/utils'
import { defaultListFor, newTaskInGroup, TaskBadges, orderBetween } from './shared'

function Row({ task, depth, groupKey, cols, config, expanded, toggle, selected, setSelected, anySelected }) {
  const s = useStore()
  const st = taskStatus(s, task)
  const subs = config.subtasks === 'separate' ? [] : applyFilters(s, subtasksOf(s, task.id), { ...config, filters: { rules: [] }, me: false }, s.currentUserId).sort((a, b) => a.order - b.order)
  const open = config.subtasks === 'expanded' ? expanded[task.id] !== false : !!expanded[task.id]
  const drag = useDraggable({ id: `drag:${task.id}:${groupKey}`, data: { taskId: task.id, groupKey } })
  const drop = useDroppable({ id: `row:${task.id}:${groupKey}`, data: { taskId: task.id, groupKey } })
  const type = s.taskTypes.find((x) => x.id === task.typeId)
  const isSel = selected.has(task.id)
  return (
    <>
      <div ref={drop.setNodeRef} className={cx('group flex items-center border-b border-zinc-100 hover:bg-zinc-50 dark:border-zinc-800/70 dark:hover:bg-zinc-900', isSel && '!bg-accent-50 dark:!bg-accent/10', drag.isDragging && 'opacity-40', drop.isOver && 'border-t-2 border-t-accent')}>
        <div className="flex min-w-[340px] flex-1 items-center gap-1.5 py-1.5 pr-2" style={{ paddingLeft: 6 + depth * 22 }}>
          <span ref={drag.setNodeRef} {...drag.listeners} {...drag.attributes} className="cursor-grab text-zinc-300 opacity-0 group-hover:opacity-100"><GripVertical size={14} /></span>
          <input type="checkbox" checked={isSel} onChange={() => setSelected((x) => { const n = new Set(x); n.has(task.id) ? n.delete(task.id) : n.add(task.id); return n })} className={cx('h-3.5 w-3.5 accent-[#6d5dfc]', !anySelected && 'opacity-0 group-hover:opacity-100')} />
          {subs.length > 0 ? (
            <button onClick={() => toggle(task.id, !open)} className="rounded p-0.5 text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700"><ChevronRight size={13} className={cx('transition-transform', open && 'rotate-90')} /></button>
          ) : <span className="w-[17px]" />}
          <Popover trigger={<button><StatusDot status={st} /></button>}>{(c) => <StatusMenu listId={task.listId} value={task.statusId} onChange={(id) => setStatus(task.id, id)} close={c} />}</Popover>
          {type && type.id !== 'task' && <Icon name={type.icon} size={13} style={{ color: type.color }} />}
          <button onClick={() => s.openTask(task.id)} className={cx('truncate text-left font-medium hover:text-accent', isClosed(s, task) && 'text-zinc-400 line-through')}>{task.name}</button>
          <TaskBadges task={task} />
        </div>
        {cols.map((c) => <div key={c} className="shrink-0 truncate px-2 py-1" style={{ width: columnWidth(s, c) }}><Cell task={task} col={c} /></div>)}
        <div className="w-8" />
      </div>
      {open && subs.map((sub) => <Row key={sub.id} task={sub} depth={depth + 1} groupKey={groupKey} cols={cols} config={config} expanded={expanded} toggle={toggle} selected={selected} setSelected={setSelected} anySelected={anySelected} />)}
    </>
  )
}

function Group({ group, children, config, cols, locType, locId, collapsed, setCollapsed }) {
  const s = useStore()
  const drop = useDroppable({ id: `group:${group.key}`, data: { groupKey: group.key } })
  const [adding, setAdding] = useState(false)
  const [name, setName] = useState('')
  const create = () => {
    if (!name.trim()) return
    const listId = defaultListFor(s, locType, locId)
    s.createTask({ name, ...newTaskInGroup(s, listId, config.groupBy, group) })
    setName('')
  }
  return (
    <div ref={drop.setNodeRef} className={cx('mb-4', drop.isOver && 'rounded-lg ring-2 ring-accent/40')}>
      <div className="sticky top-0 z-[5] flex items-center gap-2 bg-white py-2 dark:bg-zinc-950">
        <button onClick={() => setCollapsed(!collapsed)} className="text-zinc-400"><ChevronRight size={14} className={cx('transition-transform', !collapsed && 'rotate-90')} /></button>
        <span className="rounded px-2 py-0.5 text-[11px] font-bold uppercase text-white" style={{ background: group.color || '#a1a1aa' }}>{group.label}</span>
        <span className="text-zinc-400">{group.tasks.length}</span>
        <button onClick={() => setAdding(true)} className="ml-1 text-zinc-400 hover:text-accent"><Plus size={14} /></button>
      </div>
      {!collapsed && (
        <div>
          <div className="flex border-b border-zinc-200 text-[11px] font-medium text-zinc-400 dark:border-zinc-800">
            <div className="min-w-[340px] flex-1 py-1 pl-14">Nome</div>
            {cols.map((c) => <div key={c} className="shrink-0 truncate px-2 py-1" style={{ width: columnWidth(s, c) }}>{columnLabel(s, c)}</div>)}
            <div className="w-8" />
          </div>
          {children}
          {adding ? (
            <div className="flex items-center gap-2 border-b border-zinc-100 py-1.5 pl-14 dark:border-zinc-800">
              <input autoFocus className="flex-1 bg-transparent outline-none" placeholder="Nome da tarefa — Enter para salvar, Esc para sair" value={name} onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') create(); if (e.key === 'Escape') setAdding(false) }} onBlur={() => !name && setAdding(false)} />
              <button className="btn btn-primary !py-0.5" onMouseDown={(e) => { e.preventDefault(); create() }}>Salvar</button>
            </div>
          ) : (
            <button onClick={() => setAdding(true)} className="flex w-full items-center gap-2 py-1.5 pl-14 text-zinc-400 hover:text-accent"><Plus size={13} />Nova tarefa</button>
          )}
        </div>
      )}
    </div>
  )
}

export default function ListView({ tasks, config, locType, locId, selected, setSelected }) {
  const s = useStore()
  const cols = config.columns || []
  const groups = groupTasks(s, tasks, config.groupBy, locType, locId, { includeEmpty: true, showClosedGroups: config.showClosed })
  const [collapsed, setCollapsed] = useState({})
  const [expanded, setExpanded] = useState({})
  const [active, setActive] = useState(null)
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }))
  const manual = !config.sorts?.length

  const onDragEnd = ({ active: a, over }) => {
    setActive(null)
    if (!over) return
    const { taskId, groupKey } = a.data.current
    const task = s.tasks.find((t) => t.id === taskId)
    const target = over.data.current
    const targetGroup = groups.find((g) => g.key === target.groupKey)
    if (!task || !targetGroup) return
    if (target.groupKey !== groupKey) {
      const patch = patchForGroup(s, task, config.groupBy, targetGroup)
      if (patch) {
        if (config.groupBy === 'status') setStatus(task.id, patch.statusId)
        else s.updateTask(task.id, patch)
      }
    }
    if (manual && target.taskId && target.taskId !== taskId) {
      const list = targetGroup.tasks.filter((t) => t.id !== taskId)
      const idx = list.findIndex((t) => t.id === target.taskId)
      s.reorderTask(taskId, orderBetween(list[idx - 1]?.order, list[idx]?.order))
    }
  }

  const activeTask = active && s.tasks.find((t) => t.id === active)
  return (
    <DndContext sensors={sensors} onDragStart={(e) => setActive(e.active.data.current.taskId)} onDragEnd={onDragEnd} onDragCancel={() => setActive(null)}>
      <div className="h-full overflow-auto px-4 pt-2">
        <div className="min-w-fit">
          {groups.map((g) => (
            <Group key={g.key} group={g} config={config} cols={cols} locType={locType} locId={locId} collapsed={collapsed[g.key]} setCollapsed={(v) => setCollapsed({ ...collapsed, [g.key]: v })}>
              {g.tasks.map((t) => (
                <Row key={t.id} task={t} depth={0} groupKey={g.key} cols={cols} config={config} expanded={expanded} toggle={(id, v) => setExpanded({ ...expanded, [id]: v })}
                  selected={selected} setSelected={setSelected} anySelected={selected.size > 0} />
              ))}
            </Group>
          ))}
        </div>
      </div>
      <DragOverlay>{activeTask && <div className="card px-3 py-2 font-medium shadow-xl">{activeTask.name}</div>}</DragOverlay>
    </DndContext>
  )
}
