import React, { useEffect, useMemo, useRef, useState } from 'react'
import { ChevronRight, Diamond, Plus, Crosshair } from 'lucide-react'
import { addDays, format, parseISO, startOfMonth, isWeekend } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { StatusDot, AvatarStack } from '../components/ui'
import { taskStatus, subtasksOf, isClosed, getList, progressOf, getTask } from '../lib/selectors'
import { applyFilters } from '../lib/query'
import { dayStr, daysBetween, todayStr, cx } from '../lib/utils'
import { addDaysStr } from './shared'

const ROW = 36
const LEFT = 340
const ZOOMS = { day: 36, week: 16, month: 5 }

export default function GanttView({ tasks, config, update, locType }) {
  const s = useStore()
  const zoom = config.ganttZoom || 'day'
  const W = ZOOMS[zoom]
  const scroller = useRef(null)
  const [expanded, setExpanded] = useState({})
  const [drag, setDrag] = useState(null) // {taskId, mode, x0, delta, px, py}
  const dragRef = useRef(null)
  dragRef.current = drag

  // linhas: agrupadas por lista (quando a localização tem várias) + subtarefas
  const rows = useMemo(() => {
    const out = []
    const byList = {}
    tasks.forEach((t) => { (byList[t.listId] ||= []).push(t) })
    const sorted = (arr) => (config.sorts?.length ? arr : [...arr].sort((a, b) => (a.startDate || a.dueDate || '9999').localeCompare(b.startDate || b.dueDate || '9999')))
    const pushTask = (t, depth) => {
      const subs = applyFilters(s, subtasksOf(s, t.id), { ...config, filters: { rules: [] }, me: false }, s.currentUserId)
      out.push({ type: 'task', task: t, depth, hasSubs: subs.length > 0 })
      if (expanded[t.id]) sorted(subs).forEach((x) => pushTask(x, depth + 1))
    }
    Object.entries(byList).forEach(([lid, arr]) => {
      if (locType !== 'list') out.push({ type: 'group', label: getList(s, lid)?.name, color: getList(s, lid)?.color })
      sorted(arr).forEach((t) => pushTask(t, 0))
    })
    return out
  }, [tasks, expanded, s, config, locType])

  // intervalo do gráfico
  const range = useMemo(() => {
    let min = dayStr(addDays(new Date(), -14)), max = dayStr(addDays(new Date(), 45))
    rows.forEach((r) => { if (r.type !== 'task') return; const t = r.task; [t.startDate, t.dueDate].forEach((d) => { if (d && d < min) min = d; if (d && d > max) max = d }) })
    const start = addDaysStr(min, -7)
    const end = addDaysStr(max, 21)
    return { start, days: daysBetween(start, end) + 1 }
  }, [rows])
  const xOf = (day) => daysBetween(range.start, day) * W
  const totalW = range.days * W

  useEffect(() => { if (scroller.current) scroller.current.scrollLeft = Math.max(0, xOf(todayStr()) - 300) }, [zoom])

  // drag global
  useEffect(() => {
    if (!drag) return
    const move = (e) => setDrag((d) => d && { ...d, delta: Math.round((e.clientX - d.x0) / W), px: e.clientX, py: e.clientY })
    const up = (e) => {
      const d = dragRef.current
      setDrag(null)
      if (!d) return
      const t = getTask(s, d.taskId)
      if (d.mode === 'link') {
        const el = document.elementFromPoint(e.clientX, e.clientY)?.closest('[data-gantt-task]')
        const target = el?.getAttribute('data-gantt-task')
        if (target && target !== d.taskId) s.addDependency(target, d.taskId)
        return
      }
      if (!d.delta || !t) return
      const st = t.startDate || t.dueDate
      const du = t.dueDate || t.startDate
      if (d.mode === 'move') s.updateTask(t.id, { startDate: addDaysStr(st, d.delta), dueDate: addDaysStr(du, d.delta) })
      if (d.mode === 'left') { const ns = addDaysStr(st, d.delta); s.updateTask(t.id, { startDate: ns > du ? du : ns }) }
      if (d.mode === 'right') { const nd = addDaysStr(du, d.delta); s.updateTask(t.id, { dueDate: nd < st ? st : nd }) }
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up, { once: true })
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up) }
  }, [!!drag])

  const geom = (t) => {
    let st = t.startDate || t.dueDate, du = t.dueDate || t.startDate
    if (!st) return null
    if (drag?.taskId === t.id && drag.delta) {
      if (drag.mode === 'move') { st = addDaysStr(st, drag.delta); du = addDaysStr(du, drag.delta) }
      if (drag.mode === 'left') st = addDaysStr(st, drag.delta) > du ? du : addDaysStr(st, drag.delta)
      if (drag.mode === 'right') du = addDaysStr(du, drag.delta) < st ? st : addDaysStr(du, drag.delta)
    }
    return { x: xOf(st), w: (daysBetween(st, du) + 1) * W, st, du }
  }

  // posições para setas de dependência
  const pos = {}
  rows.forEach((r, i) => { if (r.type === 'task') { const g = geom(r.task); if (g) pos[r.task.id] = { ...g, y: i * ROW + ROW / 2 } } })
  const arrows = []
  rows.forEach((r) => {
    if (r.type !== 'task') return
    r.task.blockedBy.forEach((b) => {
      const a = pos[b], c = pos[r.task.id]
      if (!a || !c) return
      const bt = getTask(s, b)
      const late = bt?.dueDate && r.task.startDate && bt.dueDate >= r.task.startDate
      arrows.push({ key: b + r.task.id, x1: a.x + a.w, y1: a.y, x2: c.x, y2: c.y, late })
    })
  })

  // cabeçalho
  const header = []
  for (let i = 0; i < range.days; i++) {
    const d = addDays(parseISO(range.start), i)
    header.push(d)
  }
  const months = []
  header.forEach((d, i) => { const k = format(d, 'yyyy-MM'); if (!months.length || months[months.length - 1].k !== k) months.push({ k, label: format(d, 'MMMM yyyy', { locale: ptBR }), i, n: 1 }); else months[months.length - 1].n++ })
  const todayX = xOf(todayStr())

  const setDates = (t) => s.updateTask(t.id, { startDate: todayStr(), dueDate: addDaysStr(todayStr(), 3) })

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-2">
        <div className="flex rounded-md border border-zinc-200 p-0.5 dark:border-zinc-700">
          {[['day', 'Dia'], ['week', 'Semana'], ['month', 'Mês']].map(([k, l]) => <button key={k} onClick={() => update({ ganttZoom: k })} className={cx('rounded px-2 py-0.5', zoom === k && 'bg-zinc-100 font-semibold dark:bg-zinc-800')}>{l}</button>)}
        </div>
        <button className="btn btn-outline !py-1" onClick={() => { scroller.current.scrollLeft = Math.max(0, todayX - 300) }}><Crosshair size={13} />Hoje</button>
        <span className="text-[11px] text-zinc-400">Arraste a barra para mover · bordas para redimensionar · bolinha da direita para criar dependência</span>
      </div>
      <div ref={scroller} className="relative flex-1 overflow-auto border-t border-zinc-200 dark:border-zinc-800">
        <div style={{ width: LEFT + totalW }} className="relative select-none">
          {/* cabeçalho */}
          <div className="sticky top-0 z-20 flex bg-white dark:bg-zinc-950">
            <div className="sticky left-0 z-30 flex items-end border-b border-r border-zinc-200 bg-white px-3 pb-1 font-semibold dark:border-zinc-800 dark:bg-zinc-950" style={{ width: LEFT, minWidth: LEFT, height: 48 }}>Tarefa</div>
            <div className="relative border-b border-zinc-200 dark:border-zinc-800" style={{ width: totalW, height: 48 }}>
              {months.map((m) => <div key={m.k} className="absolute top-0 truncate border-l border-zinc-200 px-2 py-0.5 text-[11px] font-semibold capitalize text-zinc-500 dark:border-zinc-800" style={{ left: m.i * W, width: m.n * W }}>{m.label}</div>)}
              {header.map((d, i) => (zoom === 'day' || (zoom === 'week' && d.getDay() === 1) || (zoom === 'month' && d.getDate() === 1)) && (
                <div key={i} className={cx('absolute bottom-0 text-center text-[10px]', dayStr(d) === todayStr() ? 'font-bold text-accent' : 'text-zinc-400')} style={{ left: i * W, width: zoom === 'day' ? W : W * 7 }}>
                  {zoom === 'day' ? <>{format(d, 'EEEEE', { locale: ptBR })}<br />{format(d, 'd')}</> : format(d, 'd MMM', { locale: ptBR })}
                </div>
              ))}
            </div>
          </div>
          {/* corpo */}
          <div className="relative">
            {/* grade de fundo */}
            <div className="pointer-events-none absolute top-0 bottom-0" style={{ left: LEFT, width: totalW }}>
              {zoom !== 'month' && header.map((d, i) => isWeekend(d) && <div key={i} className="absolute top-0 bottom-0 bg-zinc-50 dark:bg-zinc-900/50" style={{ left: i * W, width: W }} />)}
              <div className="absolute top-0 bottom-0 z-10 w-0.5 bg-accent" style={{ left: todayX + W / 2 }} />
            </div>
            {rows.map((r, i) => r.type === 'group' ? (
              <div key={'g' + i} className="relative flex" style={{ height: ROW }}>
                <div className="sticky left-0 z-10 flex items-center gap-2 border-b border-r border-zinc-200 bg-zinc-50 px-3 text-[12px] font-bold uppercase dark:border-zinc-800 dark:bg-zinc-900" style={{ width: LEFT, minWidth: LEFT, color: r.color }}>{r.label}</div>
                <div className="border-b border-zinc-100 bg-zinc-50/50 dark:border-zinc-800 dark:bg-zinc-900/30" style={{ width: totalW }} />
              </div>
            ) : (
              <GanttRow key={r.task.id} r={r} geom={geom(r.task)} W={W} expanded={expanded} setExpanded={setExpanded} totalW={totalW} setDrag={setDrag} drag={drag} setDates={setDates} />
            ))}
            {/* setas */}
            <svg className="pointer-events-none absolute top-0" style={{ left: LEFT, width: totalW, height: rows.length * ROW }}>
              <defs><marker id="arr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#a1a1aa" /></marker><marker id="arrL" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#ef4444" /></marker></defs>
              {arrows.map((a) => {
                const mid = a.x1 + 10
                const d = a.x2 - 10 > mid ? `M${a.x1},${a.y1} H${mid} V${a.y2} H${a.x2 - 2}` : `M${a.x1},${a.y1} H${mid} V${(a.y1 + a.y2) / 2} H${a.x2 - 14} V${a.y2} H${a.x2 - 2}`
                return <path key={a.key} d={d} fill="none" stroke={a.late ? '#ef4444' : '#a1a1aa'} strokeWidth="1.5" markerEnd={`url(#${a.late ? 'arrL' : 'arr'})`} />
              })}
              {drag?.mode === 'link' && pos[drag.taskId] && scroller.current && (() => {
                const rect = scroller.current.getBoundingClientRect()
                const x2 = drag.px - rect.left + scroller.current.scrollLeft - LEFT
                const y2 = drag.py - rect.top + scroller.current.scrollTop - 48
                const a = pos[drag.taskId]
                return <path d={`M${a.x + a.w + 6},${a.y} L${x2},${y2}`} stroke="#6d5dfc" strokeWidth="2" strokeDasharray="4 3" fill="none" />
              })()}
            </svg>
          </div>
        </div>
      </div>
    </div>
  )
}

function GanttRow({ r, geom, W, expanded, setExpanded, totalW, setDrag, drag, setDates }) {
  const s = useStore()
  const t = r.task
  const st = taskStatus(s, t)
  const closed = isClosed(s, t)
  const prog = closed ? 100 : progressOf(s, t)?.pct || 0
  const milestone = t.typeId === 'milestone'
  const start = (mode) => (e) => { e.stopPropagation(); e.preventDefault(); setDrag({ taskId: t.id, mode, x0: e.clientX, delta: 0, px: e.clientX, py: e.clientY }) }
  return (
    <div className="group relative flex" style={{ height: ROW }}>
      <div className="sticky left-0 z-10 flex items-center gap-1.5 border-b border-r border-zinc-200 bg-white pr-2 group-hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-950 dark:group-hover:bg-zinc-900" style={{ width: LEFT, minWidth: LEFT, paddingLeft: 10 + r.depth * 18 }}>
        {r.hasSubs ? <button onClick={() => setExpanded({ ...expanded, [t.id]: !expanded[t.id] })} className="text-zinc-400"><ChevronRight size={13} className={cx('transition-transform', expanded[t.id] && 'rotate-90')} /></button> : <span className="w-[13px]" />}
        <StatusDot status={st} size={8} />
        <button onClick={() => s.openTask(t.id)} className={cx('flex-1 truncate text-left hover:text-accent', closed && 'text-zinc-400 line-through')}>{t.name}</button>
        <AvatarStack ids={t.assignees} size={18} max={2} />
      </div>
      <div className="relative border-b border-zinc-100 dark:border-zinc-800/60" style={{ width: totalW }} data-gantt-task={t.id}>
        {!geom ? (
          <button onClick={() => setDates(t)} className="absolute top-1.5 hidden items-center gap-1 rounded border border-dashed border-zinc-300 px-2 py-0.5 text-[11px] text-zinc-400 group-hover:flex" style={{ left: 8 }}><Plus size={11} />Definir datas</button>
        ) : milestone ? (
          <div data-gantt-task={t.id} onPointerDown={start('move')} onDoubleClick={() => s.openTask(t.id)} className="absolute top-1/2 flex cursor-grab items-center gap-2" style={{ left: geom.x + W / 2 - 9, transform: 'translateY(-50%)' }}>
            <Diamond size={18} fill="#f59e0b" className="text-amber-500" />
            <span className="whitespace-nowrap text-[12px] font-semibold">{t.name}</span>
          </div>
        ) : (
          <div data-gantt-task={t.id} onDoubleClick={() => s.openTask(t.id)} onPointerDown={start('move')}
            className={cx('absolute top-[7px] flex h-[22px] cursor-grab items-center overflow-visible rounded-md text-[11px] font-medium text-white shadow-sm', drag?.taskId === t.id && 'ring-2 ring-accent/50')}
            style={{ left: geom.x + 1, width: Math.max(geom.w - 2, 8), background: st.color + 'aa' }}>
            <div className="absolute inset-y-0 left-0 rounded-md" style={{ width: `${prog}%`, background: st.color }} />
            <span className="relative z-[1] truncate px-2">{geom.w > 60 ? t.name : ''}</span>
            <span onPointerDown={start('left')} className="absolute inset-y-0 left-0 z-[2] w-2 cursor-ew-resize rounded-l-md hover:bg-black/20" />
            <span onPointerDown={start('right')} className="absolute inset-y-0 right-0 z-[2] w-2 cursor-ew-resize rounded-r-md hover:bg-black/20" />
            <span onPointerDown={start('link')} title="Arraste até outra tarefa para criar dependência" className="absolute -right-4 top-1/2 z-[3] hidden h-3 w-3 -translate-y-1/2 cursor-crosshair rounded-full border-2 border-accent bg-white group-hover:block" />
            {geom.w <= 60 && <span className="absolute left-full z-[1] ml-5 whitespace-nowrap text-zinc-600 dark:text-zinc-300">{t.name}</span>}
          </div>
        )}
      </div>
    </div>
  )
}
