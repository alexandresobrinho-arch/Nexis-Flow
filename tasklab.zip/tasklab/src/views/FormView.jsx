import React, { useState } from 'react'
import { ArrowUp, ArrowDown, Trash2, Plus, ExternalLink, CheckCircle2, Hexagon, Eye } from 'lucide-react'
import { useStore } from '../store/store'
import { Modal, Toggle, StatusDot } from '../components/ui'
import { getFieldsForList, getStatusesForList, listsInLocation } from '../lib/selectors'
import { PRIORITIES, cx } from '../lib/utils'

const BASE_FIELDS = [['name', 'Nome da tarefa'], ['description', 'Descrição'], ['assignee', 'Responsável'], ['priority', 'Prioridade'], ['dueDate', 'Data de entrega'], ['startDate', 'Data de início'], ['tags', 'Tags']]
const DEFAULT_FORM = { title: 'Novo formulário', description: '', submitLabel: 'Enviar', assignee: '', statusId: '', typeId: 'task', fields: [{ key: 'name', label: 'Nome da tarefa', required: true }, { key: 'description', label: 'Descrição', required: false }] }

function FormRenderer({ form, listId, onSubmitted, preview }) {
  const s = useStore()
  const cfs = getFieldsForList(s, listId)
  const [vals, setVals] = useState({})
  const [errors, setErrors] = useState({})
  const [done, setDone] = useState(false)
  const visible = (f) => !f.showIf?.key || String(vals[f.showIf.key] ?? '') === String(f.showIf.value)
  const set = (k, v) => setVals({ ...vals, [k]: v })
  const submit = () => {
    const errs = {}
    form.fields.filter(visible).forEach((f) => { const v = vals[f.key]; if (f.required && (v === undefined || v === '' || v === null || (Array.isArray(v) && !v.length))) errs[f.key] = 'Obrigatório' })
    setErrors(errs)
    if (Object.keys(errs).length) return
    const cf = {}
    Object.entries(vals).forEach(([k, v]) => { if (k.startsWith('cf:')) cf[k.slice(3)] = v })
    const data = {
      listId, name: vals.name || `Envio de formulário: ${form.title}`, description: vals.description ? `<p>${String(vals.description).replace(/\n/g, '<br>')}</p>` : '',
      assignees: vals.assignee ? [vals.assignee] : form.assignee ? [form.assignee] : [], priority: vals.priority ? Number(vals.priority) : null,
      dueDate: vals.dueDate || null, startDate: vals.startDate || null, tags: vals.tags ? String(vals.tags).split(',').map((x) => x.trim().toLowerCase()).filter(Boolean) : [],
      statusId: form.statusId || undefined, typeId: form.typeId || 'task', cf,
    }
    const id = s.createTask(data)
    s.updateTask(id, { formId: form._viewId }, { silent: true })
    setDone(true)
    onSubmitted?.(id)
  }
  if (done) {
    return (
      <div className="py-16 text-center">
        <CheckCircle2 size={44} className="mx-auto text-emerald-500" />
        <div className="mt-3 text-lg font-semibold">Recebido! Obrigado.</div>
        <div className="text-zinc-500">Sua resposta virou uma tarefa na lista.</div>
        <button className="btn btn-outline mt-4" onClick={() => { setVals({}); setDone(false) }}>Enviar outra resposta</button>
      </div>
    )
  }
  const input = (f) => {
    const v = vals[f.key] ?? ''
    if (f.key === 'description') return <textarea className="input min-h-[90px]" value={v} onChange={(e) => set(f.key, e.target.value)} />
    if (f.key === 'assignee') return <select className="input" value={v} onChange={(e) => set(f.key, e.target.value)}><option value="">Selecione…</option>{s.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
    if (f.key === 'priority') return <select className="input" value={v} onChange={(e) => set(f.key, e.target.value)}><option value="">Selecione…</option>{[1, 2, 3, 4].map((p) => <option key={p} value={p}>{PRIORITIES[p].label}</option>)}</select>
    if (f.key === 'dueDate' || f.key === 'startDate') return <input type="date" className="input" value={v} onChange={(e) => set(f.key, e.target.value)} />
    if (f.key === 'tags') return <input className="input" placeholder="separe por vírgula" value={v} onChange={(e) => set(f.key, e.target.value)} />
    if (f.key.startsWith('cf:')) {
      const cf = cfs.find((x) => x.id === f.key.slice(3))
      if (!cf) return <div className="text-zinc-400">Campo indisponível nesta lista</div>
      if (cf.type === 'dropdown') return <select className="input" value={v} onChange={(e) => set(f.key, e.target.value)}><option value="">Selecione…</option>{cf.config.options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
      if (cf.type === 'labels') return <div className="flex flex-wrap gap-2">{cf.config.options.map((o) => { const on = (v || []).includes(o.id); return <button type="button" key={o.id} onClick={() => set(f.key, on ? v.filter((x) => x !== o.id) : [...(v || []), o.id])} className={cx('rounded-full border px-3 py-1', on ? 'border-transparent text-white' : 'border-zinc-300 dark:border-zinc-700')} style={on ? { background: o.color } : {}}>{o.name}</button> })}</div>
      if (cf.type === 'checkbox') return <Toggle checked={!!v} onChange={(x) => set(f.key, x)} />
      if (cf.type === 'date') return <input type="date" className="input" value={v} onChange={(e) => set(f.key, e.target.value)} />
      if (cf.type === 'rating') return <div className="flex gap-1">{Array.from({ length: cf.config.max || 5 }).map((_, i) => <button type="button" key={i} onClick={() => set(f.key, i + 1)} className={cx('text-2xl', i < (v || 0) ? 'text-amber-400' : 'text-zinc-300')}>★</button>)}</div>
      if (cf.type === 'textarea') return <textarea className="input min-h-[80px]" value={v} onChange={(e) => set(f.key, e.target.value)} />
      if (cf.type === 'people') return <select className="input" value={(v || [])[0] || ''} onChange={(e) => set(f.key, e.target.value ? [e.target.value] : [])}><option value="">Selecione…</option>{s.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
      const type = { number: 'number', money: 'number', email: 'email', url: 'url', phone: 'tel', progress: 'number' }[cf.type] || 'text'
      return <input type={type} className="input" value={v} onChange={(e) => set(f.key, type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value)} />
    }
    return <input className="input" value={v} onChange={(e) => set(f.key, e.target.value)} />
  }
  return (
    <div className="mx-auto max-w-xl">
      <div className="mb-6 h-2 rounded-full bg-gradient-to-r from-accent to-cyan-400" />
      <h2 className="text-2xl font-bold">{form.title}</h2>
      {form.description && <p className="mt-1 whitespace-pre-wrap text-zinc-500">{form.description}</p>}
      <div className="mt-6 space-y-5">
        {form.fields.filter(visible).map((f) => (
          <div key={f.key}>
            <label className="mb-1 block font-medium">{f.label}{f.required && <span className="text-red-500"> *</span>}</label>
            {f.help && <div className="mb-1 text-[12px] text-zinc-400">{f.help}</div>}
            {input(f)}
            {errors[f.key] && <div className="mt-1 text-[12px] text-red-500">{errors[f.key]}</div>}
          </div>
        ))}
      </div>
      <button className="btn btn-primary mt-6 w-full justify-center !py-2.5 text-[14px]" onClick={submit}>{form.submitLabel || 'Enviar'}</button>
      {preview && <div className="mt-2 text-center text-[11px] text-zinc-400">Pré-visualização — enviar cria uma tarefa de verdade.</div>}
    </div>
  )
}

export default function FormView({ view, locType, locId, update }) {
  const s = useStore()
  const form = { ...DEFAULT_FORM, ...(view.config.form || {}), _viewId: view.id }
  const lists = listsInLocation(s, locType, locId)
  const listId = form.listId && lists.some((l) => l.id === form.listId) ? form.listId : lists[0]?.id
  const [full, setFull] = useState(false)
  const cfs = getFieldsForList(s, listId)
  const setForm = (p) => update({ form: { ...form, ...p, _viewId: undefined } })
  const setField = (i, p) => setForm({ fields: form.fields.map((f, j) => (j === i ? { ...f, ...p } : f)) })
  const move = (i, d) => { const f = [...form.fields]; const [x] = f.splice(i, 1); f.splice(i + d, 0, x); setForm({ fields: f }) }
  const available = [...BASE_FIELDS, ...cfs.filter((f) => !['formula', 'rollup'].includes(f.type)).map((f) => [`cf:${f.id}`, f.name])].filter(([k]) => !form.fields.some((f) => f.key === k))
  const label = (k) => [...BASE_FIELDS, ...cfs.map((f) => [`cf:${f.id}`, f.name])].find((x) => x[0] === k)?.[1] || k
  const responses = s.tasks.filter((t) => t.formId === view.id && !t.deletedAt).length
  if (!listId) return <div className="p-8 text-zinc-500">Crie uma lista nesta localização para receber respostas do formulário.</div>
  return (
    <div className="flex h-full">
      <div className="w-[420px] shrink-0 space-y-4 overflow-y-auto border-r border-zinc-200 p-4 dark:border-zinc-800">
        <div className="flex items-center gap-2">
          <span className="font-semibold">Construtor de formulário</span>
          <span className="rounded-full bg-zinc-100 px-2 text-[11px] dark:bg-zinc-800">{responses} respostas</span>
          <div className="flex-1" />
          <button className="btn btn-primary !py-1" onClick={() => setFull(true)}><ExternalLink size={13} />Abrir</button>
        </div>
        <div className="space-y-2">
          <div><div className="label mb-1">Título</div><input className="input" value={form.title} onChange={(e) => setForm({ title: e.target.value })} /></div>
          <div><div className="label mb-1">Descrição</div><textarea className="input" value={form.description} onChange={(e) => setForm({ description: e.target.value })} /></div>
          <div className="grid grid-cols-2 gap-2">
            {locType !== 'list' && <div className="col-span-2"><div className="label mb-1">Respostas vão para a lista</div><select className="input" value={listId} onChange={(e) => setForm({ listId: e.target.value })}>{lists.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></div>}
            <div><div className="label mb-1">Status inicial</div><select className="input" value={form.statusId} onChange={(e) => setForm({ statusId: e.target.value })}><option value="">Padrão</option>{getStatusesForList(s, listId).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select></div>
            <div><div className="label mb-1">Responsável padrão</div><select className="input" value={form.assignee} onChange={(e) => setForm({ assignee: e.target.value })}><option value="">Ninguém</option>{s.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select></div>
            <div><div className="label mb-1">Tipo de tarefa</div><select className="input" value={form.typeId} onChange={(e) => setForm({ typeId: e.target.value })}>{s.taskTypes.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            <div><div className="label mb-1">Botão</div><input className="input" value={form.submitLabel} onChange={(e) => setForm({ submitLabel: e.target.value })} /></div>
          </div>
        </div>
        <div>
          <div className="label mb-2">Campos</div>
          <div className="space-y-2">
            {form.fields.map((f, i) => (
              <div key={f.key} className="rounded-lg border border-zinc-200 p-2 dark:border-zinc-800">
                <div className="flex items-center gap-1">
                  <span className="rounded bg-zinc-100 px-1.5 text-[10px] text-zinc-500 dark:bg-zinc-800">{label(f.key)}</span>
                  <div className="flex-1" />
                  <label className="flex items-center gap-1 text-[11px] text-zinc-500">Obrigatório <Toggle small checked={!!f.required} onChange={(v) => setField(i, { required: v })} /></label>
                  {i > 0 && <button className="btn btn-ghost !p-0.5" onClick={() => move(i, -1)}><ArrowUp size={12} /></button>}
                  {i < form.fields.length - 1 && <button className="btn btn-ghost !p-0.5" onClick={() => move(i, 1)}><ArrowDown size={12} /></button>}
                  <button className="btn btn-ghost !p-0.5 text-red-500" onClick={() => setForm({ fields: form.fields.filter((_, j) => j !== i) })}><Trash2 size={12} /></button>
                </div>
                <input className="input mt-1" value={f.label} onChange={(e) => setField(i, { label: e.target.value })} placeholder="Pergunta" />
                <input className="input mt-1 !text-[12px]" value={f.help || ''} onChange={(e) => setField(i, { help: e.target.value })} placeholder="Texto de ajuda (opcional)" />
                <details className="mt-1 text-[12px]">
                  <summary className="cursor-pointer text-zinc-500">Lógica condicional {f.showIf?.key && '· ativa'}</summary>
                  <div className="mt-1 flex gap-1">
                    <select className="input !text-[12px]" value={f.showIf?.key || ''} onChange={(e) => setField(i, { showIf: e.target.value ? { key: e.target.value, value: '' } : null })}>
                      <option value="">Sempre mostrar</option>
                      {form.fields.filter((x) => x.key !== f.key).map((x) => <option key={x.key} value={x.key}>Mostrar se "{x.label}"</option>)}
                    </select>
                    {f.showIf?.key && (() => {
                      const cf = cfs.find((x) => `cf:${x.id}` === f.showIf.key)
                      return cf?.config?.options
                        ? <select className="input !text-[12px]" value={f.showIf.value} onChange={(e) => setField(i, { showIf: { ...f.showIf, value: e.target.value } })}><option value="">=…</option>{cf.config.options.map((o) => <option key={o.id} value={o.id}>= {o.name}</option>)}</select>
                        : <input className="input !text-[12px]" placeholder="= valor" value={f.showIf.value} onChange={(e) => setField(i, { showIf: { ...f.showIf, value: e.target.value } })} />
                    })()}
                  </div>
                </details>
              </div>
            ))}
          </div>
          {available.length > 0 && (
            <select className="input mt-2" value="" onChange={(e) => { if (e.target.value) setForm({ fields: [...form.fields, { key: e.target.value, label: label(e.target.value), required: false }] }) }}>
              <option value="">+ Adicionar campo ao formulário…</option>
              {available.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          )}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto bg-zinc-50 p-8 dark:bg-zinc-900/40">
        <div className="mb-3 flex items-center gap-1 text-[12px] text-zinc-400"><Eye size={13} />Pré-visualização ao vivo</div>
        <div className="card p-8"><FormRenderer form={form} listId={listId} preview key={JSON.stringify(form.fields.map((f) => f.key))} /></div>
      </div>
      <Modal open={full} onClose={() => setFull(false)} width={720}>
        <div className="p-8">
          <FormRenderer form={form} listId={listId} />
          <div className="mt-8 flex items-center justify-center gap-1 text-[11px] text-zinc-400"><Hexagon size={11} />Formulário TaskLab</div>
        </div>
      </Modal>
    </div>
  )
}
