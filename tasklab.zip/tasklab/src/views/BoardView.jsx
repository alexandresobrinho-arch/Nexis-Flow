import React, { useState } from 'react'
import { DndContext, PointerSensor, useSensor, useSensors, useDraggable, useDroppable, DragOverlay } from '@dnd-kit/core'
import { Plus, ChevronsLeft, ChevronsRight, MoreHorizontal, CalendarDays } from 'lucide-react'
import { useStore } from '../store/store'
import { AvatarStack, PriorityFlag, Popover, StatusDot, ProgressBar, Icon } from '../components/ui'
import { CFDisplay } from '../components/fields/CustomField'
import { groupTasks, patchForGroup } from '../lib/query'
import { taskStatus, subtasksOf, progressOf, isClosed, getList, getStatusesForList, statusSource, taskCode } from '../lib/selectors'
import { setStatus } from '../lib/actions'
import { fmtDay, dueTone, cx, uid } from '../lib/utils'
import { defaultListFor, newTaskInGroup, TaskBadges, orderBetween } from './shared'

function Card({ task, groupKey, config, overlay }) {
  const s = useStore()
  const drag = useDraggable({ id: `drag:${task.id}:${groupKey}`, data: { taskId: task.id, groupKey }, disabled: overlay })
  const drop = useDroppable({ id: `card:${task.id}:${groupKey}`, data: { taskId: task.id, groupKey }, disabled: overlay })
  const prog = progressOf(s, task)
  const cover = task.attachments.find((a) => a.type?.startsWith('image/'))
  const cfCols = (config.columns || []).filter((c) => c.startsWith('cf:')).map((c) => s.fields.find((f) => f.id === c.slice(3))).filter(Boolean)
  const type = s.taskTypes.find((x) => x.id === task.typeId)
  const closed = isClosed(s, task)
  const showList = config.groupBy !== 'list' && !(config._locType === 'list')
  return (
    <div ref={(n) => { drag.setNodeRef(n); drop.setNodeRef(n) }} {...drag.listeners} {...drag.attributes} onClick={() => s.openTask(task.id)}
      className={cx('card cursor-pointer overflow-hidden p-0 shadow-sm transition hover:shadow-md', drag.isDragging && 'opacity-30', drop.isOver && 'ring-2 ring-accent', overlay && 'rotate-2 shadow-2xl')}>
      {cover && <img src={cover.url} alt="" className="h-28 w-full object-cover" />}
      <div className="space-y-2 p-3">
        {showList && <div className="flex items-center gap-1 text-[11px] text-zinc-400"><span className="h-1.5 w-1.5 rounded-full" style={{ background: getList(s, task.listId)?.color }} />{getList(s, task.listId)?.name}</div>}
        <div className="flex items-start gap-2">
          {type && type.id !== 'task' && <Icon name={type.icon} size={14} style={{ color: type.color }} className="mt-0.5 shrink-0" />}
          <span className={cx('font-medium leading-snug', closed && 'text-zinc-400 line-through')}>{task.name}</span>
        </div>
        {task.tags.length > 0 && <div className="flex flex-wrap gap-1"><TaskBadges task={{ ...task, checklists: [], attachments: [], blockedBy: [], extraListIds: [], recurrence: null }} /></div>}
        {cfCols.length > 0 && <div className="space-y-1">{cfCols.map((f) => <div key={f.id} className="flex items-center gap-2 text-[12px]"><span className="text-zinc-400">{f.name}:</span><CFDisplay task={task} field={f} /></div>)}</div>}
        {prog && <div className="flex items-center gap-2"><ProgressBar pct={prog.pct} h={4} /><span className="text-[10px] text-zinc-400">{prog.done}/{prog.total}</span></div>}
        <div className="flex items-center gap-2">
          <AvatarStack ids={task.assignees} size={20} />
          {task.dueDate && <span className={cx('flex items-center gap-1 text-[12px]', dueTone(task.dueDate, closed))}><CalendarDays size={12} />{fmtDay(task.dueDate)}</span>}
          <div className="flex-1" />
          <TaskBadges task={task} showTags={false} />
          {task.priority && <PriorityFlag p={task.priority} size={13} />}
        </div>
      </div>
    </div>
  )
}

function Column({ group, config, locType, locId, collapsed, onCollapse, wip, setWip, children }) {
  const s = useStore()
  const drop = useDroppable({ id: `col:${group.key}`, data: { groupKey: group.key } })
  const [adding, setAdding] = useState(false)
  const [name, setName] = useState('')
  const over = wip && group.tasks.length > wip
  const create = () => {
    if (!name.trim()) return
    s.createTask({ name, ...newTaskInGroup(s, defaultListFor(s, locType, locId), config.groupBy, group) })
    setName('')
  }
  if (collapsed) {
    return (
      <div ref={drop.setNodeRef} onClick={onCollapse} className={cx('flex w-10 shrink-0 cursor-pointer flex-col items-center gap-2 rounded-xl bg-zinc-100 py-3 dark:bg-zinc-900', drop.isOver && 'ring-2 ring-accent')}>
        <ChevronsRight size={14} className="text-zinc-400" />
        <span className="text-[11px] font-bold uppercase [writing-mode:vertical-rl]" style={{ color: group.color }}>{group.label} · {group.tasks.length}</span>
      </div>
    )
  }
  return (
    <div className="flex w-[280px] shrink-0 flex-col">
      <div className="mb-2 flex items-center gap-2 rounded-lg px-2 py-1.5" style={{ background: (group.color || '#a1a1aa') + '18', borderTop: `3px solid ${group.color || '#a1a1aa'}` }}>
        <span className="text-[12px] font-bold uppercase" style={{ color: group.color }}>{group.label}</span>
        <span className={cx('text-[12px]', over ? 'font-bold text-red-500' : 'text-zinc-400')}>{group.tasks.length}{wip ? ` / ${wip}` : ''}</span>
        <div className="flex-1" />
        <Popover align="end" trigger={<button className="text-zinc-400 hover:text-zinc-700"><MoreHorizontal size={14} /></button>}>
          {(close) => (
            <div className="menu w-56">
              <button className="menu-item" onClick={() => { onCollapse(); close() }}><ChevronsLeft size={14} />Recolher coluna</button>
              <button className="menu-item" onClick={() => { const v = prompt('Limite WIP (vazio = sem limite)', wip || ''); setWip(v ? Number(v) : null); close() }}>Definir limite WIP</button>
            </div>
          )}
        </Popover>
        <button className="text-zinc-400 hover:text-accent" onClick={() => setAdding(true)}><Plus size={14} /></button>
      </div>
      <div ref={drop.setNodeRef} className={cx('flex min-h-[80px] flex-1 flex-col gap-2 overflow-y-auto rounded-xl p-1 pb-4', drop.isOver && 'bg-accent-50 dark:bg-accent/10', over && 'bg-red-50 dark:bg-red-500/5')}>
        {adding && (
          <div className="card p-2">
            <input autoFocus className="w-full bg-transparent outline-none" placeholder="Nome da tarefa" value={name} onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') create(); if (e.key === 'Escape') setAdding(false) }} onBlur={() => !name && setAdding(false)} />
          </div>
        )}
        {children}
        {!adding && <button onClick={() => setAdding(true)} className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-zinc-400 hover:bg-zinc-100 hover:text-accent dark:hover:bg-zinc-900"><Plus size={13} />Nova tarefa</button>}
      </div>
    </div>
  )
}

export default function BoardView({ tasks, config, locType, locId, update }) {
  const s = useStore()
  const groupBy = config.groupBy || 'status'
  const groups = groupTasks(s, tasks, groupBy, locType, locId, { includeEmpty: true, showClosedGroups: config.showClosed })
  const [active, setActive] = useState(null)
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }))
  const collapsed = config.collapsedCols || {}
  const wip = config.wip || {}
  const manual = !config.sorts?.length

  const onDragEnd = ({ active: a, over }) => {
    setActive(null)
    if (!over) return
    const { taskId, groupKey } = a.data.current
    const task = s.tasks.find((t) => t.id === taskId)
    const tgt = over.data.current
    const group = groups.find((g) => g.key === tgt.groupKey)
    if (!task || !group) return
    if (tgt.groupKey !== groupKey) {
      const patch = patchForGroup(s, task, groupBy, group)
      if (patch) groupBy === 'status' ? setStatus(task.id, patch.statusId) : s.updateTask(task.id, patch)
    }
    if (manual) {
      const list = group.tasks.filter((t) => t.id !== taskId)
      if (tgt.taskId) {
        const idx = list.findIndex((t) => t.id === tgt.taskId)
        s.reorderTask(taskId, orderBetween(list[idx - 1]?.order, list[idx]?.order))
      } else if (tgt.groupKey !== groupKey) {
        s.reorderTask(taskId, orderBetween(list[list.length - 1]?.order, null))
      }
    }
  }
  const addStatus = () => {
    const name = prompt('Nome do novo status')
    if (!name) return
    const src = statusSource(s, locId)
    const sts = getStatusesForList(s, locId)
    const idx = sts.findIndex((x) => x.type === 'done' || x.type === 'closed')
    const next = [...sts]
    next.splice(idx < 0 ? sts.length : idx, 0, { id: uid('s'), name: name.toUpperCase(), color: '#06b6d4', type: 'active', order: 0 })
    s.setStatuses(src.locType, src.locId, next.map((x, i) => ({ ...x, order: i })))
  }
  const activeTask = active && s.tasks.find((t) => t.id === active)
  return (
    <DndContext sensors={sensors} onDragStart={(e) => setActive(e.active.data.current.taskId)} onDragEnd={onDragEnd} onDragCancel={() => setActive(null)}>
      <div className="flex h-full gap-3 overflow-x-auto p-4">
        {groups.map((g) => (
          <Column key={g.key} group={g} config={config} locType={locType} locId={locId} collapsed={collapsed[g.key]} onCollapse={() => update({ collapsedCols: { ...collapsed, [g.key]: !collapsed[g.key] } })}
            wip={wip[g.key]} setWip={(v) => update({ wip: { ...wip, [g.key]: v } })}>
            {g.tasks.map((t) => <Card key={t.id} task={t} groupKey={g.key} config={{ ...config, _locType: locType }} />)}
          </Column>
        ))}
        {groupBy === 'status' && locType === 'list' && (
          <button onClick={addStatus} className="flex h-10 w-[200px] shrink-0 items-center gap-2 rounded-lg border border-dashed border-zinc-300 px-3 text-zinc-400 hover:border-accent hover:text-accent dark:border-zinc-700"><Plus size={14} />Adicionar status</button>
        )}
      </div>
      <DragOverlay>{activeTask && <div className="w-[270px]"><Card task={activeTask} groupKey="overlay" config={config} overlay /></div>}</DragOverlay>
    </DndContext>
  )
}
