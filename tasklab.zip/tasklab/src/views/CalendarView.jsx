import React, { useState } from 'react'
import { DndContext, PointerSensor, useSensor, useSensors, useDraggable, useDroppable, DragOverlay } from '@dnd-kit/core'
import { ChevronLeft, ChevronRight, Plus, PanelRightOpen, PanelRightClose } from 'lucide-react'
import { startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, addWeeks, format, isSameMonth, isSameDay } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { StatusDot, Avatar } from '../components/ui'
import { taskStatus, isClosed } from '../lib/selectors'
import { dayStr, daysBetween, cx, todayStr } from '../lib/utils'
import { defaultListFor, addDaysStr } from './shared'

function Chip({ task, day, muted }) {
  const s = useStore()
  const st = taskStatus(s, task)
  const drag = useDraggable({ id: `cal:${task.id}:${day || 'none'}`, data: { taskId: task.id } })
  return (
    <div ref={drag.setNodeRef} {...drag.listeners} {...drag.attributes} onClick={(e) => { e.stopPropagation(); s.openTask(task.id) }}
      className={cx('flex cursor-pointer items-center gap-1.5 truncate rounded px-1.5 py-0.5 text-[12px]', drag.isDragging && 'opacity-30', muted ? 'opacity-60' : '')}
      style={{ background: st.color + '22', borderLeft: `3px solid ${st.color}` }}>
      <span className={cx('truncate', isClosed(s, task) && 'line-through')}>{task.name}</span>
      {task.assignees[0] && <span className="ml-auto"><Avatar userId={task.assignees[0]} size={14} /></span>}
    </div>
  )
}

function Day({ d, tasks, month, mode, onAdd }) {
  const key = dayStr(d)
  const drop = useDroppable({ id: `day:${key}`, data: { day: key } })
  const [more, setMore] = useState(false)
  const today = isSameDay(d, new Date())
  const max = mode === 'week' ? 50 : 4
  const shown = more ? tasks : tasks.slice(0, max)
  return (
    <div ref={drop.setNodeRef} className={cx('group flex min-h-[110px] flex-col gap-1 border-b border-r border-zinc-200 p-1 dark:border-zinc-800', mode === 'month' && !isSameMonth(d, month) && 'bg-zinc-50/70 dark:bg-zinc-900/40', drop.isOver && 'bg-accent-50 dark:bg-accent/10', mode === 'week' && 'min-h-[60vh]')}>
      <div className="flex items-center justify-between">
        <span className={cx('flex h-6 min-w-6 items-center justify-center rounded-full px-1 text-[12px]', today ? 'bg-accent font-bold text-white' : 'text-zinc-500')}>{mode === 'week' ? format(d, "EEE d", { locale: ptBR }) : format(d, 'd')}</span>
        <button onClick={() => onAdd(key)} className="hidden rounded p-0.5 text-zinc-400 hover:bg-zinc-200 group-hover:block dark:hover:bg-zinc-700"><Plus size={12} /></button>
      </div>
      {shown.map(({ task, muted }) => <Chip key={task.id} task={task} day={key} muted={muted} />)}
      {tasks.length > max && !more && <button className="text-left text-[11px] text-zinc-500 hover:text-accent" onClick={() => setMore(true)}>+{tasks.length - max} mais</button>}
    </div>
  )
}

function Unscheduled({ tasks }) {
  const drop = useDroppable({ id: 'unscheduled', data: { day: null } })
  return (
    <div ref={drop.setNodeRef} className={cx('w-64 shrink-0 overflow-y-auto border-l border-zinc-200 p-3 dark:border-zinc-800', drop.isOver && 'bg-accent-50 dark:bg-accent/10')}>
      <div className="mb-2 font-semibold">Sem data <span className="text-zinc-400">({tasks.length})</span></div>
      <div className="mb-2 text-[11px] text-zinc-400">Arraste para um dia para agendar — ou solte aqui para remover a data.</div>
      <div className="space-y-1">{tasks.map((t) => <Chip key={t.id} task={t} />)}</div>
    </div>
  )
}

export default function CalendarView({ tasks, config, update, locType, locId }) {
  const s = useStore()
  const mode = config.calendarMode || 'month'
  const [cursor, setCursor] = useState(new Date())
  const [side, setSide] = useState(true)
  const [active, setActive] = useState(null)
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }))
  const start = mode === 'month' ? startOfWeek(startOfMonth(cursor), { weekStartsOn: 1 }) : startOfWeek(cursor, { weekStartsOn: 1 })
  const end = mode === 'month' ? endOfWeek(endOfMonth(cursor), { weekStartsOn: 1 }) : endOfWeek(cursor, { weekStartsOn: 1 })
  const days = []
  for (let d = start; d <= end; d = addDays(d, 1)) days.push(d)

  const byDay = {}
  tasks.forEach((t) => {
    if (!t.dueDate && !t.startDate) return
    const due = t.dueDate || t.startDate
    const st = t.startDate && t.startDate < due ? t.startDate : due
    const span = Math.min(daysBetween(st, due), 60)
    for (let i = 0; i <= span; i++) {
      const k = addDaysStr(st, i)
      ;(byDay[k] ||= []).push({ task: t, muted: k !== due })
    }
  })
  const unscheduled = tasks.filter((t) => !t.dueDate && !t.startDate)

  const onDragEnd = ({ active: a, over }) => {
    setActive(null)
    if (!over) return
    const t = s.tasks.find((x) => x.id === a.data.current.taskId)
    const day = over.data.current.day
    if (!t) return
    if (!day) { s.updateTask(t.id, { dueDate: null, startDate: null }); return }
    if (t.startDate && t.dueDate) {
      const delta = daysBetween(t.dueDate, day)
      s.updateTask(t.id, { dueDate: day, startDate: addDaysStr(t.startDate, delta) })
    } else s.updateTask(t.id, { dueDate: day })
  }
  const nav = (n) => setCursor(mode === 'month' ? addMonths(cursor, n) : addWeeks(cursor, n))
  const onAdd = (day) => s.setQuickCreate({ listId: defaultListFor(s, locType, locId), dueDate: day })
  const activeTask = active && s.tasks.find((t) => t.id === active)

  return (
    <DndContext sensors={sensors} onDragStart={(e) => setActive(e.active.data.current.taskId)} onDragEnd={onDragEnd} onDragCancel={() => setActive(null)}>
      <div className="flex h-full">
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-center gap-2 px-4 py-2">
            <button className="btn btn-outline !py-1" onClick={() => setCursor(new Date())}>Hoje</button>
            <button className="btn btn-ghost !p-1" onClick={() => nav(-1)}><ChevronLeft size={16} /></button>
            <button className="btn btn-ghost !p-1" onClick={() => nav(1)}><ChevronRight size={16} /></button>
            <span className="text-[15px] font-semibold capitalize">{mode === 'month' ? format(cursor, 'MMMM yyyy', { locale: ptBR }) : `${format(start, 'd MMM', { locale: ptBR })} – ${format(end, 'd MMM yyyy', { locale: ptBR })}`}</span>
            <div className="flex-1" />
            <div className="flex rounded-md border border-zinc-200 p-0.5 dark:border-zinc-700">
              {[['month', 'Mês'], ['week', 'Semana']].map(([k, l]) => <button key={k} onClick={() => update({ calendarMode: k })} className={cx('rounded px-2 py-0.5', mode === k && 'bg-zinc-100 font-semibold dark:bg-zinc-800')}>{l}</button>)}
            </div>
            <button className="btn btn-ghost !p-1" onClick={() => setSide(!side)} title="Tarefas sem data">{side ? <PanelRightClose size={16} /> : <PanelRightOpen size={16} />}</button>
          </div>
          <div className="grid grid-cols-7 border-l border-t border-zinc-200 text-[11px] font-semibold uppercase text-zinc-400 dark:border-zinc-800">
            {['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'].map((d) => <div key={d} className="border-b border-r border-zinc-200 px-2 py-1 dark:border-zinc-800">{d}</div>)}
          </div>
          <div className="grid flex-1 auto-rows-fr grid-cols-7 overflow-y-auto border-l border-zinc-200 dark:border-zinc-800">
            {days.map((d) => <Day key={d.toISOString()} d={d} month={cursor} mode={mode} tasks={byDay[dayStr(d)] || []} onAdd={onAdd} />)}
          </div>
        </div>
        {side && <Unscheduled tasks={unscheduled} />}
      </div>
      <DragOverlay>{activeTask && <div className="card w-48 px-2 py-1 text-[12px] shadow-xl">{activeTask.name}</div>}</DragOverlay>
    </DndContext>
  )
}
