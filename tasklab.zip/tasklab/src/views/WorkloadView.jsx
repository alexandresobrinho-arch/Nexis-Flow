import React, { useState } from 'react'
import { ChevronLeft, ChevronRight, Settings2 } from 'lucide-react'
import { addDays, addWeeks, startOfWeek, format, isWeekend } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { Avatar, Popover, StatusDot } from '../components/ui'
import { taskStatus, isClosed } from '../lib/selectors'
import { dayStr, daysBetween, cx, todayStr } from '../lib/utils'

const METRICS = [['tasks', 'Nº de tarefas'], ['points', 'Sprint points'], ['hours', 'Horas estimadas']]

export default function WorkloadView({ tasks, config, update }) {
  const s = useStore()
  const metric = config.workloadMetric || 'tasks'
  const [cursor, setCursor] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }))
  const days = Array.from({ length: 14 }, (_, i) => addDays(cursor, i))
  const cap = (m, d) => {
    if (isWeekend(d)) return 0
    if (metric === 'hours') return m?.capacity ?? 8
    if (metric === 'points') return config.capPoints ?? 3
    return config.capTasks ?? 3
  }
  const open = tasks.filter((t) => !isClosed(s, t))
  const load = {} // load[memberId][day] = {v, tasks:[]}
  const unscheduled = {}
  open.forEach((t) => {
    const who = t.assignees.length ? t.assignees : ['none']
    if (!t.dueDate && !t.startDate) { who.forEach((u) => { unscheduled[u] = (unscheduled[u] || 0) + 1 }); return }
    const st = t.startDate && t.dueDate && t.startDate < t.dueDate ? t.startDate : t.dueDate || t.startDate
    const du = t.dueDate || t.startDate
    const span = daysBetween(st, du) + 1
    const workDays = Array.from({ length: span }, (_, i) => dayStr(addDays(new Date(st + 'T12:00'), i))).filter((d) => !isWeekend(new Date(d + 'T12:00')))
    const n = workDays.length || 1
    const value = metric === 'tasks' ? 1 : metric === 'points' ? (t.points || 0) / n : (t.timeEstimate || 0) / 60 / n
    ;(workDays.length ? workDays : [du]).forEach((d) => who.forEach((u) => {
      const cell = ((load[u] ||= {})[d] ||= { v: 0, tasks: [] })
      cell.v += value
      cell.tasks.push(t)
    }))
  })
  const rows = [...s.members, { id: 'none', name: 'Sem responsável' }]
  const fmt = (v) => (metric === 'tasks' ? v : Math.round(v * 10) / 10)
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-2">
        <button className="btn btn-outline !py-1" onClick={() => setCursor(startOfWeek(new Date(), { weekStartsOn: 1 }))}>Hoje</button>
        <button className="btn btn-ghost !p-1" onClick={() => setCursor(addWeeks(cursor, -1))}><ChevronLeft size={16} /></button>
        <button className="btn btn-ghost !p-1" onClick={() => setCursor(addWeeks(cursor, 1))}><ChevronRight size={16} /></button>
        <span className="font-semibold">{format(days[0], 'd MMM', { locale: ptBR })} – {format(days[13], 'd MMM', { locale: ptBR })}</span>
        <div className="flex-1" />
        <span className="text-zinc-500">Medir por</span>
        <select className="input !w-auto !py-1" value={metric} onChange={(e) => update({ workloadMetric: e.target.value })}>{METRICS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        {metric !== 'hours' && (
          <Popover align="end" trigger={<button className="btn btn-outline !py-1"><Settings2 size={13} />Capacidade</button>}>
            <div className="menu w-64 p-3">
              <div className="label mb-1">Capacidade diária padrão ({metric === 'points' ? 'points' : 'tarefas'})</div>
              <input type="number" min="1" className="input" defaultValue={metric === 'points' ? config.capPoints ?? 3 : config.capTasks ?? 3} onChange={(e) => update(metric === 'points' ? { capPoints: Number(e.target.value) } : { capTasks: Number(e.target.value) })} />
              <div className="mt-2 text-[11px] text-zinc-400">Em “Horas estimadas”, a capacidade vem do perfil de cada membro (h/dia) — clique no nome para editar.</div>
            </div>
          </Popover>
        )}
      </div>
      <div className="flex-1 overflow-auto px-4 pb-6">
        <table className="w-full border-collapse">
          <thead className="sticky top-0 z-10 bg-white dark:bg-zinc-950">
            <tr>
              <th className="w-56 border-b border-zinc-200 py-2 text-left font-semibold dark:border-zinc-800">Pessoa</th>
              {days.map((d) => <th key={d.toISOString()} className={cx('border-b border-zinc-200 py-2 text-center text-[11px] font-medium dark:border-zinc-800', dayStr(d) === todayStr() ? 'text-accent' : 'text-zinc-400', isWeekend(d) && 'bg-zinc-50 dark:bg-zinc-900')}>{format(d, 'EEE', { locale: ptBR })}<br />{format(d, 'd')}</th>)}
              <th className="border-b border-zinc-200 py-2 text-[11px] font-medium text-zinc-400 dark:border-zinc-800">Sem data</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((m) => {
              const total = days.reduce((a, d) => a + (load[m.id]?.[dayStr(d)]?.v || 0), 0)
              return (
                <tr key={m.id}>
                  <td className="border-b border-zinc-100 py-2 pr-2 dark:border-zinc-800">
                    <Popover trigger={
                      <button className="flex items-center gap-2 text-left">
                        <Avatar userId={m.id === 'none' ? null : m.id} size={26} />
                        <div><div className="font-medium">{m.name}</div><div className="text-[11px] text-zinc-400">{fmt(total)} {metric === 'hours' ? 'h' : metric === 'points' ? 'pts' : 'tarefas'} em 2 semanas{metric === 'hours' && m.capacity ? ` · ${m.capacity}h/dia` : ''}</div></div>
                      </button>
                    }>
                      {m.id !== 'none' && (
                        <div className="menu w-56 p-3">
                          <div className="label mb-1">Capacidade (h/dia)</div>
                          <input type="number" min="0" className="input" defaultValue={m.capacity ?? 8} onChange={(e) => s.updateMember(m.id, { capacity: Number(e.target.value) })} />
                        </div>
                      )}
                    </Popover>
                  </td>
                  {days.map((d) => {
                    const key = dayStr(d)
                    const cell = load[m.id]?.[key]
                    const c = cap(m.id === 'none' ? null : m, d)
                    const v = cell?.v || 0
                    const ratio = c ? v / c : v ? 2 : 0
                    const color = !v ? '' : ratio > 1 ? 'bg-red-500/80 text-white' : ratio > 0.8 ? 'bg-amber-400/80' : 'bg-emerald-400/70'
                    return (
                      <td key={key} className={cx('border-b border-l border-zinc-100 p-0.5 text-center dark:border-zinc-800', isWeekend(d) && 'bg-zinc-50 dark:bg-zinc-900')}>
                        {cell ? (
                          <Popover block trigger={<button className={cx('h-9 w-full rounded-md text-[12px] font-semibold', color)}>{fmt(v)}</button>}>
                            <div className="menu w-80">
                              <div className="label px-2 py-1">{format(d, "EEEE, d 'de' MMM", { locale: ptBR })} · capacidade {c || '—'}</div>
                              {cell.tasks.map((t) => (
                                <div key={t.id} className="flex items-center gap-2 px-2 py-1.5">
                                  <StatusDot status={taskStatus(s, t)} size={8} />
                                  <button className="flex-1 truncate text-left hover:text-accent" onClick={() => s.openTask(t.id)}>{t.name}</button>
                                  <select className="rounded border border-zinc-200 bg-transparent text-[11px] dark:border-zinc-700" value="" onChange={(e) => {
                                    const to = e.target.value
                                    const next = m.id === 'none' ? [to] : t.assignees.map((a) => (a === m.id ? to : a))
                                    s.updateTask(t.id, { assignees: [...new Set(next)] })
                                  }}>
                                    <option value="">Reatribuir…</option>
                                    {s.members.filter((x) => x.id !== m.id).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
                                  </select>
                                </div>
                              ))}
                            </div>
                          </Popover>
                        ) : <div className="h-9" />}
                      </td>
                    )
                  })}
                  <td className="border-b border-l border-zinc-100 text-center text-zinc-400 dark:border-zinc-800">{unscheduled[m.id] || ''}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div className="mt-3 flex items-center gap-4 text-[11px] text-zinc-500">
          <span className="flex items-center gap-1"><span className="h-3 w-3 rounded bg-emerald-400/70" />Abaixo da capacidade</span>
          <span className="flex items-center gap-1"><span className="h-3 w-3 rounded bg-amber-400/80" />Perto do limite (&gt;80%)</span>
          <span className="flex items-center gap-1"><span className="h-3 w-3 rounded bg-red-500/80" />Sobrecarregado</span>
        </div>
      </div>
    </div>
  )
}
