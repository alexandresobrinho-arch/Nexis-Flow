import React from 'react'
import { MessageSquare, ListChecks, CornerDownRight, Ban, Repeat, Paperclip } from 'lucide-react'
import { useStore } from '../store/store'
import { getStatusesForList, listsInLocation, subtasksOf, getList } from '../lib/selectors'
import { patchForGroup } from '../lib/query'
import { dayStr } from '../lib/utils'
import { addDays } from 'date-fns'
import { TagChip } from '../components/ui'

// Lista padrão para criar tarefas a partir de uma view
export function defaultListFor(s, locType, locId) {
  if (locType === 'list') return locId
  return listsInLocation(s, locType, locId)[0]?.id || s.lists[0]?.id
}

// Dados iniciais de uma nova tarefa criada dentro de um grupo
export function newTaskInGroup(s, listId, groupBy, group) {
  const data = { listId }
  if (!group || !groupBy || groupBy === 'none') return data
  const m = group.meta || {}
  if (groupBy === 'status' && m.status) {
    const st = getStatusesForList(s, listId).find((x) => x.name === m.status.name)
    if (st) data.statusId = st.id
  } else if (groupBy === 'list' && m.listId) {
    data.listId = m.listId
  } else {
    const fake = { listId, tags: [], cf: {}, assignees: [] }
    Object.assign(data, patchForGroup(s, fake, groupBy, group) || {})
  }
  return data
}

export function TaskBadges({ task, showTags = true }) {
  const s = useStore()
  const comments = s.comments.filter((c) => c.taskId === task.id).length
  const items = task.checklists.flatMap((c) => c.items)
  const subs = subtasksOf(s, task.id)
  return (
    <span className="flex shrink-0 items-center gap-2 text-[11px] text-zinc-400">
      {showTags && task.tags.slice(0, 3).map((t) => <TagChip key={t} name={t} />)}
      {subs.length > 0 && <span className="flex items-center gap-0.5"><CornerDownRight size={11} />{subs.length}</span>}
      {items.length > 0 && <span className="flex items-center gap-0.5"><ListChecks size={11} />{items.filter((i) => i.done).length}/{items.length}</span>}
      {comments > 0 && <span className="flex items-center gap-0.5"><MessageSquare size={11} />{comments}</span>}
      {task.attachments.length > 0 && <span className="flex items-center gap-0.5"><Paperclip size={11} />{task.attachments.length}</span>}
      {task.blockedBy.length > 0 && <span className="flex items-center gap-0.5 text-amber-600" title="Aguardando outra tarefa"><Ban size={11} /></span>}
      {task.recurrence && <Repeat size={11} title="Recorrente" />}
      {task.extraListIds.length > 0 && <span className="rounded bg-zinc-100 px-1 dark:bg-zinc-800" title={task.extraListIds.map((l) => getList(s, l)?.name).join(', ')}>+{task.extraListIds.length}</span>}
    </span>
  )
}

// Ordem entre dois vizinhos para reordenação manual
export function orderBetween(prev, next) {
  if (prev == null && next == null) return Date.now()
  if (prev == null) return next - 1
  if (next == null) return prev + 1
  return (prev + next) / 2
}

export const addDaysStr = (s, n) => dayStr(addDays(new Date(s + 'T12:00:00'), n))
