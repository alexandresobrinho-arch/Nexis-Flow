import React, { useState } from 'react'
import { Download, Plus, ArrowUp, ArrowDown } from 'lucide-react'
import { useStore } from '../store/store'
import { StatusDot, InlineEdit } from '../components/ui'
import { Cell, columnLabel, columnWidth, numericValue } from '../components/TaskCells'
import { groupTasks, fieldValue } from '../lib/query'
import { taskStatus, getList, getMember, timeTracked, taskCode, cfValue } from '../lib/selectors'
import { fmtMinutes, download, cx, PRIORITIES, stripHtml } from '../lib/utils'
import { defaultListFor, newTaskInGroup } from './shared'

const CALCS = [['none', '—'], ['sum', 'Soma'], ['avg', 'Média'], ['min', 'Mín'], ['max', 'Máx'], ['count', 'Contagem']]

export default function TableView({ tasks, config, update, locType, locId, selected, setSelected }) {
  const s = useStore()
  const cols = config.columns?.length ? config.columns : ['status', 'assignee', 'dueDate', 'priority']
  const groups = groupTasks(s, tasks, config._tableGrouped ? config.groupBy : 'none', locType, locId, { includeEmpty: false })
  const calcs = config.calcs || {}
  const [newName, setNewName] = useState('')
  const sortBy = (key) => {
    const cur = config.sorts?.[0]
    update({ sorts: [{ key, dir: cur?.key === key && cur.dir === 'asc' ? 'desc' : 'asc' }] })
  }
  const exportCsv = () => {
    const header = ['ID', 'Nome', ...cols.map((c) => columnLabel(s, c)), 'Descrição']
    const rows = tasks.map((t) => [taskCode(s, t), t.name, ...cols.map((c) => {
      if (c === 'status') return taskStatus(s, t).name
      if (c === 'assignee') return t.assignees.map((id) => getMember(s, id)?.name).join('; ')
      if (c === 'priority') return t.priority ? PRIORITIES[t.priority].label : ''
      if (c === 'tags') return t.tags.join('; ')
      if (c === 'list') return getList(s, t.listId)?.name
      if (c === 'timeTracked') return fmtMinutes(timeTracked(t))
      if (c === 'timeEstimate') return fmtMinutes(t.timeEstimate)
      if (c.startsWith('cf:')) {
        const f = s.fields.find((x) => x.id === c.slice(3))
        const v = f && cfValue(s, t, f)
        if (f?.type === 'dropdown') return f.config.options.find((o) => o.id === v)?.name || ''
        if (f?.type === 'labels') return (v || []).map((id) => f.config.options.find((o) => o.id === id)?.name).join('; ')
        if (f?.type === 'people') return (v || []).map((id) => getMember(s, id)?.name).join('; ')
        return v ?? ''
      }
      const v = fieldValue(s, t, c)
      return Array.isArray(v) ? v.join('; ') : v ?? ''
    }), stripHtml(t.description)])
    const csv = [header, ...rows].map((r) => r.map((x) => `"${String(x ?? '').replace(/"/g, '""')}"`).join(',')).join('\n')
    download('tarefas.csv', '﻿' + csv, 'text/csv')
  }
  const calc = (col, list) => {
    const kind = calcs[col]
    if (!kind || kind === 'none') return ''
    if (kind === 'count') return list.length
    const vals = list.map((t) => numericValue(s, t, col)).filter((v) => v !== null)
    if (!vals.length) return ''
    const r = kind === 'sum' ? vals.reduce((a, b) => a + b, 0) : kind === 'avg' ? vals.reduce((a, b) => a + b, 0) / vals.length : kind === 'min' ? Math.min(...vals) : Math.max(...vals)
    if (col === 'timeEstimate' || col === 'timeTracked') return fmtMinutes(r)
    return Math.round(r * 100) / 100
  }
  const numericCol = (c) => ['timeEstimate', 'timeTracked', 'points'].includes(c) || (c.startsWith('cf:') && ['number', 'money', 'formula', 'rating', 'rollup', 'progress'].includes(s.fields.find((f) => f.id === c.slice(3))?.type))
  const sort = config.sorts?.[0]
  const allSel = tasks.length > 0 && tasks.every((t) => selected.has(t.id))
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2 px-4 py-2">
        <span className="text-zinc-500">{tasks.length} linhas</span>
        <label className="flex items-center gap-1.5 text-zinc-500"><input type="checkbox" checked={!!config._tableGrouped} onChange={(e) => update({ _tableGrouped: e.target.checked })} />Agrupar linhas</label>
        <div className="flex-1" />
        <button className="btn btn-outline" onClick={exportCsv}><Download size={14} />Exportar CSV</button>
      </div>
      <div className="flex-1 overflow-auto px-4 pb-6">
        <table className="w-max min-w-full border-collapse text-[13px]">
          <thead className="sticky top-0 z-10 bg-zinc-50 dark:bg-zinc-900">
            <tr>
              <th className="sticky left-0 z-10 w-8 border border-zinc-200 bg-zinc-50 px-2 dark:border-zinc-800 dark:bg-zinc-900"><input type="checkbox" checked={allSel} onChange={() => setSelected(allSel ? new Set() : new Set(tasks.map((t) => t.id)))} className="accent-[#6d5dfc]" /></th>
              <th className="sticky left-8 z-10 min-w-[320px] cursor-pointer border border-zinc-200 bg-zinc-50 px-2 py-2 text-left font-semibold dark:border-zinc-800 dark:bg-zinc-900" onClick={() => sortBy('name')}>
                <span className="flex items-center gap-1">Nome {sort?.key === 'name' && (sort.dir === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}</span>
              </th>
              {cols.map((c) => (
                <th key={c} className="cursor-pointer border border-zinc-200 px-2 py-2 text-left font-semibold dark:border-zinc-800" style={{ minWidth: columnWidth(s, c) }} onClick={() => sortBy(c === 'assignee' ? 'name' : c === 'progress' ? 'name' : c)}>
                  <span className="flex items-center gap-1">{columnLabel(s, c)}{sort?.key === c && (sort.dir === 'asc' ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {groups.map((g) => (
              <React.Fragment key={g.key}>
                {groups.length > 1 && <tr><td colSpan={cols.length + 2} className="border border-zinc-200 bg-zinc-50/60 px-2 py-1 text-[11px] font-bold uppercase dark:border-zinc-800 dark:bg-zinc-900/60" style={{ color: g.color }}>{g.label} · {g.tasks.length}</td></tr>}
                {g.tasks.map((t) => (
                  <tr key={t.id} className={cx('hover:bg-zinc-50 dark:hover:bg-zinc-900', selected.has(t.id) && 'bg-accent-50 dark:bg-accent/10')}>
                    <td className="sticky left-0 border border-zinc-200 bg-white px-2 dark:border-zinc-800 dark:bg-zinc-950"><input type="checkbox" checked={selected.has(t.id)} onChange={() => setSelected((x) => { const n = new Set(x); n.has(t.id) ? n.delete(t.id) : n.add(t.id); return n })} className="accent-[#6d5dfc]" /></td>
                    <td className="sticky left-8 border border-zinc-200 bg-white px-2 py-1 dark:border-zinc-800 dark:bg-zinc-950">
                      <div className="flex items-center gap-2">
                        <StatusDot status={taskStatus(s, t)} size={8} />
                        {t.parentId && <span className="text-[10px] text-zinc-400">↳</span>}
                        <InlineEdit value={t.name} onSave={(name) => s.updateTask(t.id, { name })} className="flex-1 truncate" />
                        <button className="text-[11px] text-zinc-400 hover:text-accent" onClick={() => s.openTask(t.id)}>abrir</button>
                      </div>
                    </td>
                    {cols.map((c) => <td key={c} className="border border-zinc-200 px-1 py-0.5 dark:border-zinc-800"><Cell task={t} col={c} /></td>)}
                  </tr>
                ))}
              </React.Fragment>
            ))}
            <tr>
              <td className="border border-zinc-200 dark:border-zinc-800" />
              <td className="border border-zinc-200 px-2 py-1 dark:border-zinc-800">
                <div className="flex items-center gap-2 text-zinc-400"><Plus size={13} />
                  <input className="flex-1 bg-transparent outline-none" placeholder="Nova linha (Enter)" value={newName} onChange={(e) => setNewName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter' && newName.trim()) { s.createTask({ name: newName, ...newTaskInGroup(s, defaultListFor(s, locType, locId)) }); setNewName('') } }} />
                </div>
              </td>
              <td colSpan={cols.length} className="border border-zinc-200 dark:border-zinc-800" />
            </tr>
          </tbody>
          <tfoot className="sticky bottom-0 bg-zinc-50 dark:bg-zinc-900">
            <tr>
              <td className="border border-zinc-200 dark:border-zinc-800" />
              <td className="border border-zinc-200 px-2 py-1 text-[11px] text-zinc-400 dark:border-zinc-800">Calcular ▸</td>
              {cols.map((c) => (
                <td key={c} className="border border-zinc-200 px-1 py-0.5 dark:border-zinc-800">
                  <select className="w-full bg-transparent text-[11px] text-zinc-500 outline-none" value={calcs[c] || 'none'} onChange={(e) => update({ calcs: { ...calcs, [c]: e.target.value } })}>
                    {CALCS.filter(([k]) => k === 'none' || k === 'count' || numericCol(c)).map(([k, l]) => <option key={k} value={k}>{k === (calcs[c] || 'none') && k !== 'none' ? `${l}: ${calc(c, tasks)}` : l}</option>)}
                  </select>
                </td>
              ))}
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}
