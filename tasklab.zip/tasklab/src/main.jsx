import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)

// expõe o store no console para estudo/debug: __store.getState()
import { useStore } from './store/store'
window.__store = useStore
