import React, { useEffect } from 'react'
import { useStore } from './store/store'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import TaskDetail from './components/TaskDetail'
import ModalHost from './components/Modals'
import { CommandPalette, QuickCreate, Toasts } from './components/Global'
import LocationPage from './pages/LocationPage'
import HomePage from './pages/HomePage'
import InboxPage from './pages/InboxPage'
import DocsPage from './pages/DocsPage'
import DashboardsPage from './pages/DashboardsPage'
import GoalsPage from './pages/GoalsPage'
import TimesheetsPage from './pages/TimesheetsPage'
import { TemplatesPage, TrashPage } from './pages/MiscPages'
import SettingsPage from './pages/SettingsPage'

const PAGES = {
  home: HomePage, inbox: InboxPage, docs: DocsPage, dashboards: DashboardsPage, goals: GoalsPage,
  timesheets: TimesheetsPage, templates: TemplatesPage, trash: TrashPage, settings: SettingsPage, location: LocationPage,
}

export default function App() {
  const theme = useStore((s) => s.theme)
  const page = useStore((s) => s.route.page)
  const checkDateTriggers = useStore((s) => s.checkDateTriggers)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark')
    document.body.classList.toggle('dark', theme === 'dark')
  }, [theme])

  // gatilhos de "data chega" das automações
  useEffect(() => {
    checkDateTriggers()
    const i = setInterval(checkDateTriggers, 60000)
    return () => clearInterval(i)
  }, [])

  // atalhos de teclado
  useEffect(() => {
    const onKey = (e) => {
      const st = useStore.getState()
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName) || e.target.isContentEditable
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); st.setPalette(!st.paletteOpen); return }
      if (typing || st.paletteOpen || st.quickCreate || st.modal) return
      if (e.key === 't' || e.key === 'T') { e.preventDefault(); st.setQuickCreate({}) }
      if (e.key === '/') { e.preventDefault(); st.setPalette(true) }
      if (e.key === '[') st.toggleSidebar()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const Page = PAGES[page] || HomePage
  return (
    <div className="flex h-full overflow-hidden">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main className="min-h-0 flex-1 overflow-hidden"><Page /></main>
      </div>
      <TaskDetail />
      <ModalHost />
      <QuickCreate />
      <CommandPalette />
      <Toasts />
    </div>
  )
}
