import React, { useState } from 'react'
import {
  Home, Inbox, FileText, LayoutDashboard, Target, Clock, ChevronRight, ChevronDown, Plus, MoreHorizontal, Star, Layers,
  Folder, List as ListIcon, Hexagon, Trash2, Settings, PanelLeftClose, Lock, Copy, Pencil, Palette, Zap, ListChecks, SlidersHorizontal, LayoutTemplate,
  Archive,
} from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, Icon, ColorPicker, Confirm } from './ui'
import { cx } from '../lib/utils'

function NavItem({ icon: I, label, active, onClick, badge }) {
  return (
    <button onClick={onClick} className={cx('flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-left font-medium', active ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800')}>
      <I size={16} />
      <span className="flex-1 truncate">{label}</span>
      {badge ? <span className="rounded-full bg-accent px-1.5 text-[10px] font-bold text-white">{badge}</span> : null}
    </button>
  )
}

export function LocationMenu({ locType, locId, close, onRename }) {
  const st = useStore()
  const [confirm, setConfirm] = useState(false)
  const item = locType === 'space' ? st.spaces.find((x) => x.id === locId) : locType === 'folder' ? st.folders.find((x) => x.id === locId) : st.lists.find((x) => x.id === locId)
  if (!item) return null
  const fav = st.favorites.some((f) => f.type === locType && f.id === locId)
  const spaceId = locType === 'space' ? locId : item.spaceId
  const add = (kind) => {
    const name = prompt(kind === 'folder' ? 'Nome da pasta' : 'Nome da lista')
    if (!name) return
    if (kind === 'folder') st.addFolder(spaceId, name)
    else {
      const id = st.addList(spaceId, locType === 'folder' ? locId : null, name)
      st.navigate({ page: 'location', locType: 'list', locId: id })
    }
    close()
  }
  const del = () => {
    if (locType === 'space') st.deleteSpace(locId)
    if (locType === 'folder') st.deleteFolder(locId)
    if (locType === 'list') st.deleteList(locId)
  }
  const modal = (type) => { st.setModal({ type, locType, locId }); close() }
  return (
    <div className="menu w-60">
      {locType !== 'list' && <button className="menu-item" onClick={() => add('list')}><ListIcon size={14} />Nova lista</button>}
      {locType === 'space' && <button className="menu-item" onClick={() => add('folder')}><Folder size={14} />Nova pasta</button>}
      {locType !== 'list' && <button className="menu-item" onClick={() => modal('listFromTemplate')}><LayoutTemplate size={14} />Lista a partir de template</button>}
      <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
      <button className="menu-item" onClick={() => { onRename?.(); close() }}><Pencil size={14} />Renomear</button>
      <Popover side="right" trigger={<span className="menu-item"><Palette size={14} />Cor<ChevronRight size={13} className="ml-auto" /></span>} block>
        {(c2) => <div className="menu"><ColorPicker value={item.color} onChange={(color) => {
          if (locType === 'space') st.updateSpace(locId, { color }); if (locType === 'folder') st.updateFolder(locId, { color }); if (locType === 'list') st.updateList(locId, { color }); c2()
        }} /></div>}
      </Popover>
      {locType === 'space' && (
        <Popover side="right" block trigger={<span className="menu-item"><Layers size={14} />Ícone<ChevronRight size={13} className="ml-auto" /></span>}>
          {(c2) => <div className="menu grid grid-cols-5 gap-1 p-2">{['Megaphone', 'Rocket', 'User', 'Layers', 'Briefcase', 'Code', 'Heart', 'Star', 'Zap', 'BookOpen', 'Target', 'Palette', 'Globe', 'Box', 'Users'].map((n) => (
            <button key={n} className="flex h-8 w-8 items-center justify-center rounded hover:bg-zinc-100 dark:hover:bg-zinc-800" onClick={() => { st.updateSpace(locId, { icon: n }); c2() }}><Icon name={n} size={16} /></button>
          ))}</div>}
        </Popover>
      )}
      <button className="menu-item" onClick={() => { st.toggleFavorite(locType, locId); close() }}><Star size={14} />{fav ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}</button>
      <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
      <button className="menu-item" onClick={() => modal('statuses')}><ListChecks size={14} />Status</button>
      <button className="menu-item" onClick={() => modal('fields')}><SlidersHorizontal size={14} />Campos personalizados</button>
      <button className="menu-item" onClick={() => modal('automations')}><Zap size={14} />Automações</button>
      {locType === 'list' && <button className="menu-item" onClick={() => { st.saveListTemplate(locId, prompt('Nome do template', item.name) || item.name); close() }}><LayoutTemplate size={14} />Salvar como template</button>}
      {locType === 'list' && <button className="menu-item" onClick={() => { const id = st.duplicateList(locId); st.navigate({ page: 'location', locType: 'list', locId: id }); close() }}><Copy size={14} />Duplicar</button>}
      {locType === 'space' && <button className="menu-item" onClick={() => { st.updateSpace(locId, { private: !item.private }); close() }}><Lock size={14} />{item.private ? 'Tornar público' : 'Tornar privado'}</button>}
      <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
      <button className="menu-item text-red-500" onClick={() => setConfirm(true)}><Trash2 size={14} />Excluir</button>
      <Confirm open={confirm} onClose={() => { setConfirm(false); close() }} onConfirm={del} title={`Excluir "${item.name}"?`} text="As tarefas vão para a lixeira e podem ser restauradas." />
    </div>
  )
}

function TreeRow({ depth, icon, color, label, active, expanded, onToggle, onClick, locType, locId, count }) {
  const [renaming, setRenaming] = useState(false)
  const [v, setV] = useState(label)
  const st = useStore()
  const save = () => {
    setRenaming(false)
    if (!v.trim()) return
    if (locType === 'space') st.updateSpace(locId, { name: v.trim() })
    if (locType === 'folder') st.updateFolder(locId, { name: v.trim() })
    if (locType === 'list') st.updateList(locId, { name: v.trim() })
  }
  return (
    <div className={cx('group flex items-center gap-1 rounded-md pr-1 text-zinc-600 dark:text-zinc-300', active ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'hover:bg-zinc-100 dark:hover:bg-zinc-800')} style={{ paddingLeft: 4 + depth * 14 }}>
      {onToggle ? (
        <button onClick={onToggle} className="rounded p-0.5 text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700">{expanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}</button>
      ) : <span className="w-[17px]" />}
      <button className="flex min-w-0 flex-1 items-center gap-2 py-1.5 text-left" onClick={onClick} onDoubleClick={() => { setV(label); setRenaming(true) }}>
        {icon}
        {renaming ? (
          <input autoFocus className="w-full rounded bg-white px-1 outline-none ring-2 ring-accent/40 dark:bg-zinc-900" value={v} onChange={(e) => setV(e.target.value)} onBlur={save} onKeyDown={(e) => e.key === 'Enter' && save()} onClick={(e) => e.stopPropagation()} />
        ) : <span className="truncate font-medium">{label}</span>}
      </button>
      {count ? <span className="text-[11px] text-zinc-400 group-hover:hidden">{count}</span> : null}
      <Popover align="start" side="right" trigger={<span className="hidden rounded p-0.5 hover:bg-zinc-200 group-hover:inline-flex dark:hover:bg-zinc-700"><MoreHorizontal size={14} /></span>}>
        {(close) => <LocationMenu locType={locType} locId={locId} close={close} onRename={() => { setV(label); setRenaming(true) }} />}
      </Popover>
    </div>
  )
}

export default function Sidebar() {
  const st = useStore()
  const { spaces, folders, lists, route, expanded, favorites, tasks } = st
  const unread = st.notifications.filter((n) => n.userId === st.currentUserId && !n.read && !n.cleared).length
  const go = (r) => st.navigate(r)
  const isLoc = (t, id) => route.page === 'location' && route.locType === t && route.locId === id
  const countFor = (lid) => tasks.filter((t) => t.listId === lid && !t.deletedAt && !t.archived && !t.parentId).length

  if (st.sidebarCollapsed) {
    return (
      <aside className="flex w-14 shrink-0 flex-col items-center gap-1 border-r border-zinc-200 bg-zinc-50 py-3 dark:border-zinc-800 dark:bg-zinc-900">
        <button className="mb-2 rounded-lg bg-accent p-1.5 text-white" onClick={st.toggleSidebar}><Hexagon size={18} /></button>
        {[[Home, 'home'], [Inbox, 'inbox'], [FileText, 'docs'], [LayoutDashboard, 'dashboards'], [Target, 'goals'], [Clock, 'timesheets']].map(([I, p]) => (
          <button key={p} onClick={() => go({ page: p })} className={cx('rounded-md p-2', route.page === p ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'text-zinc-500 hover:bg-zinc-200 dark:hover:bg-zinc-800')}><I size={17} /></button>
        ))}
      </aside>
    )
  }

  return (
    <aside className="flex w-64 shrink-0 flex-col border-r border-zinc-200 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900">
      <div className="flex items-center gap-2 px-3 py-3">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-accent to-cyan-500 text-white"><Hexagon size={16} /></span>
        <span className="flex-1 truncate text-[14px] font-bold">{st.workspace.name}</span>
        <button className="btn btn-ghost !p-1" title="Recolher" onClick={st.toggleSidebar}><PanelLeftClose size={16} /></button>
      </div>
      <nav className="space-y-0.5 px-2">
        <NavItem icon={Home} label="Início" active={route.page === 'home'} onClick={() => go({ page: 'home' })} />
        <NavItem icon={Inbox} label="Caixa de entrada" badge={unread} active={route.page === 'inbox'} onClick={() => go({ page: 'inbox' })} />
        <NavItem icon={FileText} label="Docs" active={route.page === 'docs'} onClick={() => go({ page: 'docs' })} />
        <NavItem icon={LayoutDashboard} label="Dashboards" active={route.page === 'dashboards'} onClick={() => go({ page: 'dashboards' })} />
        <NavItem icon={Target} label="Metas" active={route.page === 'goals'} onClick={() => go({ page: 'goals' })} />
        <NavItem icon={Clock} label="Planilhas de horas" active={route.page === 'timesheets'} onClick={() => go({ page: 'timesheets' })} />
      </nav>

      <div className="mt-3 flex-1 overflow-y-auto px-2 pb-4">
        {favorites.length > 0 && (
          <div className="mb-3">
            <div className="label px-2 py-1">Favoritos</div>
            {favorites.map((f) => {
              const item = f.type === 'doc' ? st.docs.find((d) => d.id === f.id) : f.type === 'space' ? spaces.find((x) => x.id === f.id) : f.type === 'folder' ? folders.find((x) => x.id === f.id) : lists.find((x) => x.id === f.id)
              if (!item) return null
              return (
                <button key={f.type + f.id} onClick={() => f.type === 'doc' ? go({ page: 'docs', docId: f.id }) : go({ page: 'location', locType: f.type, locId: f.id })} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800">
                  <Star size={13} className="text-amber-400" fill="currentColor" />
                  <span className="truncate font-medium">{f.type === 'doc' ? item.title : item.name}</span>
                </button>
              )
            })}
          </div>
        )}

        <div className="flex items-center justify-between px-2 py-1">
          <span className="label">Spaces</span>
          <button className="rounded p-0.5 text-zinc-400 hover:bg-zinc-200 dark:hover:bg-zinc-700" title="Novo Space" onClick={() => st.setModal({ type: 'newSpace' })}><Plus size={14} /></button>
        </div>
        <TreeRowStatic label="Tudo" icon={<Layers size={14} className="text-zinc-400" />} active={isLoc('everything', 'all')} onClick={() => go({ page: 'location', locType: 'everything', locId: 'all' })} />
        {spaces.map((sp) => (
          <div key={sp.id}>
            <TreeRow depth={0} locType="space" locId={sp.id} label={sp.name} expanded={expanded[sp.id]} onToggle={() => st.toggleExpanded(sp.id)} active={isLoc('space', sp.id)}
              onClick={() => go({ page: 'location', locType: 'space', locId: sp.id })}
              icon={<span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md text-white" style={{ background: sp.color }}><Icon name={sp.icon} size={12} /></span>} />
            {expanded[sp.id] && (
              <div>
                {folders.filter((f) => f.spaceId === sp.id).map((f) => (
                  <div key={f.id}>
                    <TreeRow depth={1} locType="folder" locId={f.id} label={f.name} expanded={expanded[f.id]} onToggle={() => st.toggleExpanded(f.id)} active={isLoc('folder', f.id)}
                      onClick={() => go({ page: 'location', locType: 'folder', locId: f.id })} icon={<Folder size={14} style={{ color: f.color || sp.color }} />} />
                    {expanded[f.id] && lists.filter((l) => l.folderId === f.id).map((l) => (
                      <TreeRow key={l.id} depth={2} locType="list" locId={l.id} label={l.name} active={isLoc('list', l.id)} count={countFor(l.id)}
                        onClick={() => go({ page: 'location', locType: 'list', locId: l.id })} icon={<span className="h-2 w-2 shrink-0 rounded-full" style={{ background: l.color }} />} />
                    ))}
                  </div>
                ))}
                {lists.filter((l) => l.spaceId === sp.id && !l.folderId).map((l) => (
                  <TreeRow key={l.id} depth={1} locType="list" locId={l.id} label={l.name} active={isLoc('list', l.id)} count={countFor(l.id)}
                    onClick={() => go({ page: 'location', locType: 'list', locId: l.id })} icon={<span className="h-2 w-2 shrink-0 rounded-full" style={{ background: l.color }} />} />
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="space-y-0.5 border-t border-zinc-200 p-2 dark:border-zinc-800">
        <NavItem icon={LayoutTemplate} label="Templates" active={route.page === 'templates'} onClick={() => go({ page: 'templates' })} />
        <NavItem icon={Archive} label="Lixeira" active={route.page === 'trash'} onClick={() => go({ page: 'trash' })} />
        <NavItem icon={Settings} label="Configurações" active={route.page === 'settings'} onClick={() => go({ page: 'settings' })} />
      </div>
    </aside>
  )
}

function TreeRowStatic({ label, icon, active, onClick }) {
  return (
    <button onClick={onClick} className={cx('flex w-full items-center gap-2 rounded-md py-1.5 pl-[25px] pr-2 text-left font-medium', active ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800')}>
      {icon}<span>{label}</span>
    </button>
  )
}
