import React from 'react'
import { Ban, Link2 } from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, StatusBadge, StatusMenu, UserPickerMenu, AvatarStack, Avatar, PriorityFlag, PriorityMenu, DatePickerMenu, TagMenu, TagChip, ProgressBar, Icon } from './ui'
import { CFEditor } from './fields/CustomField'
import { taskStatus, getList, progressOf, timeTracked, isClosed, blockingOf, cfValue } from '../lib/selectors'
import { setStatus } from '../lib/actions'
import { fmtDay, fmtMinutes, parseDuration, dueTone, cx, fmtRelative } from '../lib/utils'

export const COLUMN_META = {
  status: { label: 'Status', w: 130 },
  assignee: { label: 'Responsável', w: 110 },
  dueDate: { label: 'Entrega', w: 100 },
  startDate: { label: 'Início', w: 100 },
  priority: { label: 'Prioridade', w: 100 },
  tags: { label: 'Tags', w: 150 },
  timeEstimate: { label: 'Estimativa', w: 90, num: true },
  timeTracked: { label: 'Rastreado', w: 90, num: true },
  points: { label: 'Points', w: 70, num: true },
  progress: { label: 'Progresso', w: 120 },
  list: { label: 'Lista', w: 130 },
  createdAt: { label: 'Criada', w: 90 },
  updatedAt: { label: 'Atualizada', w: 90 },
  createdBy: { label: 'Criado por', w: 90 },
  type: { label: 'Tipo', w: 100 },
  dependencies: { label: 'Dependências', w: 110 },
}

export function columnLabel(s, key) {
  if (key.startsWith('cf:')) return s.fields.find((f) => f.id === key.slice(3))?.name || '?'
  return COLUMN_META[key]?.label || key
}
export function columnWidth(s, key) {
  if (key.startsWith('cf:')) {
    const f = s.fields.find((x) => x.id === key.slice(3))
    return ['labels', 'textarea', 'url', 'email'].includes(f?.type) ? 170 : 130
  }
  return COLUMN_META[key]?.w || 120
}

const hover = 'rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800'

export function Cell({ task, col }) {
  const s = useStore()
  const up = (p) => s.updateTask(task.id, p)
  const closed = isClosed(s, task)
  if (col.startsWith('cf:')) {
    const f = s.fields.find((x) => x.id === col.slice(3))
    const applies = f && (f.locType === 'workspace' || (f.locType === 'list' && f.locId === task.listId) || (f.locType === 'folder' && getList(s, task.listId)?.folderId === f.locId) || (f.locType === 'space' && getList(s, task.listId)?.spaceId === f.locId))
    if (!applies) return <span className="text-zinc-200 dark:text-zinc-700">·</span>
    return <CFEditor task={task} field={f} />
  }
  switch (col) {
    case 'status':
      return <Popover trigger={<button><StatusBadge status={taskStatus(s, task)} small /></button>}>{(c) => <StatusMenu listId={task.listId} value={task.statusId} onChange={(id) => setStatus(task.id, id)} close={c} />}</Popover>
    case 'assignee':
      return <Popover trigger={<button className={hover}><AvatarStack ids={task.assignees} size={22} /></button>}>{(c) => <UserPickerMenu value={task.assignees} onChange={(a) => up({ assignees: a })} close={c} />}</Popover>
    case 'dueDate':
    case 'startDate':
      return (
        <Popover trigger={<button className={cx(hover, col === 'dueDate' && dueTone(task.dueDate, closed))}>{task[col] ? fmtDay(task[col]) : <span className="text-zinc-300 dark:text-zinc-600">—</span>}</button>}>
          {(c) => <DatePickerMenu value={task[col]} onChange={(d) => up({ [col]: d })} close={c} />}
        </Popover>
      )
    case 'priority':
      return <Popover trigger={<button className={hover}><PriorityFlag p={task.priority} label={!!task.priority} /></button>}>{(c) => <PriorityMenu value={task.priority} onChange={(p) => up({ priority: p })} close={c} />}</Popover>
    case 'tags':
      return (
        <Popover trigger={<button className={cx(hover, 'flex max-w-full flex-wrap gap-1')}>{task.tags.length ? task.tags.map((t) => <TagChip key={t} name={t} />) : <span className="text-zinc-300 dark:text-zinc-600">—</span>}</button>}>
          <TagMenu value={task.tags} onChange={(tags) => up({ tags })} />
        </Popover>
      )
    case 'timeEstimate':
      return (
        <Popover trigger={<button className={hover}>{task.timeEstimate ? fmtMinutes(task.timeEstimate) : <span className="text-zinc-300 dark:text-zinc-600">—</span>}</button>}>
          {(c) => <div className="menu w-48 p-2"><input autoFocus className="input" placeholder="ex: 2h 30m" defaultValue={task.timeEstimate ? fmtMinutes(task.timeEstimate) : ''} onKeyDown={(e) => { if (e.key === 'Enter') { up({ timeEstimate: parseDuration(e.target.value) || null }); c() } }} /></div>}
        </Popover>
      )
    case 'timeTracked': { const m = timeTracked(task); return <span className={m ? '' : 'text-zinc-300 dark:text-zinc-600'}>{m ? fmtMinutes(m) : '—'}</span> }
    case 'points':
      return (
        <Popover trigger={<button className={hover}>{task.points ?? <span className="text-zinc-300 dark:text-zinc-600">—</span>}</button>}>
          {(c) => <div className="menu grid w-48 grid-cols-4 gap-1 p-2">{[0, 1, 2, 3, 5, 8, 13, 21].map((p) => <button key={p} className="rounded border border-zinc-200 py-1 dark:border-zinc-700" onClick={() => { up({ points: p }); c() }}>{p}</button>)}</div>}
        </Popover>
      )
    case 'progress': {
      const p = progressOf(s, task)
      return p ? <span className="flex items-center gap-1.5"><ProgressBar pct={p.pct} h={5} /><span className="text-[11px] text-zinc-500">{p.pct}%</span></span> : <span className="text-zinc-300 dark:text-zinc-600">—</span>
    }
    case 'list': { const l = getList(s, task.listId); return <span className="flex items-center gap-1.5 truncate"><span className="h-2 w-2 shrink-0 rounded-full" style={{ background: l?.color }} /><span className="truncate">{l?.name}</span></span> }
    case 'createdAt': return <span className="text-zinc-500">{fmtRelative(task.createdAt)}</span>
    case 'updatedAt': return <span className="text-zinc-500">{fmtRelative(task.updatedAt)}</span>
    case 'createdBy': return <Avatar userId={task.createdBy} size={20} />
    case 'type': { const t = s.taskTypes.find((x) => x.id === task.typeId) || s.taskTypes[0]; return <span className="flex items-center gap-1" style={{ color: t.color }}><Icon name={t.icon} size={13} />{t.name}</span> }
    case 'dependencies': {
      const w = task.blockedBy.length, b = blockingOf(s, task.id).length
      return <span className="flex gap-2 text-[12px]">{w > 0 && <span className="flex items-center gap-0.5 text-amber-600"><Ban size={12} />{w}</span>}{b > 0 && <span className="flex items-center gap-0.5 text-red-500"><Ban size={12} />{b}</span>}{task.links.length > 0 && <span className="flex items-center gap-0.5 text-zinc-400"><Link2 size={12} />{task.links.length}</span>}{!w && !b && !task.links.length && <span className="text-zinc-300 dark:text-zinc-600">—</span>}</span>
    }
    default: return null
  }
}

// valor numérico para rodapé de cálculo
export function numericValue(s, task, col) {
  if (col === 'timeEstimate') return task.timeEstimate || 0
  if (col === 'timeTracked') return timeTracked(task)
  if (col === 'points') return task.points || 0
  if (col.startsWith('cf:')) {
    const f = s.fields.find((x) => x.id === col.slice(3))
    if (!f || !['number', 'money', 'formula', 'rating', 'rollup', 'progress'].includes(f.type)) return null
    return Number(cfValue(s, task, f)) || 0
  }
  return null
}
