import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Search, CheckSquare, FileText, List as ListIcon, Folder, Layers, ArrowRight, Plus, Home, Inbox, LayoutDashboard, Target, Clock, Settings, Moon, LayoutTemplate } from 'lucide-react'
import { useStore } from '../store/store'
import { Modal, StatusDot, Popover, StatusMenu, UserPickerMenu, AvatarStack, PriorityMenu, PriorityFlag, DatePickerMenu, TagMenu, TagChip, ModalHeader } from './ui'
import { searchTasks, taskStatus, taskPath, getStatusesForList, taskCode } from '../lib/selectors'
import { cx, fmtDay } from '../lib/utils'

export function CommandPalette() {
  const st = useStore()
  const [q, setQ] = useState('')
  const [idx, setIdx] = useState(0)
  const open = st.paletteOpen
  useEffect(() => { if (open) { setQ(''); setIdx(0) } }, [open])
  const results = useMemo(() => {
    const ql = q.toLowerCase()
    const nav = [
      ['Ir para Início', Home, () => st.navigate({ page: 'home' })],
      ['Ir para Caixa de entrada', Inbox, () => st.navigate({ page: 'inbox' })],
      ['Ir para Docs', FileText, () => st.navigate({ page: 'docs' })],
      ['Ir para Dashboards', LayoutDashboard, () => st.navigate({ page: 'dashboards' })],
      ['Ir para Metas', Target, () => st.navigate({ page: 'goals' })],
      ['Ir para Planilhas de horas', Clock, () => st.navigate({ page: 'timesheets' })],
      ['Ir para Templates', LayoutTemplate, () => st.navigate({ page: 'templates' })],
      ['Configurações', Settings, () => st.navigate({ page: 'settings' })],
      ['Criar tarefa', Plus, () => st.setQuickCreate({})],
      ['Criar doc', Plus, () => { const id = st.addDoc({}); st.navigate({ page: 'docs', docId: id }) }],
      ['Alternar tema claro/escuro', Moon, () => st.setTheme(st.theme === 'dark' ? 'light' : 'dark')],
    ].filter(([l]) => !ql || l.toLowerCase().includes(ql)).map(([label, icon, run]) => ({ kind: 'Ações', label, icon, run }))
    const locs = [
      ...st.spaces.map((x) => ({ label: x.name, icon: Layers, color: x.color, run: () => st.navigate({ page: 'location', locType: 'space', locId: x.id }) })),
      ...st.folders.map((x) => ({ label: x.name, icon: Folder, run: () => st.navigate({ page: 'location', locType: 'folder', locId: x.id }) })),
      ...st.lists.map((x) => ({ label: x.name, icon: ListIcon, color: x.color, run: () => st.navigate({ page: 'location', locType: 'list', locId: x.id }) })),
    ].filter((x) => ql && x.label.toLowerCase().includes(ql)).map((x) => ({ ...x, kind: 'Locais' }))
    const tasks = searchTasks(st, q).slice(0, 12).map((t) => ({ kind: 'Tarefas', label: t.name, sub: taskPath(st, t), status: taskStatus(st, t), code: taskCode(st, t), run: () => st.openTask(t.id) }))
    const docs = st.docs.filter((d) => ql && d.title.toLowerCase().includes(ql)).map((d) => ({ kind: 'Docs', label: d.title, icon: FileText, run: () => st.navigate({ page: 'docs', docId: d.id }) }))
    return [...tasks, ...locs, ...docs, ...nav]
  }, [q, st])
  const choose = (r) => { st.setPalette(false); r.run() }
  if (!open) return null
  let lastKind = null
  return (
    <Modal open onClose={() => st.setPalette(false)} width={620}>
      <div className="flex items-center gap-2 border-b border-zinc-200 px-4 dark:border-zinc-800">
        <Search size={16} className="text-zinc-400" />
        <input autoFocus value={q} onChange={(e) => { setQ(e.target.value); setIdx(0) }} placeholder="Buscar ou digitar um comando…" className="h-12 flex-1 bg-transparent text-[15px] outline-none"
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(results.length - 1, i + 1)) }
            if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)) }
            if (e.key === 'Enter' && results[idx]) choose(results[idx])
          }} />
      </div>
      <div className="max-h-[60vh] overflow-y-auto p-2">
        {!results.length && <div className="p-6 text-center text-zinc-400">Nada encontrado</div>}
        {results.map((r, i) => {
          const header = r.kind !== lastKind ? (lastKind = r.kind) : null
          const I = r.icon
          return (
            <React.Fragment key={i}>
              {header && <div className="label px-2 pb-1 pt-2">{header}</div>}
              <button onMouseEnter={() => setIdx(i)} onClick={() => choose(r)} className={cx('flex w-full items-center gap-2.5 rounded-md px-2 py-2 text-left', i === idx && 'bg-zinc-100 dark:bg-zinc-800')}>
                {r.status ? <StatusDot status={r.status} /> : <I size={15} style={{ color: r.color }} className="text-zinc-400" />}
                <span className="truncate font-medium">{r.label}</span>
                {r.code && <span className="text-[11px] text-zinc-400">{r.code}</span>}
                {r.sub && <span className="ml-auto truncate text-[11px] text-zinc-400">{r.sub}</span>}
                {i === idx && !r.sub && <ArrowRight size={13} className="ml-auto text-zinc-400" />}
              </button>
            </React.Fragment>
          )
        })}
      </div>
    </Modal>
  )
}

export function QuickCreate() {
  const st = useStore()
  const qc = st.quickCreate
  const defaultList = qc?.listId || (st.route.locType === 'list' ? st.route.locId : st.lists[0]?.id)
  const [form, setForm] = useState(null)
  useEffect(() => {
    if (qc) setForm({ name: '', description: '', listId: defaultList, statusId: null, assignees: qc.assignees || [], priority: null, dueDate: qc.dueDate || null, tags: [], template: '' })
  }, [qc])
  if (!qc || !form) return null
  const list = st.lists.find((l) => l.id === form.listId)
  const statuses = list ? getStatusesForList(st, list.id) : []
  const status = statuses.find((x) => x.id === form.statusId) || statuses[0]
  const set = (p) => setForm((f) => ({ ...f, ...p }))
  const create = (openAfter) => {
    if (!form.listId) return
    let id
    if (form.template) {
      id = st.createTaskFromTemplate(form.template, form.listId)
      if (form.name.trim()) st.updateTask(id, { name: form.name.trim() })
      st.updateTask(id, { assignees: form.assignees, priority: form.priority, dueDate: form.dueDate, statusId: status?.id })
    } else {
      if (!form.name.trim()) return
      id = st.createTask({ ...form, statusId: status?.id, description: form.description ? `<p>${form.description.replace(/\n/g, '<br>')}</p>` : '' })
    }
    st.setQuickCreate(null)
    st.toast('Tarefa criada')
    if (openAfter) st.openTask(id)
  }
  return (
    <Modal open onClose={() => st.setQuickCreate(null)} width={640}>
      <ModalHeader title="Nova tarefa" onClose={() => st.setQuickCreate(null)}>
        <select className="input !w-auto" value={form.listId || ''} onChange={(e) => set({ listId: e.target.value, statusId: null })}>
          {st.spaces.map((sp) => (
            <optgroup key={sp.id} label={sp.name}>
              {st.lists.filter((l) => l.spaceId === sp.id).map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
            </optgroup>
          ))}
        </select>
      </ModalHeader>
      <div className="space-y-3 p-4">
        <input autoFocus className="w-full bg-transparent text-xl font-semibold outline-none" placeholder={form.template ? 'Nome (opcional — usa o do template)' : 'Nome da tarefa'} value={form.name} onChange={(e) => set({ name: e.target.value })} onKeyDown={(e) => e.key === 'Enter' && create(false)} />
        <textarea className="input min-h-[80px]" placeholder="Descrição" value={form.description} onChange={(e) => set({ description: e.target.value })} />
        <div className="flex flex-wrap items-center gap-2">
          <Popover trigger={<button className="btn btn-outline"><StatusDot status={status} /><span className="uppercase">{status?.name}</span></button>}>
            {(c) => <StatusMenu listId={form.listId} value={status?.id} onChange={(statusId) => set({ statusId })} close={c} />}
          </Popover>
          <Popover trigger={<button className="btn btn-outline"><AvatarStack ids={form.assignees} size={18} />Responsáveis</button>}>
            {(c) => <UserPickerMenu value={form.assignees} onChange={(assignees) => set({ assignees })} close={c} />}
          </Popover>
          <Popover trigger={<button className="btn btn-outline">{form.dueDate ? fmtDay(form.dueDate) : 'Data de entrega'}</button>}>
            {(c) => <DatePickerMenu value={form.dueDate} onChange={(dueDate) => set({ dueDate })} close={c} />}
          </Popover>
          <Popover trigger={<button className="btn btn-outline"><PriorityFlag p={form.priority} label /></button>}>
            {(c) => <PriorityMenu value={form.priority} onChange={(priority) => set({ priority })} close={c} />}
          </Popover>
          <Popover trigger={<button className="btn btn-outline">{form.tags.length ? form.tags.map((t) => <TagChip key={t} name={t} />) : 'Tags'}</button>}>
            <TagMenu value={form.tags} onChange={(tags) => set({ tags })} />
          </Popover>
          {st.templates.some((t) => t.kind === 'task') && (
            <select className="input !w-auto" value={form.template} onChange={(e) => set({ template: e.target.value })}>
              <option value="">Sem template</option>
              {st.templates.filter((t) => t.kind === 'task').map((t) => <option key={t.id} value={t.id}>Template: {t.name}</option>)}
            </select>
          )}
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-zinc-200 px-4 py-3 dark:border-zinc-800">
        <button className="btn btn-outline" onClick={() => create(true)}>Criar e abrir</button>
        <button className="btn btn-primary" onClick={() => create(false)}>Criar tarefa</button>
      </div>
    </Modal>
  )
}

export function Toasts() {
  const toasts = useStore((s) => s.toasts)
  return (
    <div className="pointer-events-none fixed bottom-4 left-1/2 z-[2000] flex -translate-x-1/2 flex-col items-center gap-2">
      {toasts.map((t) => <div key={t.id} className="rounded-lg bg-zinc-900 px-4 py-2 text-white shadow-xl dark:bg-zinc-100 dark:text-zinc-900">{t.text}</div>)}
    </div>
  )
}
