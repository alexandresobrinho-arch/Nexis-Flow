// Editor rich text com toolbar + comandos "/" (estilo ClickUp Docs)
import React, { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Bold, Italic, Underline, Strikethrough, Heading1, Heading2, List, ListOrdered, ListChecks, Quote, Code, Link, Minus, Table, Type, Heading3, CalendarDays, RemoveFormatting } from 'lucide-react'
import { cx, fmtDay, todayStr } from '../lib/utils'

const SLASH = [
  { k: 'p', label: 'Texto', icon: Type, run: () => document.execCommand('formatBlock', false, 'p') },
  { k: 'h1', label: 'Título 1', icon: Heading1, run: () => document.execCommand('formatBlock', false, 'h1') },
  { k: 'h2', label: 'Título 2', icon: Heading2, run: () => document.execCommand('formatBlock', false, 'h2') },
  { k: 'h3', label: 'Título 3', icon: Heading3, run: () => document.execCommand('formatBlock', false, 'h3') },
  { k: 'ul', label: 'Lista com marcadores', icon: List, run: () => document.execCommand('insertUnorderedList') },
  { k: 'ol', label: 'Lista numerada', icon: ListOrdered, run: () => document.execCommand('insertOrderedList') },
  { k: 'check', label: 'Checklist', icon: ListChecks, run: () => document.execCommand('insertHTML', false, '<ul class="checklist"><li>Item</li></ul><p><br></p>') },
  { k: 'quote', label: 'Citação', icon: Quote, run: () => document.execCommand('formatBlock', false, 'blockquote') },
  { k: 'code', label: 'Bloco de código', icon: Code, run: () => document.execCommand('formatBlock', false, 'pre') },
  { k: 'hr', label: 'Divisor', icon: Minus, run: () => document.execCommand('insertHorizontalRule') },
  { k: 'table', label: 'Tabela 3×3', icon: Table, run: () => document.execCommand('insertHTML', false, `<table><tbody>${'<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>'.repeat(3)}</tbody></table><p><br></p>`) },
  { k: 'date', label: 'Data de hoje', icon: CalendarDays, run: () => document.execCommand('insertText', false, fmtDay(todayStr(), { full: true })) },
]

export default function RichEditor({ html, onChange, onBlur, placeholder = 'Escreva algo, ou digite "/" para comandos…', docKey, className = '', toolbar = true, minHeight = 80 }) {
  const ref = useRef(null)
  const [slash, setSlash] = useState(null) // {x,y,q,i}
  useEffect(() => { if (ref.current && ref.current.innerHTML !== (html || '')) ref.current.innerHTML = html || '' }, [docKey])

  const emit = () => onChange?.(ref.current.innerHTML)
  const exec = (cmd, val) => { ref.current.focus(); document.execCommand(cmd, false, val); emit() }
  const filtered = slash ? SLASH.filter((x) => x.label.toLowerCase().includes(slash.q.toLowerCase())) : []

  const choose = (item) => {
    for (let i = 0; i < slash.q.length + 1; i++) document.execCommand('delete')
    item.run()
    setSlash(null)
    emit()
  }

  const onKeyDown = (e) => {
    if (slash) {
      if (e.key === 'Escape') { setSlash(null); return }
      if (e.key === 'ArrowDown') { e.preventDefault(); setSlash({ ...slash, i: Math.min(filtered.length - 1, slash.i + 1) }); return }
      if (e.key === 'ArrowUp') { e.preventDefault(); setSlash({ ...slash, i: Math.max(0, slash.i - 1) }); return }
      if (e.key === 'Enter') { e.preventDefault(); if (filtered[slash.i]) choose(filtered[slash.i]); else setSlash(null); return }
      if (e.key === 'Backspace') { if (!slash.q) setSlash(null); else setSlash({ ...slash, q: slash.q.slice(0, -1), i: 0 }); return }
      if (e.key === ' ') { setSlash(null); return }
      if (e.key.length === 1) { setSlash({ ...slash, q: slash.q + e.key, i: 0 }); return }
    }
    if (e.key === '/') {
      const sel = window.getSelection()
      if (sel.rangeCount) {
        const r = sel.getRangeAt(0).getBoundingClientRect()
        const box = ref.current.getBoundingClientRect()
        setSlash({ x: r.left || box.left + 10, y: (r.bottom || box.top + 20) + 4, q: '', i: 0 })
      }
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); const url = prompt('URL do link'); if (url) exec('createLink', url) }
  }

  const onClick = (e) => {
    const li = e.target.closest?.('ul.checklist > li')
    if (li) {
      const r = li.getBoundingClientRect()
      if (e.clientX < r.left + 18) { li.classList.toggle('done'); emit() }
    }
    const a = e.target.closest?.('a')
    if (a && (e.ctrlKey || e.metaKey)) window.open(a.href, '_blank')
  }

  const B = ({ icon: I, cmd, val, title, onClick: oc }) => (
    <button type="button" title={title} onMouseDown={(e) => { e.preventDefault(); oc ? oc() : exec(cmd, val) }} className="rounded p-1 text-zinc-500 hover:bg-zinc-100 hover:text-zinc-800 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"><I size={15} /></button>
  )

  return (
    <div className={className}>
      {toolbar && (
        <div className="mb-1 flex flex-wrap items-center gap-0.5 border-b border-zinc-100 pb-1 dark:border-zinc-800">
          <B icon={Bold} cmd="bold" title="Negrito" /><B icon={Italic} cmd="italic" title="Itálico" /><B icon={Underline} cmd="underline" title="Sublinhado" /><B icon={Strikethrough} cmd="strikeThrough" title="Riscado" />
          <span className="mx-1 h-4 w-px bg-zinc-200 dark:bg-zinc-700" />
          <B icon={Heading1} cmd="formatBlock" val="h1" title="Título 1" /><B icon={Heading2} cmd="formatBlock" val="h2" title="Título 2" />
          <B icon={List} cmd="insertUnorderedList" title="Lista" /><B icon={ListOrdered} cmd="insertOrderedList" title="Lista numerada" />
          <B icon={ListChecks} title="Checklist" onClick={() => { ref.current.focus(); SLASH[6].run(); emit() }} />
          <B icon={Quote} cmd="formatBlock" val="blockquote" title="Citação" /><B icon={Code} cmd="formatBlock" val="pre" title="Código" />
          <B icon={Link} title="Link (Ctrl+K)" onClick={() => { const url = prompt('URL do link'); if (url) exec('createLink', url) }} />
          <B icon={RemoveFormatting} title="Limpar formatação" onClick={() => { exec('removeFormat'); exec('formatBlock', 'p') }} />
        </div>
      )}
      <div ref={ref} contentEditable suppressContentEditableWarning className="doc-editor" data-placeholder={placeholder} style={{ minHeight }}
        onInput={emit} onKeyDown={onKeyDown} onClick={onClick} onBlur={() => { setTimeout(() => setSlash(null), 150); onBlur?.(ref.current.innerHTML) }} />
      {slash && filtered.length > 0 && createPortal(
        <div className="menu fixed z-[1500] max-h-72 w-60 overflow-y-auto" style={{ left: Math.min(slash.x, window.innerWidth - 250), top: Math.min(slash.y, window.innerHeight - 300) }}>
          <div className="label px-2 py-1">Blocos</div>
          {filtered.map((it, i) => (
            <button key={it.k} onMouseDown={(e) => { e.preventDefault(); choose(it) }} className={cx('menu-item', i === slash.i && 'bg-zinc-100 dark:bg-zinc-800')}>
              <it.icon size={15} className="text-zinc-400" />{it.label}
            </button>
          ))}
        </div>,
        document.body,
      )}
    </div>
  )
}
