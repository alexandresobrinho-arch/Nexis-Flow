import React, { useEffect, useState } from 'react'
import { Search, Plus, Moon, Sun, Square, Play, ChevronDown, CheckSquare, FileText, Bell, Layers, Repeat } from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, Avatar } from './ui'
import { getTask, getMember } from '../lib/selectors'

function TimerChip() {
  const timer = useStore((s) => s.timer)
  const task = useStore((s) => timer && getTask(s, timer.taskId))
  const stop = useStore((s) => s.stopTimer)
  const open = useStore((s) => s.openTask)
  const [, tick] = useState(0)
  useEffect(() => { if (!timer) return; const i = setInterval(() => tick((x) => x + 1), 1000); return () => clearInterval(i) }, [timer])
  if (!timer) return null
  const sec = Math.floor((Date.now() - timer.start) / 1000)
  const hh = String(Math.floor(sec / 3600)).padStart(2, '0'), mm = String(Math.floor((sec % 3600) / 60)).padStart(2, '0'), ss = String(sec % 60).padStart(2, '0')
  return (
    <div className="flex items-center gap-2 rounded-full bg-red-50 py-1 pl-3 pr-1 text-red-600 dark:bg-red-500/10">
      <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" />
      <button className="max-w-[180px] truncate font-medium" onClick={() => open(timer.taskId)}>{task?.name}</button>
      <span className="font-mono text-[12px]">{hh}:{mm}:{ss}</span>
      <button className="rounded-full bg-red-500 p-1 text-white hover:bg-red-600" title="Parar" onClick={() => stop()}><Square size={10} fill="currentColor" /></button>
    </div>
  )
}

export default function Topbar() {
  const st = useStore()
  const me = getMember(st, st.currentUserId)
  const unread = st.notifications.filter((n) => n.userId === st.currentUserId && !n.read && !n.cleared).length
  return (
    <header className="flex h-12 shrink-0 items-center gap-3 border-b border-zinc-200 bg-white px-4 dark:border-zinc-800 dark:bg-zinc-950">
      <button onClick={() => st.setPalette(true)} className="flex w-full max-w-md items-center gap-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-1.5 text-zinc-400 hover:border-zinc-300 dark:border-zinc-800 dark:bg-zinc-900">
        <Search size={14} /><span className="flex-1 text-left">Buscar tarefas, docs, listas…</span>
        <kbd className="rounded border border-zinc-200 bg-white px-1.5 text-[10px] dark:border-zinc-700 dark:bg-zinc-800">Ctrl K</kbd>
      </button>
      <div className="flex-1" />
      <TimerChip />
      <Popover align="end" trigger={<button className="btn btn-primary"><Plus size={15} />Novo<ChevronDown size={13} /></button>}>
        {(close) => (
          <div className="menu w-52">
            <button className="menu-item" onClick={() => { st.setQuickCreate({}); close() }}><CheckSquare size={14} />Tarefa <kbd className="ml-auto text-[10px] text-zinc-400">T</kbd></button>
            <button className="menu-item" onClick={() => { const id = st.addDoc({}); st.navigate({ page: 'docs', docId: id }); close() }}><FileText size={14} />Doc</button>
            <button className="menu-item" onClick={() => { const t = prompt('Lembrete'); if (t) st.addReminder(t, new Date().toISOString().slice(0, 10)); close() }}><Bell size={14} />Lembrete</button>
            <button className="menu-item" onClick={() => { st.setModal({ type: 'newSpace' }); close() }}><Layers size={14} />Space</button>
          </div>
        )}
      </Popover>
      <button className="btn btn-ghost relative !p-1.5" onClick={() => st.navigate({ page: 'inbox' })} title="Caixa de entrada">
        <Bell size={17} />{unread > 0 && <span className="absolute -right-0.5 -top-0.5 rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">{unread}</span>}
      </button>
      <button className="btn btn-ghost !p-1.5" onClick={() => st.setTheme(st.theme === 'dark' ? 'light' : 'dark')} title="Tema">{st.theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
      <Popover align="end" trigger={<button className="flex items-center gap-1 rounded-full p-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800"><Avatar userId={st.currentUserId} size={28} /><ChevronDown size={13} className="text-zinc-400" /></button>}>
        {(close) => (
          <div className="menu w-64">
            <div className="flex items-center gap-2 px-2 py-2"><Avatar userId={me?.id} size={32} /><div><div className="font-semibold">{me?.name}</div><div className="text-[11px] text-zinc-400">{me?.email}</div></div></div>
            <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
            <div className="label flex items-center gap-1 px-2 py-1"><Repeat size={11} />Simular como outro membro</div>
            {st.members.filter((m) => m.id !== st.currentUserId).map((m) => (
              <button key={m.id} className="menu-item" onClick={() => { st.setCurrentUser(m.id); close() }}><Avatar userId={m.id} size={20} />{m.name}<span className="ml-auto text-[10px] text-zinc-400">{m.role}</span></button>
            ))}
            <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
            <button className="menu-item" onClick={() => { st.navigate({ page: 'settings' }); close() }}>Configurações</button>
          </div>
        )}
      </Popover>
    </header>
  )
}
