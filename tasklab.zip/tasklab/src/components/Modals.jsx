import React, { useState } from 'react'
import { Plus, Trash2, ArrowUp, ArrowDown, Zap, Play, Pause, Pencil, CheckCircle2, XCircle, Sparkles, Check } from 'lucide-react'
import { useStore } from '../store/store'
import { Modal, ModalHeader, Popover, ColorPicker, Toggle, Tabs, Icon, StatusDot, Confirm } from './ui'
import { FieldDefinitionForm, FIELD_TYPES } from './fields/CustomField'
import { TRIGGERS, ACTIONS, CONDITION_FIELDS, OP_LABELS, describeAutomation } from '../lib/automations'
import { getStatusesForLocation, locationName, getFieldsForLocation, listsInLocation, getList, getTask, getFolder, getSpace } from '../lib/selectors'
import { PRIORITIES, PALETTE, STATUS_TYPES, uid, cx, fmtRelative } from '../lib/utils'

// ---------------- STATUS ----------------
function StatusEditor({ locType, locId, close }) {
  const s = useStore()
  const item = locType === 'space' ? getSpace(s, locId) : locType === 'folder' ? getFolder(s, locId) : getList(s, locId)
  const inherited = locType !== 'space' && !item.statuses
  const [custom, setCustom] = useState(!inherited)
  const [list, setList] = useState(() => (getStatusesForLocation(s, locType, locId)).map((x) => ({ ...x })))
  const save = () => {
    if (!custom) s.setStatuses(locType, locId, null)
    else {
      const fixed = list.filter((x) => x.name.trim()).map((x, i) => ({ ...x, name: x.name.trim().toUpperCase(), order: i }))
      if (!fixed.length) return
      s.setStatuses(locType, locId, fixed)
    }
    s.toast('Status salvos')
    close()
  }
  const types = ['notstarted', 'active', 'done', 'closed']
  return (
    <>
      <ModalHeader title={`Status — ${item.name}`} onClose={close} />
      <div className="max-h-[65vh] overflow-y-auto p-4">
        {locType !== 'space' && (
          <div className="mb-4 flex gap-2">
            <button onClick={() => setCustom(false)} className={cx('flex-1 rounded-lg border p-3 text-left', !custom ? 'border-accent bg-accent-50 dark:bg-accent/10' : 'border-zinc-200 dark:border-zinc-700')}><div className="font-semibold">Herdar do {locType === 'list' && item.folderId ? 'Folder/Space' : 'Space'}</div><div className="text-[12px] text-zinc-500">Usa os status da localização pai</div></button>
            <button onClick={() => setCustom(true)} className={cx('flex-1 rounded-lg border p-3 text-left', custom ? 'border-accent bg-accent-50 dark:bg-accent/10' : 'border-zinc-200 dark:border-zinc-700')}><div className="font-semibold">Personalizado</div><div className="text-[12px] text-zinc-500">Status próprios para esta {locType === 'list' ? 'lista' : 'pasta'}</div></button>
          </div>
        )}
        <div className={cx(!custom && 'pointer-events-none opacity-50')}>
          {types.map((type) => (
            <div key={type} className="mb-4">
              <div className="label mb-1">{STATUS_TYPES[type]}</div>
              {list.map((st, i) => st.type !== type ? null : (
                <div key={st.id} className="mb-1 flex items-center gap-2">
                  <Popover trigger={<button className="h-6 w-6 rounded-md" style={{ background: st.color }} />}>{(c) => <div className="menu"><ColorPicker value={st.color} onChange={(color) => { setList(list.map((x, j) => (j === i ? { ...x, color } : x))); c() }} /></div>}</Popover>
                  <input className="input uppercase" value={st.name} onChange={(e) => setList(list.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
                  <select className="input !w-36" value={st.type} onChange={(e) => setList(list.map((x, j) => (j === i ? { ...x, type: e.target.value } : x)))}>{types.map((t) => <option key={t} value={t}>{STATUS_TYPES[t]}</option>)}</select>
                  <button className="btn btn-ghost !p-1" onClick={() => { if (i > 0) { const l = [...list]; [l[i - 1], l[i]] = [l[i], l[i - 1]]; setList(l) } }}><ArrowUp size={13} /></button>
                  <button className="btn btn-ghost !p-1" onClick={() => { if (i < list.length - 1) { const l = [...list]; [l[i + 1], l[i]] = [l[i], l[i + 1]]; setList(l) } }}><ArrowDown size={13} /></button>
                  <button className="btn btn-ghost !p-1 text-red-500" onClick={() => setList(list.filter((_, j) => j !== i))}><Trash2 size={13} /></button>
                </div>
              ))}
              <button className="btn btn-ghost text-accent" onClick={() => setList([...list, { id: uid('s'), name: 'NOVO STATUS', color: PALETTE[list.length % PALETTE.length], type, order: list.length }])}><Plus size={13} />Adicionar status</button>
            </div>
          ))}
          <div className="rounded-lg bg-zinc-50 p-3 text-[12px] text-zinc-500 dark:bg-zinc-800/50">Tarefas em status removidos voltam para o primeiro status. "Concluído" e "Fechado" marcam a tarefa como finalizada (dispara recorrência, desbloqueia dependências e automações).</div>
        </div>
      </div>
      <div className="flex justify-end gap-2 border-t border-zinc-200 px-4 py-3 dark:border-zinc-800"><button className="btn btn-outline" onClick={close}>Cancelar</button><button className="btn btn-primary" onClick={save}>Salvar</button></div>
    </>
  )
}

// ---------------- CAMPOS ----------------
function FieldsManager({ locType, locId, close }) {
  const s = useStore()
  const [editing, setEditing] = useState(null) // field | 'new'
  const [del, setDel] = useState(null)
  const own = s.fields.filter((f) => f.locType === locType && f.locId === locId)
  const inherited = getFieldsForLocation(s, locType, locId).filter((f) => !own.includes(f))
  const where = (f) => f.locType === 'workspace' ? 'Workspace' : `${{ space: 'Space', folder: 'Pasta', list: 'Lista' }[f.locType]}: ${locationName(s, f.locType, f.locId)}`
  const typeLabel = (t) => FIELD_TYPES.find((x) => x[0] === t)?.[1]
  const usage = (f) => s.tasks.filter((t) => t.cf?.[f.id] !== undefined && t.cf?.[f.id] !== null && t.cf?.[f.id] !== '').length
  return (
    <>
      <ModalHeader title={`Campos personalizados — ${locationName(s, locType, locId)}`} onClose={close} />
      <div className="max-h-[70vh] overflow-y-auto p-4">
        {editing ? (
          <FieldDefinitionForm initial={editing === 'new' ? null : editing} locked={editing !== 'new'} onCancel={() => setEditing(null)} onSubmit={(f) => {
            if (editing === 'new') s.addField({ ...f, locType, locId }); else s.updateField(editing.id, f)
            setEditing(null)
          }} />
        ) : (
          <>
            <div className="mb-2 flex items-center"><span className="font-semibold">Nesta localização</span><div className="flex-1" /><button className="btn btn-primary" onClick={() => setEditing('new')}><Plus size={14} />Novo campo</button></div>
            {!own.length && <div className="rounded-lg border border-dashed border-zinc-300 p-4 text-center text-zinc-400 dark:border-zinc-700">Nenhum campo criado aqui ainda.</div>}
            <div className="space-y-1">
              {own.map((f) => (
                <div key={f.id} className="flex items-center gap-2 rounded-lg border border-zinc-200 px-3 py-2 dark:border-zinc-800">
                  <span className="font-medium">{f.name}</span>{f.required && <span className="text-[10px] text-red-500">obrigatório</span>}
                  <span className="rounded bg-zinc-100 px-1.5 text-[11px] text-zinc-500 dark:bg-zinc-800">{typeLabel(f.type)}</span>
                  <span className="text-[11px] text-zinc-400">{usage(f)} tarefas preenchidas</span>
                  <div className="flex-1" />
                  <button className="btn btn-ghost !p-1" onClick={() => setEditing(f)}><Pencil size={13} /></button>
                  <button className="btn btn-ghost !p-1 text-red-500" onClick={() => setDel(f)}><Trash2 size={13} /></button>
                </div>
              ))}
            </div>
            {inherited.length > 0 && (
              <>
                <div className="mb-2 mt-5 font-semibold">Herdados / de outras localizações abaixo</div>
                <div className="space-y-1">
                  {inherited.map((f) => (
                    <div key={f.id} className="flex items-center gap-2 rounded-lg bg-zinc-50 px-3 py-2 dark:bg-zinc-800/50">
                      <span className="font-medium">{f.name}</span><span className="rounded bg-white px-1.5 text-[11px] text-zinc-500 dark:bg-zinc-900">{typeLabel(f.type)}</span>
                      <span className="text-[11px] text-zinc-400">{where(f)}</span>
                      <div className="flex-1" /><button className="btn btn-ghost !p-1" onClick={() => setEditing(f)}><Pencil size={13} /></button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </div>
      <Confirm open={!!del} onClose={() => setDel(null)} onConfirm={() => s.deleteField(del.id)} title={`Excluir o campo "${del?.name}"?`} text="Os valores preenchidos nas tarefas serão apagados." />
    </>
  )
}

// ---------------- AUTOMAÇÕES ----------------
function ParamInput({ param, value, onChange, locType, locId, s }) {
  const statuses = getStatusesForLocation(s, locType, locId)
  switch (param) {
    case 'fromStatus':
    case 'toStatus':
    case 'status':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">{param === 'status' ? 'Selecione…' : 'Qualquer status'}</option>{statuses.map((x) => <option key={x.id} value={x.name}>{param === 'fromStatus' ? 'de ' : param === 'toStatus' ? 'para ' : ''}{x.name}</option>)}</select>
    case 'priority':
    case 'toPriority':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">{param === 'toPriority' ? 'Qualquer' : 'Nenhuma'}</option>{[1, 2, 3, 4].map((p) => <option key={p} value={p}>{PRIORITIES[p].label}</option>)}</select>
    case 'user':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">Qualquer pessoa / selecione…</option>{s.members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
    case 'tag':
      return <input className="input" list="tags-dl" value={value || ''} onChange={(e) => onChange(e.target.value.toLowerCase())} placeholder="tag" />
    case 'days':
      return <input type="number" className="input" value={value ?? 0} onChange={(e) => onChange(Number(e.target.value))} placeholder="dias a partir de hoje" />
    case 'text':
    case 'name':
      return <input className="input" value={value || ''} onChange={(e) => onChange(e.target.value)} placeholder={param === 'text' ? 'Texto — use {{task.name}}' : 'Nome — use {{task.name}}'} />
    case 'list':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">Selecione a lista…</option>{s.lists.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
    case 'template':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">Selecione…</option>{s.templates.filter((t) => t.kind === 'task').map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
    case 'typeId':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">Qualquer / selecione…</option>{s.taskTypes.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
    case 'field':
      return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value)}><option value="">Qualquer campo / selecione…</option>{getFieldsForLocation(s, locType, locId).filter((f) => !['formula', 'rollup'].includes(f.type)).map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</select>
    default: return null
  }
}

function CFValueInput({ field, value, onChange }) {
  if (!field) return null
  if (field.type === 'checkbox') return <select className="input" value={String(!!value)} onChange={(e) => onChange(e.target.value === 'true')}><option value="true">Marcado</option><option value="false">Desmarcado</option></select>
  if (field.type === 'dropdown') return <select className="input" value={value || ''} onChange={(e) => onChange(e.target.value || null)}><option value="">Vazio</option>{field.config.options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
  if (field.type === 'labels') return <select className="input" value={(value || [])[0] || ''} onChange={(e) => onChange(e.target.value ? [e.target.value] : [])}><option value="">Vazio</option>{field.config.options.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
  if (field.type === 'date') return <input type="date" className="input" value={value || ''} onChange={(e) => onChange(e.target.value)} />
  if (['number', 'money', 'rating', 'progress'].includes(field.type)) return <input type="number" className="input" value={value ?? ''} onChange={(e) => onChange(e.target.value === '' ? null : Number(e.target.value))} />
  return <input className="input" value={value || ''} onChange={(e) => onChange(e.target.value)} />
}

const SUGGESTED = [
  { name: 'Ao concluir, arquivar', trigger: { type: 'status_changed', params: { toStatus: '__done' } }, actions: [{ type: 'archive', params: {} }] },
  { name: 'Nova tarefa → atribuir ao criador', trigger: { type: 'task_created', params: {} }, actions: [{ type: 'assign_creator', params: {} }] },
  { name: 'Prioridade urgente → notificar', trigger: { type: 'priority_changed', params: { toPriority: '1' } }, actions: [{ type: 'notify', params: { user: 'u1', text: 'Uma tarefa virou URGENTE' } }, { type: 'add_tag', params: { tag: 'urgente' } }] },
  { name: 'Data de entrega chegou → urgente', trigger: { type: 'due_date_arrives', params: {} }, actions: [{ type: 'change_priority', params: { priority: '1' } }] },
  { name: 'Checklist completa → próximo status', trigger: { type: 'checklists_resolved', params: {} }, actions: [{ type: 'add_comment', params: { text: 'Checklist de "{{task.name}}" concluída ✅' } }] },
  { name: 'Desbloqueada → avisar responsável', trigger: { type: 'task_unblocked', params: {} }, actions: [{ type: 'add_comment', params: { text: '🔓 Dependências concluídas — pode começar!' } }] },
]

function AutomationBuilder({ initial, locType, locId, onDone }) {
  const s = useStore()
  const [a, setA] = useState(() => initial ? JSON.parse(JSON.stringify(initial)) : { name: '', trigger: { type: 'task_created', params: {} }, conditions: [], actions: [{ type: 'change_status', params: {} }] })
  const trig = TRIGGERS.find((t) => t.id === a.trigger.type)
  const fields = getFieldsForLocation(s, locType, locId)
  const save = () => {
    const data = { ...a, name: a.name || describeAutomation(s, a).slice(0, 60) }
    if (initial?.id) s.updateAutomation(initial.id, data); else s.addAutomation({ ...data, locType, locId })
    onDone()
  }
  return (
    <div className="space-y-4">
      <input className="input text-[14px] font-semibold" placeholder="Nome da automação (opcional)" value={a.name} onChange={(e) => setA({ ...a, name: e.target.value })} />
      <datalist id="tags-dl">{s.tags.map((t) => <option key={t.name} value={t.name} />)}</datalist>
      <div className="rounded-xl border border-zinc-200 p-3 dark:border-zinc-800">
        <div className="label mb-2 text-accent">Quando (gatilho)</div>
        <select className="input" value={a.trigger.type} onChange={(e) => setA({ ...a, trigger: { type: e.target.value, params: {} } })}>{TRIGGERS.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}</select>
        {trig?.params && <div className="mt-2 grid grid-cols-2 gap-2">{trig.params.map((p) => <ParamInput key={p} s={s} param={p} locType={locType} locId={locId} value={a.trigger.params[p]} onChange={(v) => setA({ ...a, trigger: { ...a.trigger, params: { ...a.trigger.params, [p]: v } } })} />)}</div>}
      </div>
      <div className="rounded-xl border border-zinc-200 p-3 dark:border-zinc-800">
        <div className="label mb-2 text-amber-600">Se (condições — opcional)</div>
        {a.conditions.map((c, i) => {
          const def = CONDITION_FIELDS.find((x) => x.id === c.field)
          const setC = (p) => setA({ ...a, conditions: a.conditions.map((x, j) => (j === i ? { ...x, ...p } : x)) })
          const noVal = ['empty', 'notempty', 'overdue', 'yes', 'no'].includes(c.op)
          return (
            <div key={i} className="mb-2 flex gap-2">
              <select className="input !w-40" value={c.field} onChange={(e) => setC({ field: e.target.value, op: CONDITION_FIELDS.find((x) => x.id === e.target.value).ops[0], value: '' })}>{CONDITION_FIELDS.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</select>
              {c.field === 'cf' && <select className="input !w-40" value={c.fieldId || ''} onChange={(e) => setC({ fieldId: e.target.value })}><option value="">Campo…</option>{fields.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</select>}
              <select className="input !w-36" value={c.op} onChange={(e) => setC({ op: e.target.value })}>{def.ops.map((o) => <option key={o} value={o}>{OP_LABELS[o]}</option>)}</select>
              {!noVal && (c.field === 'status' ? <ParamInput s={s} param="status" locType={locType} locId={locId} value={c.value} onChange={(v) => setC({ value: v })} />
                : c.field === 'priority' ? <ParamInput s={s} param="priority" value={c.value} onChange={(v) => setC({ value: v })} locType={locType} locId={locId} />
                : c.field === 'assignee' ? <ParamInput s={s} param="user" value={c.value} onChange={(v) => setC({ value: v })} locType={locType} locId={locId} />
                : c.field === 'type' ? <ParamInput s={s} param="typeId" value={c.value} onChange={(v) => setC({ value: v })} locType={locType} locId={locId} />
                : c.field === 'cf' ? <CFValueInput field={fields.find((f) => f.id === c.fieldId)} value={c.value} onChange={(v) => setC({ value: v })} />
                : <input className="input" value={c.value || ''} onChange={(e) => setC({ value: e.target.value })} />)}
              <button className="btn btn-ghost !p-1" onClick={() => setA({ ...a, conditions: a.conditions.filter((_, j) => j !== i) })}><Trash2 size={13} /></button>
            </div>
          )
        })}
        <button className="btn btn-ghost text-amber-600" onClick={() => setA({ ...a, conditions: [...a.conditions, { field: 'status', op: 'is', value: '' }] })}><Plus size={13} />Adicionar condição</button>
      </div>
      <div className="rounded-xl border border-zinc-200 p-3 dark:border-zinc-800">
        <div className="label mb-2 text-emerald-600">Então (ações, em ordem)</div>
        {a.actions.map((act, i) => {
          const def = ACTIONS.find((x) => x.id === act.type)
          const setAct = (p) => setA({ ...a, actions: a.actions.map((x, j) => (j === i ? { ...x, ...p } : x)) })
          return (
            <div key={i} className="mb-2 rounded-lg bg-zinc-50 p-2 dark:bg-zinc-800/50">
              <div className="flex gap-2">
                <span className="pt-1.5 text-[11px] font-bold text-zinc-400">{i + 1}.</span>
                <select className="input" value={act.type} onChange={(e) => setAct({ type: e.target.value, params: {} })}>{ACTIONS.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</select>
                {i > 0 && <button className="btn btn-ghost !p-1" onClick={() => { const l = [...a.actions]; [l[i - 1], l[i]] = [l[i], l[i - 1]]; setA({ ...a, actions: l }) }}><ArrowUp size={13} /></button>}
                <button className="btn btn-ghost !p-1" onClick={() => setA({ ...a, actions: a.actions.filter((_, j) => j !== i) })}><Trash2 size={13} /></button>
              </div>
              {def?.params && (
                <div className="mt-2 grid grid-cols-2 gap-2 pl-5">
                  {def.params.filter((p) => p !== 'value').map((p) => <ParamInput key={p} s={s} param={p} locType={locType} locId={locId} value={act.params[p]} onChange={(v) => setAct({ params: { ...act.params, [p]: v } })} />)}
                  {def.params.includes('value') && <CFValueInput field={fields.find((f) => f.id === act.params.field)} value={act.params.value} onChange={(v) => setAct({ params: { ...act.params, value: v } })} />}
                </div>
              )}
            </div>
          )
        })}
        <button className="btn btn-ghost text-emerald-600" onClick={() => setA({ ...a, actions: [...a.actions, { type: 'add_comment', params: {} }] })}><Plus size={13} />Adicionar ação</button>
      </div>
      <div className="rounded-lg bg-accent-50 p-3 text-[12px] text-accent dark:bg-accent/10">{describeAutomation(s, a)}{a.conditions.length ? ` · ${a.conditions.length} condição(ões)` : ''}</div>
      <div className="flex justify-end gap-2"><button className="btn btn-outline" onClick={onDone}>Cancelar</button><button className="btn btn-primary" disabled={!a.actions.length} onClick={save}>Salvar automação</button></div>
    </div>
  )
}

function AutomationsModal({ locType, locId, close }) {
  const s = useStore()
  const [tab, setTab] = useState('manage')
  const [editing, setEditing] = useState(null)
  const autos = s.automations.filter((a) => a.locType === locType && a.locId === locId)
  const inherited = s.automations.filter((a) => !autos.includes(a) && (
    (a.locType === 'space' && (getList(s, locId)?.spaceId === a.locId || getFolder(s, locId)?.spaceId === a.locId)) ||
    (a.locType === 'folder' && getList(s, locId)?.folderId === a.locId)))
  const logs = s.automationLog.filter((l) => [...autos, ...inherited].some((a) => a.id === l.automationId))
  const statuses = getStatusesForLocation(s, locType, locId)
  const addSuggested = (sg) => {
    const doneStatus = statuses.find((x) => x.type === 'done' || x.type === 'closed')?.name
    const trigger = JSON.parse(JSON.stringify(sg.trigger))
    if (trigger.params.toStatus === '__done') trigger.params.toStatus = doneStatus
    s.addAutomation({ name: sg.name, trigger, conditions: [], actions: sg.actions, locType, locId })
    s.toast('Automação adicionada')
    setTab('manage')
  }
  const Row = ({ a, readonly }) => (
    <div className="flex items-center gap-3 rounded-lg border border-zinc-200 px-3 py-2.5 dark:border-zinc-800">
      <Zap size={16} className={a.active ? 'text-accent' : 'text-zinc-300'} />
      <div className="min-w-0 flex-1">
        <div className="font-medium">{a.name}</div>
        <div className="truncate text-[12px] text-zinc-500">{describeAutomation(s, a)}</div>
        <div className="text-[11px] text-zinc-400">{a.runs || 0} execuções{a.lastRun ? ` · última ${fmtRelative(a.lastRun)}` : ''}{readonly ? ` · herdada de ${locationName(s, a.locType, a.locId)}` : ''}</div>
      </div>
      <Toggle checked={a.active} onChange={(v) => s.updateAutomation(a.id, { active: v })} />
      <button className="btn btn-ghost !p-1" onClick={() => { setEditing(a); setTab('edit') }}><Pencil size={13} /></button>
      {!readonly && <button className="btn btn-ghost !p-1 text-red-500" onClick={() => s.deleteAutomation(a.id)}><Trash2 size={13} /></button>}
    </div>
  )
  return (
    <>
      <ModalHeader title={`Automações — ${locationName(s, locType, locId)}`} onClose={close}>
        <button className="btn btn-primary" onClick={() => { setEditing(null); setTab('edit') }}><Plus size={14} />Nova automação</button>
      </ModalHeader>
      <div className="px-4"><Tabs value={tab} onChange={setTab} tabs={[['manage', 'Gerenciar', autos.length], ['edit', editing ? 'Editar' : 'Criar'], ['templates', 'Sugestões'], ['log', 'Atividade', logs.length]]} /></div>
      <div className="max-h-[65vh] overflow-y-auto p-4">
        {tab === 'manage' && (
          <div className="space-y-2">
            {!autos.length && !inherited.length && <div className="py-8 text-center text-zinc-400">Nenhuma automação aqui. Crie uma ou use uma sugestão.</div>}
            {autos.map((a) => <Row key={a.id} a={a} />)}
            {inherited.length > 0 && <div className="label pt-3">Herdadas da hierarquia</div>}
            {inherited.map((a) => <Row key={a.id} a={a} readonly />)}
          </div>
        )}
        {tab === 'edit' && <AutomationBuilder key={editing?.id || 'new'} initial={editing} locType={locType} locId={locId} onDone={() => { setEditing(null); setTab('manage') }} />}
        {tab === 'templates' && (
          <div className="grid grid-cols-2 gap-2">
            {SUGGESTED.map((sg) => (
              <button key={sg.name} onClick={() => addSuggested(sg)} className="rounded-xl border border-zinc-200 p-3 text-left hover:border-accent dark:border-zinc-800">
                <Sparkles size={15} className="mb-1 text-accent" />
                <div className="font-medium">{sg.name}</div>
                <div className="text-[12px] text-zinc-500">{describeAutomation(s, sg)}</div>
              </button>
            ))}
          </div>
        )}
        {tab === 'log' && (
          <div className="space-y-1">
            {!logs.length && <div className="py-8 text-center text-zinc-400">Nenhuma execução ainda.</div>}
            {logs.map((l) => (
              <div key={l.id} className="flex items-center gap-2 rounded px-2 py-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/50">
                {l.ok ? <CheckCircle2 size={14} className="text-emerald-500" /> : <XCircle size={14} className="text-red-500" />}
                <span className="font-medium">{s.automations.find((a) => a.id === l.automationId)?.name}</span>
                <span className="text-zinc-400">em</span>
                <button className="truncate text-accent hover:underline" onClick={() => { close(); s.openTask(l.taskId) }}>{getTask(s, l.taskId)?.name || 'tarefa removida'}</button>
                <span className="truncate text-[11px] text-zinc-400">{l.message}</span>
                <span className="ml-auto shrink-0 text-[11px] text-zinc-400">{fmtRelative(l.at)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  )
}

// ---------------- NOVO SPACE ----------------
function NewSpace({ close }) {
  const s = useStore()
  const [name, setName] = useState('')
  const [color, setColor] = useState('#6d5dfc')
  const [icon, setIcon] = useState('Layers')
  const [priv, setPriv] = useState(false)
  const [preset, setPreset] = useState('simple')
  const presets = {
    simple: ['A FAZER:notstarted:#a1a1aa', 'EM ANDAMENTO:active:#3b82f6', 'CONCLUÍDO:closed:#10b981'],
    kanban: ['BACKLOG:notstarted:#a1a1aa', 'A FAZER:notstarted:#64748b', 'FAZENDO:active:#6d5dfc', 'REVISÃO:active:#f59e0b', 'FEITO:done:#10b981', 'FECHADO:closed:#16a34a'],
    scrum: ['A FAZER:notstarted:#a1a1aa', 'EM PROGRESSO:active:#6d5dfc', 'CODE REVIEW:active:#ec4899', 'QA:active:#f97316', 'PRONTO:done:#10b981', 'FECHADO:closed:#16a34a'],
  }
  const create = () => {
    if (!name.trim()) return
    const statuses = presets[preset].map((p, i) => { const [n, type, c] = p.split(':'); return { id: uid('s'), name: n, type, color: c, order: i } })
    const id = s.addSpace({ name: name.trim(), color, icon, private: priv, statuses })
    const lid = s.addList(id, null, 'Lista')
    s.navigate({ page: 'location', locType: 'list', locId: lid })
    close()
  }
  return (
    <>
      <ModalHeader title="Criar Space" onClose={close} />
      <div className="space-y-4 p-4">
        <div className="flex gap-2">
          <Popover trigger={<button className="flex h-10 w-10 items-center justify-center rounded-lg text-white" style={{ background: color }}><Icon name={icon} size={18} /></button>}>
            <div className="menu w-64"><ColorPicker value={color} onChange={setColor} />
              <div className="grid grid-cols-6 gap-1 p-2">{['Layers', 'Megaphone', 'Rocket', 'User', 'Briefcase', 'Code', 'Heart', 'Star', 'Zap', 'BookOpen', 'Target', 'Globe'].map((n) => <button key={n} onClick={() => setIcon(n)} className={cx('flex h-8 w-8 items-center justify-center rounded', icon === n && 'bg-zinc-100 dark:bg-zinc-800')}><Icon name={n} size={15} /></button>)}</div>
            </div>
          </Popover>
          <input autoFocus className="input !text-[15px]" placeholder="Nome do Space (ex: Marketing, Engenharia)" value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && create()} />
        </div>
        <div>
          <div className="label mb-2">Fluxo de status</div>
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(presets).map(([k, arr]) => (
              <button key={k} onClick={() => setPreset(k)} className={cx('rounded-lg border p-2 text-left', preset === k ? 'border-accent bg-accent-50 dark:bg-accent/10' : 'border-zinc-200 dark:border-zinc-700')}>
                <div className="mb-1 font-semibold capitalize">{{ simple: 'Simples', kanban: 'Kanban', scrum: 'Scrum' }[k]}</div>
                <div className="flex flex-wrap gap-1">{arr.map((p) => { const [n, , c] = p.split(':'); return <span key={n} className="rounded px-1 text-[9px] font-bold text-white" style={{ background: c }}>{n}</span> })}</div>
              </button>
            ))}
          </div>
        </div>
        <label className="flex items-center gap-2"><Toggle checked={priv} onChange={setPriv} />Space privado</label>
      </div>
      <div className="flex justify-end gap-2 border-t border-zinc-200 px-4 py-3 dark:border-zinc-800"><button className="btn btn-outline" onClick={close}>Cancelar</button><button className="btn btn-primary" onClick={create}>Criar Space</button></div>
    </>
  )
}

function ListFromTemplate({ locType, locId, close }) {
  const s = useStore()
  const tpls = s.templates.filter((t) => t.kind === 'list')
  const [tpl, setTpl] = useState(tpls[0]?.id || '')
  const [name, setName] = useState('')
  const spaceId = locType === 'space' ? locId : getFolder(s, locId)?.spaceId
  const folderId = locType === 'folder' ? locId : null
  return (
    <>
      <ModalHeader title="Nova lista a partir de template" onClose={close} />
      <div className="space-y-3 p-4">
        {!tpls.length ? <div className="text-zinc-500">Nenhum template de lista ainda. Abra o menu “…” de uma lista e use “Salvar como template”.</div> : (
          <>
            <select className="input" value={tpl} onChange={(e) => setTpl(e.target.value)}>{tpls.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.data.tasks.length} tarefas)</option>)}</select>
            <input className="input" placeholder="Nome da nova lista (opcional)" value={name} onChange={(e) => setName(e.target.value)} />
          </>
        )}
      </div>
      <div className="flex justify-end gap-2 border-t border-zinc-200 px-4 py-3 dark:border-zinc-800">
        <button className="btn btn-outline" onClick={close}>Cancelar</button>
        <button className="btn btn-primary" disabled={!tpl} onClick={() => { const id = s.createListFromTemplate(tpl, spaceId, folderId, name); s.navigate({ page: 'location', locType: 'list', locId: id }); close() }}>Criar lista</button>
      </div>
    </>
  )
}

export default function ModalHost() {
  const s = useStore()
  const m = s.modal
  if (!m) return null
  const close = () => s.setModal(null)
  const widths = { statuses: 640, fields: 680, automations: 820, newSpace: 560, listFromTemplate: 480 }
  return (
    <Modal open onClose={close} width={widths[m.type] || 600}>
      {m.type === 'statuses' && <StatusEditor {...m} close={close} />}
      {m.type === 'fields' && <FieldsManager {...m} close={close} />}
      {m.type === 'automations' && <AutomationsModal {...m} close={close} />}
      {m.type === 'newSpace' && <NewSpace close={close} />}
      {m.type === 'listFromTemplate' && <ListFromTemplate {...m} close={close} />}
    </Modal>
  )
}
