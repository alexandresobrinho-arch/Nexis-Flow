// Renderização + edição de todos os tipos de campo personalizado
import React, { useEffect, useState } from 'react'
import { Check, X, ExternalLink, Mail, Phone, Calculator, Sigma, Star } from 'lucide-react'
import { useStore } from '../../store/store'
import { Popover, UserPickerMenu, AvatarStack, DatePickerMenu, ProgressBar } from '../ui'
import { cfValue } from '../../lib/selectors'
import { money, fmtDay, cx, uid, PALETTE } from '../../lib/utils'

export const FIELD_TYPES = [
  ['text', 'Texto'], ['textarea', 'Texto longo'], ['number', 'Número'], ['money', 'Dinheiro'], ['dropdown', 'Dropdown'],
  ['labels', 'Rótulos (multi)'], ['date', 'Data'], ['checkbox', 'Checkbox'], ['email', 'Email'], ['phone', 'Telefone'],
  ['url', 'Website (URL)'], ['rating', 'Avaliação'], ['progress', 'Progresso (manual)'], ['people', 'Pessoas'],
  ['formula', 'Fórmula'], ['rollup', 'Rollup (soma das subtarefas)'],
]

function TextEditor({ value, onSave, type, close }) {
  const [v, setV] = useState(value ?? '')
  const commit = () => { onSave(type === 'number' || type === 'money' ? (v === '' ? null : Number(v)) : v || null); close() }
  const Tag = type === 'textarea' ? 'textarea' : 'input'
  return (
    <div className="menu w-72 p-2">
      <Tag autoFocus type={type === 'number' || type === 'money' ? 'number' : type === 'email' ? 'email' : 'text'} className={cx('input', type === 'textarea' && 'min-h-[100px]')} value={v} onChange={(e) => setV(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter' && type !== 'textarea') commit() }} placeholder={type === 'url' ? 'https://' : ''} />
      <div className="mt-2 flex justify-end gap-1">
        {value != null && value !== '' && <button className="btn btn-ghost text-red-500" onClick={() => { onSave(null); close() }}>Limpar</button>}
        <button className="btn btn-primary" onClick={commit}>Salvar</button>
      </div>
    </div>
  )
}

function OptionsMenu({ field, value, onSave, multi, close }) {
  const updateField = useStore((s) => s.updateField)
  const [q, setQ] = useState('')
  const opts = field.config?.options || []
  const vals = multi ? value || [] : value ? [value] : []
  const pick = (id) => {
    if (multi) onSave(vals.includes(id) ? vals.filter((x) => x !== id) : [...vals, id])
    else { onSave(vals.includes(id) ? null : id); close() }
  }
  const create = () => {
    const id = uid('o')
    updateField(field.id, { config: { ...field.config, options: [...opts, { id, name: q.trim(), color: PALETTE[opts.length % PALETTE.length] }] } })
    pick(id); setQ('')
  }
  const list = opts.filter((o) => o.name.toLowerCase().includes(q.toLowerCase()))
  return (
    <div className="menu w-60">
      <div className="p-1"><input autoFocus className="input" placeholder="Buscar ou criar opção" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && q.trim() && !list.length && create()} /></div>
      {list.map((o) => (
        <button key={o.id} className="menu-item" onClick={() => pick(o.id)}>
          <span className="rounded px-2 py-0.5 text-[12px] font-medium text-white" style={{ background: o.color }}>{o.name}</span>
          {vals.includes(o.id) && <Check size={14} className="ml-auto text-accent" />}
        </button>
      ))}
      {q.trim() && !opts.some((o) => o.name.toLowerCase() === q.trim().toLowerCase()) && <button className="menu-item text-accent" onClick={create}>+ Criar "{q.trim()}"</button>}
      {vals.length > 0 && <button className="menu-item text-zinc-500" onClick={() => { onSave(multi ? [] : null); close() }}><X size={13} />Limpar</button>}
    </div>
  )
}

export function OptionPill({ field, id }) {
  const o = (field.config?.options || []).find((x) => x.id === id)
  if (!o) return null
  return <span className="inline-block max-w-[140px] truncate whitespace-nowrap rounded px-2 py-0.5 text-[11px] font-medium text-white" style={{ background: o.color }}>{o.name}</span>
}

// Exibe o valor (sem edição)
export function CFDisplay({ task, field }) {
  const s = useStore()
  const v = cfValue(s, task, field)
  const empty = v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length)
  switch (field.type) {
    case 'checkbox': return <span className={cx('inline-flex h-4 w-4 items-center justify-center rounded border', v ? 'border-accent bg-accent text-white' : 'border-zinc-300 dark:border-zinc-600')}>{v && <Check size={11} strokeWidth={3} />}</span>
    case 'rating': {
      const max = field.config?.max || 5
      return <span className="inline-flex gap-0.5">{Array.from({ length: max }).map((_, i) => <Star key={i} size={13} className={i < (v || 0) ? 'text-amber-400' : 'text-zinc-200 dark:text-zinc-700'} fill="currentColor" />)}</span>
    }
    case 'progress': return <span className="flex w-24 items-center gap-1.5"><ProgressBar pct={v || 0} /><span className="text-[11px] text-zinc-500">{v || 0}%</span></span>
    default: break
  }
  if (empty) return <span className="text-zinc-300 dark:text-zinc-600">—</span>
  switch (field.type) {
    case 'money': return <span>{money(v, field.config?.currency)}</span>
    case 'formula': return <span className="inline-flex items-center gap-1 font-medium"><Calculator size={12} className="text-zinc-400" />{field.config?.currency ? money(v, field.config.currency) : v}</span>
    case 'rollup': return <span className="inline-flex items-center gap-1 font-medium"><Sigma size={12} className="text-zinc-400" />{v}</span>
    case 'dropdown': return <OptionPill field={field} id={v} />
    case 'labels': return <span className="flex flex-wrap gap-1">{v.map((id) => <OptionPill key={id} field={field} id={id} />)}</span>
    case 'date': return <span>{fmtDay(v)}</span>
    case 'people': return <AvatarStack ids={v} size={20} />
    case 'url': return <a href={v} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="inline-flex max-w-[160px] items-center gap-1 truncate text-accent hover:underline"><ExternalLink size={11} />{v.replace(/^https?:\/\//, '')}</a>
    case 'email': return <a href={`mailto:${v}`} onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-1 truncate text-accent"><Mail size={11} />{v}</a>
    case 'phone': return <span className="inline-flex items-center gap-1"><Phone size={11} className="text-zinc-400" />{v}</span>
    case 'textarea': return <span className="line-clamp-2 whitespace-pre-wrap">{v}</span>
    default: return <span className="truncate">{String(v)}</span>
  }
}

// Valor clicável + editor adequado
export function CFEditor({ task, field, className = '' }) {
  const setFieldValue = useStore((s) => s.setFieldValue)
  const v = task.cf?.[field.id]
  const save = (val) => setFieldValue(task.id, field.id, val)
  const wrap = (child) => <div className={cx('min-h-[24px] cursor-pointer rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800', className)}>{child}</div>
  if (field.type === 'formula' || field.type === 'rollup') return <div className={cx('px-1 py-0.5', className)} title={field.type === 'formula' ? `Fórmula: ${field.config?.expr}` : 'Soma das subtarefas'}><CFDisplay task={task} field={field} /></div>
  if (field.type === 'checkbox') return <div className={cx('px-1 py-0.5', className)} onClick={(e) => { e.stopPropagation(); save(!v) }}><span className="cursor-pointer"><CFDisplay task={task} field={field} /></span></div>
  if (field.type === 'rating') {
    const max = field.config?.max || 5
    return (
      <div className={cx('flex gap-0.5 px-1 py-0.5', className)} onClick={(e) => e.stopPropagation()}>
        {Array.from({ length: max }).map((_, i) => <Star key={i} size={14} onClick={() => save(v === i + 1 ? 0 : i + 1)} className={cx('cursor-pointer', i < (v || 0) ? 'text-amber-400' : 'text-zinc-200 hover:text-amber-200 dark:text-zinc-700')} fill="currentColor" />)}
      </div>
    )
  }
  const content = <CFDisplay task={task} field={field} />
  return (
    <Popover block trigger={wrap(content)}>
      {(close) => {
        switch (field.type) {
          case 'dropdown': return <OptionsMenu field={field} value={v} onSave={save} close={close} />
          case 'labels': return <OptionsMenu field={field} value={v} onSave={save} multi close={close} />
          case 'people': return <UserPickerMenu value={v || []} onChange={save} close={close} />
          case 'date': return <DatePickerMenu value={v} onChange={save} close={close} />
          case 'progress': return <ProgressEditor value={v} onSave={save} close={close} />
          default: return <TextEditor value={v} onSave={save} type={field.type} close={close} />
        }
      }}
    </Popover>
  )
}

function ProgressEditor({ value, onSave, close }) {
  const [v, setV] = useState(value || 0)
  return (
    <div className="menu w-64 p-3">
      <div className="mb-2 flex justify-between"><span className="font-medium">Progresso</span><span>{v}%</span></div>
      <input type="range" min="0" max="100" step="5" value={v} onChange={(e) => setV(Number(e.target.value))} className="w-full accent-[#6d5dfc]" />
      <div className="mt-2 flex justify-end"><button className="btn btn-primary" onClick={() => { onSave(v); close() }}>Salvar</button></div>
    </div>
  )
}

// Editor de definição de campo (nome, tipo, opções...)
export function FieldDefinitionForm({ initial, onSubmit, onCancel, locked }) {
  const [f, setF] = useState(initial || { name: '', type: 'text', config: {} })
  useEffect(() => { if (initial) setF(initial) }, [initial?.id])
  const cfg = f.config || {}
  const setCfg = (p) => setF({ ...f, config: { ...cfg, ...p } })
  const fieldsInScope = useStore((s) => s.fields)
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div><div className="label mb-1">Nome</div><input autoFocus className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><div className="label mb-1">Tipo</div>
          <select disabled={locked} className="input" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value, config: {} })}>
            {FIELD_TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </select>
        </div>
      </div>
      {(f.type === 'dropdown' || f.type === 'labels') && (
        <div>
          <div className="label mb-1">Opções</div>
          <div className="space-y-1">
            {(cfg.options || []).map((o, i) => (
              <div key={o.id} className="flex items-center gap-2">
                <input type="color" value={o.color} onChange={(e) => setCfg({ options: cfg.options.map((x) => (x.id === o.id ? { ...x, color: e.target.value } : x)) })} className="h-7 w-8 cursor-pointer rounded border-0 bg-transparent" />
                <input className="input" value={o.name} onChange={(e) => setCfg({ options: cfg.options.map((x) => (x.id === o.id ? { ...x, name: e.target.value } : x)) })} />
                <button className="btn btn-ghost !p-1" onClick={() => setCfg({ options: cfg.options.filter((x) => x.id !== o.id) })}><X size={14} /></button>
              </div>
            ))}
            <button className="btn btn-ghost text-accent" onClick={() => setCfg({ options: [...(cfg.options || []), { id: uid('o'), name: `Opção ${(cfg.options || []).length + 1}`, color: PALETTE[(cfg.options || []).length % PALETTE.length] }] })}>+ Adicionar opção</button>
          </div>
        </div>
      )}
      {f.type === 'money' && <div><div className="label mb-1">Moeda</div><select className="input" value={cfg.currency || 'BRL'} onChange={(e) => setCfg({ currency: e.target.value })}>{['BRL', 'USD', 'EUR'].map((c) => <option key={c}>{c}</option>)}</select></div>}
      {f.type === 'rating' && <div><div className="label mb-1">Máximo</div><input type="number" min="1" max="10" className="input" value={cfg.max || 5} onChange={(e) => setCfg({ max: Number(e.target.value) })} /></div>}
      {f.type === 'formula' && (
        <div>
          <div className="label mb-1">Expressão</div>
          <input className="input font-mono" value={cfg.expr || ''} onChange={(e) => setCfg({ expr: e.target.value })} placeholder="{Orçamento} * 1.15" />
          <div className="mt-1 text-[11px] text-zinc-500">Use nomes de campos numéricos entre chaves. Também: {'{points}'}, {'{estimate}'} (h), {'{tracked}'} (h). Operadores: + − * / ( ) %</div>
          <label className="mt-2 flex items-center gap-2"><input type="checkbox" checked={!!cfg.currency} onChange={(e) => setCfg({ currency: e.target.checked ? 'BRL' : null })} />Exibir como moeda</label>
        </div>
      )}
      {f.type === 'rollup' && (
        <div>
          <div className="label mb-1">Somar o campo das subtarefas</div>
          <select className="input" value={cfg.fieldId || ''} onChange={(e) => setCfg({ fieldId: e.target.value })}>
            <option value="">Selecione…</option>
            {fieldsInScope.filter((x) => ['number', 'money'].includes(x.type)).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
          </select>
        </div>
      )}
      <div><div className="label mb-1">Descrição (opcional)</div><input className="input" value={f.description || ''} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      <label className="flex items-center gap-2"><input type="checkbox" checked={!!f.required} onChange={(e) => setF({ ...f, required: e.target.checked })} />Campo obrigatório (aviso ao fechar tarefa)</label>
      <div className="flex justify-end gap-2">
        {onCancel && <button className="btn btn-outline" onClick={onCancel}>Cancelar</button>}
        <button className="btn btn-primary" disabled={!f.name.trim()} onClick={() => onSubmit(f)}>Salvar campo</button>
      </div>
    </div>
  )
}
