import React, { useMemo, useRef, useState } from 'react'
import {
  X, MoreHorizontal, Check, Users, CalendarDays, Flag, Clock, Hourglass, Tag, Zap, Repeat, Eye, List as ListIcon, Play, Square, Plus, Trash2,
  Copy, ArrowRightLeft, LayoutTemplate, Archive, Link2, Paperclip, Ban, CornerDownRight, ChevronRight, SmilePlus, CheckCircle2, MessageSquare,
  ListChecks, GripVertical, AtSign, UserCheck, Hash, CircleDot, Image as ImageIcon, ExternalLink, ArrowUp, ArrowDown,
} from 'lucide-react'
import { useStore } from '../store/store'
import {
  Modal, Popover, StatusBadge, StatusDot, StatusMenu, UserPickerMenu, AvatarStack, Avatar, PriorityFlag, PriorityMenu, DatePickerMenu,
  TagMenu, TagChip, InlineEdit, ProgressBar, Confirm, SearchInput, Icon,
} from './ui'
import RichEditor from './RichEditor'
import { CFEditor } from './fields/CustomField'
import {
  getTask, taskStatus, taskPath, getList, getSpace, getFolder, subtasksOf, progressOf, timeTracked, getFieldsForList, blockingOf, isClosed,
  taskCode, getStatusesForList, searchTasks,
} from '../lib/selectors'
import { setStatus, completeTask, memberName } from '../lib/actions'
import { fmtDay, fmtMinutes, parseDuration, fmtRelative, dueTone, cx, todayStr, fmtDateTime } from '../lib/utils'

const EMOJIS = ['👍', '❤️', '🎉', '🔥', '👀', '✅', '😂', '🙏']

function Prop({ icon: I, label, children }) {
  return (
    <div className="flex min-h-[32px] items-center gap-2">
      <div className="flex w-32 shrink-0 items-center gap-2 text-zinc-500"><I size={14} />{label}</div>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  )
}

export function TaskPickerMenu({ onPick, exclude = [], close, placeholder = 'Buscar tarefa…' }) {
  const s = useStore()
  const [q, setQ] = useState('')
  const res = (q ? searchTasks(s, q) : s.tasks.filter((t) => !t.deletedAt).slice(-15).reverse()).filter((t) => !exclude.includes(t.id)).slice(0, 15)
  return (
    <div className="menu w-80">
      <div className="p-1"><SearchInput value={q} onChange={setQ} autoFocus placeholder={placeholder} /></div>
      <div className="max-h-72 overflow-y-auto">
        {res.map((t) => (
          <button key={t.id} className="menu-item" onClick={() => { onPick(t.id); close?.() }}>
            <StatusDot status={taskStatus(s, t)} size={8} />
            <span className="flex-1 truncate">{t.name}</span>
            <span className="truncate text-[10px] text-zinc-400">{getList(s, t.listId)?.name}</span>
          </button>
        ))}
        {!res.length && <div className="p-3 text-center text-zinc-400">Nenhuma tarefa</div>}
      </div>
    </div>
  )
}

function TimeTracker({ task }) {
  const s = useStore()
  const running = s.timer?.taskId === task.id
  const [manual, setManual] = useState('')
  const [note, setNote] = useState('')
  const total = timeTracked(task)
  return (
    <div className="flex items-center gap-2">
      <button onClick={() => (running ? s.stopTimer() : s.startTimer(task.id))} className={cx('flex h-6 w-6 items-center justify-center rounded-full text-white', running ? 'bg-red-500' : 'bg-accent')}>
        {running ? <Square size={10} fill="currentColor" /> : <Play size={11} fill="currentColor" />}
      </button>
      <Popover trigger={<button className="whitespace-nowrap rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800">{total ? fmtMinutes(total) : <span className="text-zinc-400">Registrar tempo</span>}</button>}>
        <div className="menu w-80 p-2">
          <div className="label mb-1">Adicionar manualmente</div>
          <div className="flex gap-1">
            <input className="input" placeholder="ex: 1h 30m" value={manual} onChange={(e) => setManual(e.target.value)} />
            <button className="btn btn-primary" onClick={() => { const m = parseDuration(manual); if (m) { s.addTimeEntry(task.id, { userId: s.currentUserId, start: Date.now(), minutes: m, note }); setManual(''); setNote('') } }}>Adicionar</button>
          </div>
          <input className="input mt-1" placeholder="Nota (opcional)" value={note} onChange={(e) => setNote(e.target.value)} />
          <div className="label mb-1 mt-3">Registros ({fmtMinutes(total) || '0m'})</div>
          <div className="max-h-48 space-y-1 overflow-y-auto">
            {task.timeEntries.slice().reverse().map((e) => (
              <div key={e.id} className="group flex items-center gap-2 rounded px-1 py-1 hover:bg-zinc-50 dark:hover:bg-zinc-800">
                <Avatar userId={e.userId} size={18} />
                <span className="font-medium">{fmtMinutes(e.minutes)}</span>
                <span className="flex-1 truncate text-[11px] text-zinc-400">{fmtDateTime(e.start)}{e.note && ` · ${e.note}`}</span>
                <button title={e.billable ? 'Faturável' : 'Não faturável'} onClick={() => s.updateTimeEntry(task.id, e.id, { billable: !e.billable })} className={cx('text-[11px] font-bold', e.billable ? 'text-emerald-500' : 'text-zinc-300')}>$</button>
                <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={() => s.deleteTimeEntry(task.id, e.id)}><Trash2 size={12} /></button>
              </div>
            ))}
            {!task.timeEntries.length && <div className="text-zinc-400">Nenhum registro ainda.</div>}
          </div>
        </div>
      </Popover>
      {task.timeEstimate ? <span className="text-[11px] text-zinc-400">de {fmtMinutes(task.timeEstimate)}</span> : null}
      {task.timeEstimate ? <div className="w-20"><ProgressBar pct={(total / task.timeEstimate) * 100} color={total > task.timeEstimate ? '#ef4444' : '#6d5dfc'} h={4} /></div> : null}
    </div>
  )
}

function RecurrenceEditor({ task }) {
  const update = useStore((s) => s.updateTask)
  const r = task.recurrence
  const label = r ? `A cada ${r.interval > 1 ? r.interval + ' ' : ''}${{ daily: r.interval > 1 ? 'dias' : 'dia', weekly: r.interval > 1 ? 'semanas' : 'semana', monthly: r.interval > 1 ? 'meses' : 'mês' }[r.freq]} · ${r.mode === 'reopen' ? 'reabre' : 'cria nova'}` : null
  return (
    <Popover trigger={<button className="rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800">{label || <span className="text-zinc-400">Não se repete</span>}</button>}>
      {(close) => {
        const cur = r || { freq: 'weekly', interval: 1, mode: 'new' }
        return (
          <div className="menu w-72 space-y-2 p-3">
            <div className="label">Repetir quando concluída</div>
            <div className="flex gap-1">
              <input type="number" min="1" className="input w-16" defaultValue={cur.interval} id="rec-int" />
              <select className="input" defaultValue={cur.freq} id="rec-freq"><option value="daily">dia(s)</option><option value="weekly">semana(s)</option><option value="monthly">mês(es)</option></select>
            </div>
            <select className="input" defaultValue={cur.mode} id="rec-mode"><option value="new">Criar nova tarefa</option><option value="reopen">Reabrir esta tarefa</option></select>
            <div className="flex justify-between">
              {r ? <button className="btn btn-ghost text-red-500" onClick={() => { update(task.id, { recurrence: null }); close() }}>Remover</button> : <span />}
              <button className="btn btn-primary" onClick={() => {
                update(task.id, { recurrence: { interval: Number(document.getElementById('rec-int').value) || 1, freq: document.getElementById('rec-freq').value, mode: document.getElementById('rec-mode').value } })
                close()
              }}>Salvar</button>
            </div>
            <div className="text-[11px] text-zinc-500">Ao mudar para um status concluído/fechado, a próxima ocorrência é agendada a partir da data de entrega.</div>
          </div>
        )
      }}
    </Popover>
  )
}

function SubtaskRow({ t }) {
  const s = useStore()
  const st = taskStatus(s, t)
  return (
    <div className="group flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/60">
      <Popover trigger={<button><StatusDot status={st} /></button>}>{(c) => <StatusMenu listId={t.listId} value={t.statusId} onChange={(id) => setStatus(t.id, id)} close={c} />}</Popover>
      <button className={cx('flex-1 truncate text-left', isClosed(s, t) && 'text-zinc-400 line-through')} onClick={() => s.openTask(t.id)}>{t.name}</button>
      {subtasksOf(s, t.id).length > 0 && <span className="text-[11px] text-zinc-400">{subtasksOf(s, t.id).length} sub</span>}
      <Popover trigger={<button><AvatarStack ids={t.assignees} size={20} /></button>}>{(c) => <UserPickerMenu value={t.assignees} onChange={(a) => s.updateTask(t.id, { assignees: a })} close={c} />}</Popover>
      <Popover trigger={<button className={cx('w-16 text-right text-[12px]', dueTone(t.dueDate, isClosed(s, t)))}>{t.dueDate ? fmtDay(t.dueDate) : <CalendarDays size={13} className="ml-auto text-zinc-300" />}</button>}>
        {(c) => <DatePickerMenu value={t.dueDate} onChange={(d) => s.updateTask(t.id, { dueDate: d })} close={c} />}
      </Popover>
      <Popover trigger={<button><PriorityFlag p={t.priority} /></button>}>{(c) => <PriorityMenu value={t.priority} onChange={(p) => s.updateTask(t.id, { priority: p })} close={c} />}</Popover>
      <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={() => s.deleteTask(t.id)}><Trash2 size={13} /></button>
    </div>
  )
}

function Checklists({ task }) {
  const s = useStore()
  const [newItem, setNewItem] = useState({})
  return (
    <div className="space-y-3">
      {task.checklists.map((ck) => {
        const done = ck.items.filter((i) => i.done).length
        return (
          <div key={ck.id} className="rounded-lg border border-zinc-200 dark:border-zinc-800">
            <div className="flex items-center gap-2 border-b border-zinc-100 px-3 py-2 dark:border-zinc-800">
              <ListChecks size={14} className="text-zinc-400" />
              <InlineEdit value={ck.name} onSave={(name) => s.updateChecklist(task.id, ck.id, { name })} className="flex-1 font-semibold" />
              <span className="text-[11px] text-zinc-400">{done}/{ck.items.length}</span>
              <div className="w-20"><ProgressBar pct={ck.items.length ? (done / ck.items.length) * 100 : 0} h={4} /></div>
              <button className="text-zinc-400 hover:text-red-500" onClick={() => s.deleteChecklist(task.id, ck.id)}><Trash2 size={13} /></button>
            </div>
            <div className="p-1">
              {ck.items.map((it, idx) => (
                <div key={it.id} className="group flex items-center gap-2 rounded px-2 py-1 hover:bg-zinc-50 dark:hover:bg-zinc-800/60">
                  <input type="checkbox" checked={it.done} onChange={(e) => s.updateChecklistItem(task.id, ck.id, it.id, { done: e.target.checked })} className="h-4 w-4 accent-[#6d5dfc]" />
                  <InlineEdit value={it.text} onSave={(text) => s.updateChecklistItem(task.id, ck.id, it.id, { text })} className={cx('flex-1', it.done && 'text-zinc-400 line-through')} />
                  <div className="hidden gap-0.5 group-hover:flex">
                    {idx > 0 && <button className="text-zinc-400" onClick={() => s.moveChecklistItem(task.id, ck.id, idx, idx - 1)}><ArrowUp size={12} /></button>}
                    {idx < ck.items.length - 1 && <button className="text-zinc-400" onClick={() => s.moveChecklistItem(task.id, ck.id, idx, idx + 1)}><ArrowDown size={12} /></button>}
                  </div>
                  <Popover trigger={<button>{it.assignee ? <Avatar userId={it.assignee} size={18} /> : <UserCheck size={14} className="text-zinc-300 group-hover:text-zinc-400" />}</button>}>
                    {(c) => <UserPickerMenu value={it.assignee ? [it.assignee] : []} multiple={false} onChange={(v) => s.updateChecklistItem(task.id, ck.id, it.id, { assignee: v[0] || null })} close={c} />}
                  </Popover>
                  <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={() => s.deleteChecklistItem(task.id, ck.id, it.id)}><X size={13} /></button>
                </div>
              ))}
              <input className="w-full rounded bg-transparent px-2 py-1.5 outline-none placeholder:text-zinc-400" placeholder="+ Novo item (Enter)" value={newItem[ck.id] || ''}
                onChange={(e) => setNewItem({ ...newItem, [ck.id]: e.target.value })}
                onKeyDown={(e) => { if (e.key === 'Enter' && newItem[ck.id]?.trim()) { s.addChecklistItem(task.id, ck.id, newItem[ck.id].trim()); setNewItem({ ...newItem, [ck.id]: '' }) } }} />
            </div>
          </div>
        )
      })}
    </div>
  )
}

function Attachments({ task }) {
  const s = useStore()
  const fileRef = useRef(null)
  const onFile = (e) => {
    const f = e.target.files[0]
    if (!f) return
    if (f.size > 1.5 * 1024 * 1024) { s.toast('Arquivo grande demais para o modo local (máx 1,5 MB)'); return }
    const r = new FileReader()
    r.onload = () => s.addAttachment(task.id, { name: f.name, url: r.result, type: f.type, size: f.size })
    r.readAsDataURL(f)
    e.target.value = ''
  }
  return (
    <div>
      <div className="grid grid-cols-3 gap-2">
        {task.attachments.map((a) => (
          <div key={a.id} className="group relative overflow-hidden rounded-lg border border-zinc-200 dark:border-zinc-800">
            {a.type?.startsWith('image/') ? <img src={a.url} alt={a.name} className="h-20 w-full object-cover" /> : <div className="flex h-20 items-center justify-center bg-zinc-50 dark:bg-zinc-800"><Paperclip size={20} className="text-zinc-400" /></div>}
            <a href={a.url} target="_blank" rel="noreferrer" download={a.type ? a.name : undefined} className="block truncate px-2 py-1 text-[11px] hover:underline">{a.name}</a>
            <button className="absolute right-1 top-1 hidden rounded bg-white/90 p-0.5 text-red-500 group-hover:block dark:bg-zinc-900/90" onClick={() => s.removeAttachment(task.id, a.id)}><X size={12} /></button>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-2">
        <button className="btn btn-outline" onClick={() => fileRef.current.click()}><Paperclip size={13} />Enviar arquivo</button>
        <button className="btn btn-outline" onClick={() => { const url = prompt('URL do link'); if (url) s.addAttachment(task.id, { name: url.replace(/^https?:\/\//, '').slice(0, 40), url }) }}><Link2 size={13} />Adicionar link</button>
        <input ref={fileRef} type="file" className="hidden" onChange={onFile} />
      </div>
    </div>
  )
}

function Relationships({ task }) {
  const s = useStore()
  const waiting = task.blockedBy.map((id) => getTask(s, id)).filter(Boolean)
  const blocking = blockingOf(s, task.id)
  const linked = task.links.map((id) => getTask(s, id)).filter(Boolean)
  const Row = ({ t, onRemove, tone }) => (
    <div className="group flex items-center gap-2 rounded px-2 py-1 hover:bg-zinc-50 dark:hover:bg-zinc-800/60">
      <StatusDot status={taskStatus(s, t)} size={8} />
      <button className={cx('flex-1 truncate text-left', isClosed(s, t) && 'line-through text-zinc-400')} onClick={() => s.openTask(t.id)}>{t.name}</button>
      {tone}
      <button className="hidden text-zinc-400 hover:text-red-500 group-hover:block" onClick={onRemove}><X size={13} /></button>
    </div>
  )
  return (
    <div className="space-y-3">
      <div>
        <div className="mb-1 flex items-center gap-2 text-[12px] font-semibold text-amber-600"><Ban size={13} />Aguardando ({waiting.length})
          <Popover trigger={<button className="ml-1 text-zinc-400 hover:text-accent"><Plus size={13} /></button>}>{(c) => <TaskPickerMenu exclude={[task.id, ...task.blockedBy]} onPick={(id) => s.addDependency(task.id, id)} close={c} />}</Popover>
        </div>
        {waiting.map((t) => <Row key={t.id} t={t} onRemove={() => s.removeDependency(task.id, t.id)} tone={!isClosed(s, t) && <span className="text-[10px] font-semibold text-amber-600">BLOQUEIA</span>} />)}
      </div>
      <div>
        <div className="mb-1 flex items-center gap-2 text-[12px] font-semibold text-red-500"><Ban size={13} />Bloqueando ({blocking.length})
          <Popover trigger={<button className="ml-1 text-zinc-400 hover:text-accent"><Plus size={13} /></button>}>{(c) => <TaskPickerMenu exclude={[task.id, ...blocking.map((b) => b.id)]} onPick={(id) => s.addDependency(id, task.id)} close={c} />}</Popover>
        </div>
        {blocking.map((t) => <Row key={t.id} t={t} onRemove={() => s.removeDependency(t.id, task.id)} />)}
      </div>
      <div>
        <div className="mb-1 flex items-center gap-2 text-[12px] font-semibold text-zinc-500"><Link2 size={13} />Tarefas vinculadas ({linked.length})
          <Popover trigger={<button className="ml-1 text-zinc-400 hover:text-accent"><Plus size={13} /></button>}>{(c) => <TaskPickerMenu exclude={[task.id, ...task.links]} onPick={(id) => s.toggleLink(task.id, id)} close={c} />}</Popover>
        </div>
        {linked.map((t) => <Row key={t.id} t={t} onRemove={() => s.toggleLink(task.id, t.id)} />)}
      </div>
    </div>
  )
}

// ---------- Comentários + atividade ----------
function MentionTextarea({ value, onChange, onSubmit, placeholder, autoFocus }) {
  const members = useStore((s) => s.members)
  const ref = useRef(null)
  const [menu, setMenu] = useState(null)
  const handle = (e) => {
    const v = e.target.value
    onChange(v)
    const pos = e.target.selectionStart
    const m = v.slice(0, pos).match(/@([\p{L}]*)$/u)
    setMenu(m ? { q: m[1], start: pos - m[0].length } : null)
  }
  const pick = (name) => {
    const before = value.slice(0, menu.start)
    const after = value.slice(ref.current.selectionStart)
    onChange(`${before}@${name} ${after}`)
    setMenu(null)
    setTimeout(() => ref.current.focus(), 0)
  }
  const list = menu ? members.filter((m) => m.name.toLowerCase().startsWith(menu.q.toLowerCase()) || m.name.toLowerCase().includes(menu.q.toLowerCase())) : []
  return (
    <div className="relative">
      <textarea ref={ref} autoFocus={autoFocus} className="input min-h-[64px] resize-none" placeholder={placeholder} value={value} onChange={handle}
        onKeyDown={(e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); onSubmit() } if (e.key === 'Escape') setMenu(null) }} />
      {menu && list.length > 0 && (
        <div className="menu absolute bottom-full left-0 z-10 mb-1 w-56">
          {list.map((m) => <button key={m.id} className="menu-item" onMouseDown={(e) => { e.preventDefault(); pick(m.name) }}><Avatar userId={m.id} size={18} />{m.name}</button>)}
        </div>
      )}
    </div>
  )
}

function renderText(text, members) {
  const names = members.map((m) => m.name).sort((a, b) => b.length - a.length)
  if (!names.length) return text
  const re = new RegExp(`(@(?:${names.map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')}))`, 'g')
  return text.split(re).map((part, i) => (part.startsWith('@') && names.includes(part.slice(1)) ? <span key={i} className="rounded bg-accent-50 px-1 font-medium text-accent dark:bg-accent/20">{part}</span> : <React.Fragment key={i}>{part}</React.Fragment>))
}

function Comment({ c, replies }) {
  const s = useStore()
  const [replying, setReplying] = useState(false)
  const [reply, setReply] = useState('')
  const [editing, setEditing] = useState(false)
  const [edit, setEdit] = useState(c.text)
  return (
    <div className={cx('rounded-lg border bg-white p-3 dark:bg-zinc-900', c.assignedTo && !c.resolved ? 'border-amber-300' : 'border-zinc-200 dark:border-zinc-800', c.resolved && 'opacity-60')}>
      <div className="flex items-center gap-2">
        <Avatar userId={c.userId} size={22} />
        <span className="font-semibold">{memberName(c.userId)}</span>
        <span className="text-[11px] text-zinc-400">{fmtRelative(c.createdAt)}</span>
        <div className="flex-1" />
        {c.userId === s.currentUserId && <button className="text-[11px] text-zinc-400 hover:text-zinc-600" onClick={() => setEditing(true)}>Editar</button>}
        {c.userId === s.currentUserId && <button className="text-zinc-400 hover:text-red-500" onClick={() => s.deleteComment(c.id)}><Trash2 size={12} /></button>}
      </div>
      {c.assignedTo && (
        <div className="mt-2 flex items-center gap-2 rounded bg-amber-50 px-2 py-1 text-[12px] text-amber-700 dark:bg-amber-500/10">
          <UserCheck size={12} />Atribuído a {memberName(c.assignedTo)}
          <button className="ml-auto font-semibold" onClick={() => s.updateComment(c.id, { resolved: !c.resolved })}>{c.resolved ? 'Reabrir' : 'Resolver'}</button>
        </div>
      )}
      {editing ? (
        <div className="mt-2"><MentionTextarea value={edit} onChange={setEdit} onSubmit={() => { s.updateComment(c.id, { text: edit }); setEditing(false) }} />
          <div className="mt-1 flex justify-end gap-1"><button className="btn btn-ghost" onClick={() => setEditing(false)}>Cancelar</button><button className="btn btn-primary" onClick={() => { s.updateComment(c.id, { text: edit }); setEditing(false) }}>Salvar</button></div></div>
      ) : <div className="mt-2 whitespace-pre-wrap leading-relaxed">{renderText(c.text, s.members)}</div>}
      <div className="mt-2 flex flex-wrap items-center gap-1">
        {Object.entries(c.reactions).map(([emo, users]) => (
          <button key={emo} title={users.map(memberName).join(', ')} onClick={() => s.toggleReaction(c.id, emo)} className={cx('rounded-full border px-1.5 text-[12px]', users.includes(s.currentUserId) ? 'border-accent bg-accent-50 dark:bg-accent/20' : 'border-zinc-200 dark:border-zinc-700')}>{emo} {users.length}</button>
        ))}
        <Popover trigger={<button className="rounded-full p-1 text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"><SmilePlus size={14} /></button>}>
          {(close) => <div className="menu flex gap-1 p-1.5">{EMOJIS.map((e) => <button key={e} className="rounded p-1 text-lg hover:bg-zinc-100 dark:hover:bg-zinc-800" onClick={() => { s.toggleReaction(c.id, e); close() }}>{e}</button>)}</div>}
        </Popover>
        {!c.parentId && <button className="text-[12px] text-zinc-400 hover:text-accent" onClick={() => setReplying(!replying)}>Responder</button>}
        {!c.assignedTo && !c.parentId && (
          <Popover trigger={<button className="text-[12px] text-zinc-400 hover:text-accent">Atribuir</button>}>
            {(cl) => <UserPickerMenu multiple={false} value={[]} onChange={(v) => { s.updateComment(c.id, { assignedTo: v[0] || null }); cl() }} close={cl} />}
          </Popover>
        )}
      </div>
      {replies?.length > 0 && <div className="mt-2 space-y-2 border-l-2 border-zinc-100 pl-3 dark:border-zinc-800">{replies.map((r) => <Comment key={r.id} c={r} />)}</div>}
      {replying && (
        <div className="mt-2">
          <MentionTextarea autoFocus value={reply} onChange={setReply} placeholder="Responder… (Ctrl+Enter)" onSubmit={() => { s.addComment(c.taskId, reply, c.id); setReply(''); setReplying(false) }} />
        </div>
      )}
    </div>
  )
}

function ActivityPanel({ task }) {
  const s = useStore()
  const [tab, setTab] = useState('all')
  const [text, setText] = useState('')
  const [assignTo, setAssignTo] = useState(null)
  const comments = s.comments.filter((c) => c.taskId === task.id)
  const tops = comments.filter((c) => !c.parentId)
  const acts = s.activity.filter((a) => a.taskId === task.id)
  const feed = [
    ...(tab !== 'activity' ? tops.map((c) => ({ kind: 'c', at: c.createdAt, c })) : []),
    ...(tab !== 'comments' ? acts.map((a) => ({ kind: 'a', at: a.createdAt, a })) : []),
  ].sort((a, b) => a.at - b.at)
  const send = () => { if (!text.trim()) return; s.addComment(task.id, text, null, { assignedTo: assignTo }); setText(''); setAssignTo(null) }
  return (
    <div className="flex h-full flex-col bg-zinc-50 dark:bg-zinc-950/40">
      <div className="flex items-center gap-1 border-b border-zinc-200 px-3 py-2 dark:border-zinc-800">
        <span className="mr-2 font-semibold">Atividade</span>
        {[['all', 'Tudo'], ['comments', `Comentários ${comments.length || ''}`], ['activity', 'Histórico']].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={cx('rounded-md px-2 py-1 text-[12px]', tab === k ? 'bg-white font-semibold shadow-sm dark:bg-zinc-800' : 'text-zinc-500')}>{l}</button>
        ))}
        <div className="flex-1" />
        <Popover align="end" trigger={<button className="flex items-center gap-1 text-zinc-400" title="Seguidores"><Eye size={14} /><span className="text-[12px]">{task.watchers.length}</span></button>}>
          {(c) => <UserPickerMenu value={task.watchers} onChange={(w) => s.updateTask(task.id, { watchers: w })} close={c} />}
        </Popover>
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto p-3">
        {feed.map((f) => f.kind === 'c'
          ? <Comment key={f.c.id} c={f.c} replies={comments.filter((r) => r.parentId === f.c.id)} />
          : (
            <div key={f.a.id} className="flex items-start gap-2 px-1 text-[12px] text-zinc-500">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-zinc-300" />
              <span className="flex-1"><b className="font-medium text-zinc-700 dark:text-zinc-300">{memberName(f.a.userId)}</b> {f.a.text}</span>
              <span className="shrink-0 text-[11px] text-zinc-400">{fmtRelative(f.a.createdAt)}</span>
            </div>
          ))}
        {!feed.length && <div className="py-8 text-center text-zinc-400">Sem atividade</div>}
      </div>
      <div className="border-t border-zinc-200 p-3 dark:border-zinc-800">
        <MentionTextarea value={text} onChange={setText} onSubmit={send} placeholder="Comentar… use @ para mencionar (Ctrl+Enter envia)" />
        <div className="mt-2 flex items-center gap-2">
          <Popover trigger={<button className="btn btn-ghost !px-1.5 text-[12px]"><UserCheck size={13} />{assignTo ? memberName(assignTo) : 'Atribuir comentário'}</button>}>
            {(c) => <UserPickerMenu multiple={false} value={assignTo ? [assignTo] : []} onChange={(v) => setAssignTo(v[0] || null)} close={c} />}
          </Popover>
          <div className="flex-1" />
          <button className="btn btn-primary" onClick={send}>Comentar</button>
        </div>
      </div>
    </div>
  )
}

function Section({ title, icon: I, children, right, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="mt-6">
      <div className="mb-2 flex items-center gap-2">
        <button className="flex items-center gap-2 font-semibold" onClick={() => setOpen(!open)}>
          <ChevronRight size={14} className={cx('transition-transform', open && 'rotate-90')} /><I size={15} className="text-zinc-400" />{title}
        </button>
        <div className="flex-1" />{right}
      </div>
      {open && children}
    </div>
  )
}

function TaskMenu({ task, close }) {
  const s = useStore()
  const [confirm, setConfirm] = useState(false)
  return (
    <div className="menu w-64">
      <button className="menu-item" onClick={() => { navigator.clipboard?.writeText(taskCode(s, task)); s.toast('ID copiado'); close() }}><Hash size={14} />Copiar ID ({taskCode(s, task)})</button>
      <button className="menu-item" onClick={() => { s.duplicateTask(task.id); close() }}><Copy size={14} />Duplicar</button>
      <Popover side="right" block trigger={<span className="menu-item"><ArrowRightLeft size={14} />Mover para lista<ChevronRight size={13} className="ml-auto" /></span>}>
        {(c2) => (
          <div className="menu max-h-80 w-56 overflow-y-auto">
            {s.lists.filter((l) => l.id !== task.listId).map((l) => <button key={l.id} className="menu-item" onClick={() => { s.moveTask(task.id, l.id); c2(); close() }}><span className="h-2 w-2 rounded-full" style={{ background: l.color }} />{l.name}<span className="ml-auto text-[10px] text-zinc-400">{getSpace(s, l.spaceId)?.name}</span></button>)}
          </div>
        )}
      </Popover>
      <Popover side="right" block trigger={<span className="menu-item"><ListIcon size={14} />Adicionar a outra lista<ChevronRight size={13} className="ml-auto" /></span>}>
        {(c2) => (
          <div className="menu max-h-80 w-56 overflow-y-auto">
            {s.lists.filter((l) => l.id !== task.listId).map((l) => {
              const on = task.extraListIds.includes(l.id)
              return <button key={l.id} className="menu-item" onClick={() => s.updateTask(task.id, { extraListIds: on ? task.extraListIds.filter((x) => x !== l.id) : [...task.extraListIds, l.id] })}><span className="h-2 w-2 rounded-full" style={{ background: l.color }} />{l.name}{on && <Check size={13} className="ml-auto text-accent" />}</button>
            })}
          </div>
        )}
      </Popover>
      {task.parentId ? (
        <button className="menu-item" onClick={() => { s.updateTask(task.id, { parentId: null }); close() }}><CornerDownRight size={14} />Tornar tarefa principal</button>
      ) : (
        <Popover side="right" block trigger={<span className="menu-item"><CornerDownRight size={14} />Converter em subtarefa de…<ChevronRight size={13} className="ml-auto" /></span>}>
          {(c2) => <TaskPickerMenu exclude={[task.id, ...subtasksOf(s, task.id).map((x) => x.id)]} onPick={(pid) => { const p = getTask(s, pid); s.updateTask(task.id, { parentId: pid, ...(p.listId !== task.listId ? { listId: p.listId } : {}) }); close() }} close={c2} />}
        </Popover>
      )}
      <div className="my-1 border-t border-zinc-100 dark:border-zinc-800" />
      <button className="menu-item" onClick={() => { s.saveTaskTemplate(task.id, prompt('Nome do template', task.name) || task.name); close() }}><LayoutTemplate size={14} />Salvar como template</button>
      {s.templates.some((t) => t.kind === 'task') && (
        <Popover side="right" block trigger={<span className="menu-item"><LayoutTemplate size={14} />Aplicar template<ChevronRight size={13} className="ml-auto" /></span>}>
          {(c2) => <div className="menu w-56">{s.templates.filter((t) => t.kind === 'task').map((t) => <button key={t.id} className="menu-item" onClick={() => { s.applyTemplateToTask(t.id, task.id); c2(); close() }}>{t.name}</button>)}</div>}
        </Popover>
      )}
      <button className="menu-item" onClick={() => { s.updateTask(task.id, { archived: !task.archived }); close() }}><Archive size={14} />{task.archived ? 'Desarquivar' : 'Arquivar'}</button>
      <button className="menu-item text-red-500" onClick={() => setConfirm(true)}><Trash2 size={14} />Excluir</button>
      <Confirm open={confirm} onClose={() => { setConfirm(false); close() }} onConfirm={() => s.deleteTask(task.id)} title="Excluir tarefa?" text="Ela e suas subtarefas vão para a lixeira." />
    </div>
  )
}

export default function TaskDetail() {
  const s = useStore()
  const task = getTask(s, s.openTaskId)
  const [newSub, setNewSub] = useState('')
  if (!task || task.deletedAt) return null
  const st = taskStatus(s, task)
  const list = getList(s, task.listId)
  const space = list && getSpace(s, list.spaceId)
  const folder = list?.folderId && getFolder(s, list.folderId)
  const parent = task.parentId && getTask(s, task.parentId)
  const subs = subtasksOf(s, task.id)
  const prog = progressOf(s, task)
  const fields = getFieldsForList(s, task.listId)
  const ca = s.workspace.clickApps
  const type = s.taskTypes.find((x) => x.id === task.typeId) || s.taskTypes[0]
  const closed = isClosed(s, task)
  const go = (r) => { s.closeTask(); s.navigate(r) }

  return (
    <Modal open onClose={s.closeTask} width={1180} bare>
      <div className="card flex h-[88vh] flex-col overflow-hidden shadow-2xl">
        {/* barra superior */}
        <div className="flex items-center gap-2 border-b border-zinc-200 px-4 py-2.5 text-[12px] text-zinc-500 dark:border-zinc-800">
          <button className="hover:text-accent" onClick={() => go({ page: 'location', locType: 'space', locId: space?.id })}>{space?.name}</button>
          {folder && <><ChevronRight size={12} /><button className="hover:text-accent" onClick={() => go({ page: 'location', locType: 'folder', locId: folder.id })}>{folder.name}</button></>}
          <ChevronRight size={12} /><button className="hover:text-accent" onClick={() => go({ page: 'location', locType: 'list', locId: list?.id })}>{list?.name}</button>
          {parent && <><ChevronRight size={12} /><button className="max-w-[200px] truncate hover:text-accent" onClick={() => s.openTask(parent.id)}>{parent.name}</button></>}
          {task.extraListIds.length > 0 && <span className="rounded bg-zinc-100 px-1.5 dark:bg-zinc-800">+{task.extraListIds.length} lista(s)</span>}
          {task.archived && <span className="rounded bg-amber-100 px-1.5 text-amber-700">Arquivada</span>}
          <div className="flex-1" />
          {ca.customTaskIds && <span className="font-mono">{taskCode(s, task)}</span>}
          <span>Criada {fmtRelative(task.createdAt)} por {memberName(task.createdBy)}</span>
          <Popover align="end" trigger={<button className="btn btn-ghost !p-1"><MoreHorizontal size={16} /></button>}>{(c) => <TaskMenu task={task} close={c} />}</Popover>
          <button className="btn btn-ghost !p-1" onClick={s.closeTask}><X size={17} /></button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* esquerda */}
          <div className="min-w-0 flex-1 overflow-y-auto px-8 py-6">
            <div className="mb-3 flex items-center gap-2">
              {ca.taskTypes && (
                <Popover trigger={<button className="flex items-center gap-1 rounded-md border border-zinc-200 px-2 py-0.5 text-[12px] dark:border-zinc-700" style={{ color: type.color }}><Icon name={type.icon} size={12} />{type.name}</button>}>
                  {(c) => <div className="menu w-48">{s.taskTypes.map((tt) => <button key={tt.id} className="menu-item" onClick={() => { s.updateTask(task.id, { typeId: tt.id }); c() }}><Icon name={tt.icon} size={14} style={{ color: tt.color }} />{tt.name}{tt.id === task.typeId && <Check size={13} className="ml-auto text-accent" />}</button>)}</div>}
                </Popover>
              )}
              {parent && <span className="text-[12px] text-zinc-400">Subtarefa de <button className="text-accent hover:underline" onClick={() => s.openTask(parent.id)}>{parent.name}</button></span>}
            </div>
            <InlineEdit value={task.name} onSave={(name) => s.updateTask(task.id, { name })} className="block text-[26px] font-bold leading-tight" multiline />

            <div className="mt-5 grid grid-cols-1 gap-x-8 gap-y-1 xl:grid-cols-2">
              <Prop icon={CircleDot} label="Status">
                <div className="flex items-center gap-1">
                  <Popover trigger={<button><StatusBadge status={st} /></button>}>{(c) => <StatusMenu listId={task.listId} value={task.statusId} onChange={(id) => setStatus(task.id, id)} close={c} />}</Popover>
                  <button title={closed ? 'Reabrir' : 'Concluir'} onClick={() => completeTask(task.id)} className={cx('flex h-6 w-6 items-center justify-center rounded border', closed ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-zinc-300 text-zinc-400 hover:border-emerald-500 hover:text-emerald-500 dark:border-zinc-600')}><Check size={14} /></button>
                </div>
              </Prop>
              <Prop icon={Users} label="Responsáveis">
                <Popover trigger={<button className="flex items-center gap-2 rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800"><AvatarStack ids={task.assignees} size={24} max={5} />{!task.assignees.length && <span className="text-zinc-400">Vazio</span>}</button>}>
                  {(c) => <UserPickerMenu value={task.assignees} multiple={ca.multipleAssignees} onChange={(a) => s.updateTask(task.id, { assignees: a })} close={c} />}
                </Popover>
              </Prop>
              <Prop icon={CalendarDays} label="Datas">
                <div className="flex items-center gap-1">
                  <Popover trigger={<button className="rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800">{task.startDate ? fmtDay(task.startDate) : <span className="text-zinc-400">Início</span>}</button>}>{(c) => <DatePickerMenu value={task.startDate} onChange={(d) => s.updateTask(task.id, { startDate: d })} close={c} />}</Popover>
                  <span className="text-zinc-300">→</span>
                  <Popover trigger={<button className={cx('rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800', dueTone(task.dueDate, closed))}>{task.dueDate ? fmtDay(task.dueDate) : <span className="text-zinc-400">Entrega</span>}</button>}>{(c) => <DatePickerMenu value={task.dueDate} onChange={(d) => s.updateTask(task.id, { dueDate: d })} close={c} />}</Popover>
                </div>
              </Prop>
              {ca.priorities && <Prop icon={Flag} label="Prioridade">
                <Popover trigger={<button className="rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800"><PriorityFlag p={task.priority} label /></button>}>{(c) => <PriorityMenu value={task.priority} onChange={(p) => s.updateTask(task.id, { priority: p })} close={c} />}</Popover>
              </Prop>}
              {ca.timeEstimates && <Prop icon={Hourglass} label="Estimativa">
                <Popover trigger={<button className="rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800">{task.timeEstimate ? fmtMinutes(task.timeEstimate) : <span className="text-zinc-400">Vazio</span>}</button>}>
                  {(c) => <div className="menu w-56 p-2"><input autoFocus className="input" placeholder="ex: 3h, 1h 30m, 45m" defaultValue={task.timeEstimate ? fmtMinutes(task.timeEstimate) : ''} onKeyDown={(e) => { if (e.key === 'Enter') { s.updateTask(task.id, { timeEstimate: parseDuration(e.target.value) || null }); c() } }} /><div className="mt-1 text-[11px] text-zinc-400">Enter para salvar</div></div>}
                </Popover>
              </Prop>}
              {ca.timeTracking && <Prop icon={Clock} label="Tempo rastreado"><TimeTracker task={task} /></Prop>}
              {ca.points && <Prop icon={Zap} label="Sprint points">
                <Popover trigger={<button className="rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800">{task.points ?? <span className="text-zinc-400">Vazio</span>}</button>}>
                  {(c) => <div className="menu grid w-56 grid-cols-4 gap-1 p-2">{[0, 1, 2, 3, 5, 8, 13, 21].map((p) => <button key={p} className={cx('rounded border py-1 font-semibold', task.points === p ? 'border-accent bg-accent text-white' : 'border-zinc-200 dark:border-zinc-700')} onClick={() => { s.updateTask(task.id, { points: p }); c() }}>{p}</button>)}<button className="col-span-4 text-zinc-400" onClick={() => { s.updateTask(task.id, { points: null }); c() }}>Limpar</button></div>}
                </Popover>
              </Prop>}
              {ca.tags && <Prop icon={Tag} label="Tags">
                <div className="flex flex-wrap items-center gap-1">
                  {task.tags.map((t) => <TagChip key={t} name={t} onRemove={() => s.updateTask(task.id, { tags: task.tags.filter((x) => x !== t) })} />)}
                  <Popover trigger={<button className="rounded p-0.5 text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800"><Plus size={13} /></button>}><TagMenu value={task.tags} onChange={(tags) => s.updateTask(task.id, { tags })} /></Popover>
                </div>
              </Prop>}
              <Prop icon={Repeat} label="Recorrência"><RecurrenceEditor task={task} /></Prop>
              <Prop icon={ListIcon} label="Listas">
                <div className="flex flex-wrap gap-1">
                  {[task.listId, ...task.extraListIds].map((lid) => { const l = getList(s, lid); return l && <span key={lid} className="inline-flex items-center gap-1 rounded bg-zinc-100 px-1.5 py-0.5 text-[12px] dark:bg-zinc-800"><span className="h-1.5 w-1.5 rounded-full" style={{ background: l.color }} />{l.name}{lid === task.listId && <span className="text-[10px] text-zinc-400">(principal)</span>}</span> })}
                </div>
              </Prop>
            </div>

            <div className="mt-6">
              <RichEditor docKey={task.id} html={task.description} onBlur={(html) => html !== task.description && s.updateTask(task.id, { description: html })} placeholder="Adicione uma descrição, ou digite '/' para comandos" minHeight={60} />
            </div>

            {fields.length > 0 && (
              <Section title="Campos personalizados" icon={Hash} right={<button className="text-[12px] text-zinc-400 hover:text-accent" onClick={() => s.setModal({ type: 'fields', locType: 'list', locId: task.listId })}>Gerenciar</button>}>
                <div className="divide-y divide-zinc-100 rounded-lg border border-zinc-200 dark:divide-zinc-800 dark:border-zinc-800">
                  {fields.map((f) => (
                    <div key={f.id} className="flex items-center gap-3 px-3 py-1.5">
                      <div className="w-44 shrink-0 truncate text-zinc-500" title={f.description}>{f.name}{f.required && <span className="text-red-500"> *</span>}</div>
                      <div className="min-w-0 flex-1"><CFEditor task={task} field={f} /></div>
                    </div>
                  ))}
                </div>
              </Section>
            )}

            <Section title={`Subtarefas${subs.length ? ` (${subs.filter((x) => isClosed(s, x)).length}/${subs.length})` : ''}`} icon={CornerDownRight} right={prog && <div className="flex w-40 items-center gap-2"><ProgressBar pct={prog.pct} h={5} /><span className="text-[11px] text-zinc-400">{prog.pct}%</span></div>}>
              <div className="rounded-lg border border-zinc-200 p-1 dark:border-zinc-800">
                {subs.sort((a, b) => a.order - b.order).map((t) => <SubtaskRow key={t.id} t={t} />)}
                <input className="w-full rounded bg-transparent px-2 py-1.5 outline-none placeholder:text-zinc-400" placeholder="+ Adicionar subtarefa (Enter)" value={newSub} onChange={(e) => setNewSub(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && newSub.trim()) { s.createTask({ name: newSub, listId: task.listId, parentId: task.id }); setNewSub('') } }} />
              </div>
            </Section>

            <Section title="Checklists" icon={ListChecks} right={<button className="text-[12px] text-zinc-400 hover:text-accent" onClick={() => s.addChecklist(task.id)}>+ Checklist</button>}>
              {task.checklists.length ? <Checklists task={task} /> : <button className="text-zinc-400 hover:text-accent" onClick={() => s.addChecklist(task.id)}>+ Criar checklist</button>}
            </Section>

            <Section title="Relacionamentos e dependências" icon={Link2}><Relationships task={task} /></Section>
            <Section title={`Anexos${task.attachments.length ? ` (${task.attachments.length})` : ''}`} icon={Paperclip}><Attachments task={task} /></Section>
            <div className="h-10" />
          </div>
          {/* direita */}
          <div className="hidden w-[400px] shrink-0 border-l border-zinc-200 lg:block dark:border-zinc-800"><ActivityPanel task={task} /></div>
        </div>
      </div>
    </Modal>
  )
}
