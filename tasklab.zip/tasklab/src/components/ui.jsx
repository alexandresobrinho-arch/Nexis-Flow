import React, { useEffect, useLayoutEffect, useRef, useState, useId } from 'react'
import { createPortal } from 'react-dom'
import {
  Flag, X, Check, ChevronLeft, ChevronRight, Bot, Calendar as CalIcon, Search, Megaphone, Rocket, User, Layers, Briefcase,
  Code, Heart, Star, Zap, BookOpen, Folder, List, CircleDot, Diamond, Bug, Users, Target, Palette, Globe, Box,
} from 'lucide-react'
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, format, isSameMonth, isSameDay,
} from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { useStore } from '../store/store'
import { initials, PRIORITIES, PALETTE, dayStr, parseDay, cx } from '../lib/utils'
import { getStatusesForList, getMember } from '../lib/selectors'

export const ICONS = { Megaphone, Rocket, User, Layers, Briefcase, Code, Heart, Star, Zap, BookOpen, Folder, List, CircleDot, Diamond, Bug, Users, Target, Palette, Globe, Box }
export function Icon({ name, size = 14, className, style }) {
  const C = ICONS[name] || Layers
  return <C size={size} className={className} style={style} />
}

// ---------- camadas (popovers/modais) com fechamento correto em pilha ----------
const stack = []
function useLayer(open, onClose, ref, { outside = true } = {}) {
  const id = useId()
  const cb = useRef(onClose)
  cb.current = onClose
  useEffect(() => {
    if (!open) return
    stack.push(id)
    const isTop = () => stack[stack.length - 1] === id
    const key = (e) => { if (e.key === 'Escape' && isTop()) { e.stopPropagation(); cb.current() } }
    const down = (e) => {
      if (!outside || !isTop()) return
      if (ref?.current && ref.current.contains(e.target)) return
      if (e.target.closest?.('[data-layer-anchor="' + id + '"]')) return
      cb.current()
    }
    document.addEventListener('keydown', key, true)
    document.addEventListener('mousedown', down)
    return () => {
      const i = stack.indexOf(id)
      if (i >= 0) stack.splice(i, 1)
      document.removeEventListener('keydown', key, true)
      document.removeEventListener('mousedown', down)
    }
  }, [open])
  return id
}

export function Popover({ trigger, children, align = 'start', className = '', open: cOpen, onOpenChange, block = false, side = 'bottom' }) {
  const [inner, setInner] = useState(false)
  const open = cOpen ?? inner
  const setOpen = (v) => (onOpenChange ? onOpenChange(v) : setInner(v))
  const anchor = useRef(null)
  const pop = useRef(null)
  const [pos, setPos] = useState({ top: -9999, left: -9999 })
  const id = useLayer(open, () => setOpen(false), pop)
  useLayoutEffect(() => {
    if (!open || !anchor.current || !pop.current) return
    const place = () => {
      const r = anchor.current.getBoundingClientRect()
      const p = pop.current.getBoundingClientRect()
      let top = side === 'right' ? r.top : r.bottom + 4
      let left = side === 'right' ? r.right + 4 : align === 'end' ? r.right - p.width : r.left
      if (top + p.height > window.innerHeight - 8) top = Math.max(8, (side === 'right' ? r.bottom : r.top - 4) - p.height)
      left = Math.max(8, Math.min(left, window.innerWidth - p.width - 8))
      setPos({ top, left })
    }
    place()
    const ro = new ResizeObserver(place)
    ro.observe(pop.current)
    return () => ro.disconnect()
  }, [open])
  const close = () => setOpen(false)
  return (
    <>
      <span ref={anchor} data-layer-anchor={id} className={block ? 'block' : 'inline-flex max-w-full'} onClick={(e) => { e.stopPropagation(); setOpen(!open) }}>
        {typeof trigger === 'function' ? trigger(open) : trigger}
      </span>
      {open && createPortal(
        <div ref={pop} style={{ position: 'fixed', top: pos.top, left: pos.left, zIndex: 1000 }} onClick={(e) => e.stopPropagation()} className={className}>
          {typeof children === 'function' ? children(close) : children}
        </div>,
        document.body,
      )}
    </>
  )
}

export function Modal({ open, onClose, children, width = 560, className = '', bare = false }) {
  const ref = useRef(null)
  useLayer(open, onClose, ref, { outside: false })
  if (!open) return null
  return createPortal(
    <div className="fixed inset-0 z-[900] flex items-start justify-center overflow-y-auto bg-black/40 p-4 pt-[6vh] backdrop-blur-[1px]" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div ref={ref} style={{ maxWidth: width }} className={cx('w-full', bare ? '' : 'card shadow-2xl', className)}>{children}</div>
    </div>,
    document.body,
  )
}

export function ModalHeader({ title, onClose, children }) {
  return (
    <div className="flex items-center gap-2 border-b border-zinc-200 px-4 py-3 dark:border-zinc-800">
      <h3 className="flex-1 text-[15px] font-semibold">{title}</h3>
      {children}
      <button className="btn btn-ghost !p-1" onClick={onClose}><X size={16} /></button>
    </div>
  )
}

export function Avatar({ userId, size = 22, ring = false, title }) {
  const m = useStore((s) => getMember(s, userId))
  if (userId === 'automation') return <span title="Automação" className="inline-flex items-center justify-center rounded-full bg-zinc-700 text-white" style={{ width: size, height: size }}><Bot size={size * 0.6} /></span>
  if (!m) return <span className="inline-flex items-center justify-center rounded-full border border-dashed border-zinc-300 text-zinc-400" style={{ width: size, height: size }}><User size={size * 0.55} /></span>
  return (
    <span title={title ?? m.name} className={cx('inline-flex shrink-0 items-center justify-center rounded-full font-semibold text-white', ring && 'ring-2 ring-white dark:ring-zinc-900')} style={{ width: size, height: size, background: m.color, fontSize: size * 0.4 }}>
      {initials(m.name)}
    </span>
  )
}

export function AvatarStack({ ids = [], size = 22, max = 3 }) {
  if (!ids.length) return <Avatar userId={null} size={size} />
  return (
    <span className="inline-flex -space-x-1.5">
      {ids.slice(0, max).map((id) => <Avatar key={id} userId={id} size={size} ring />)}
      {ids.length > max && <span className="inline-flex items-center justify-center rounded-full bg-zinc-200 text-[10px] font-semibold ring-2 ring-white dark:bg-zinc-700 dark:ring-zinc-900" style={{ width: size, height: size }}>+{ids.length - max}</span>}
    </span>
  )
}

export function StatusBadge({ status, small }) {
  if (!status) return null
  return (
    <span className={cx('inline-flex items-center gap-1 whitespace-nowrap rounded font-semibold uppercase text-white', small ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-[11px]')} style={{ background: status.color }}>
      {status.type === 'closed' || status.type === 'done' ? <Check size={11} /> : null}{status.name}
    </span>
  )
}
export function StatusDot({ status, size = 10 }) {
  if (!status) return null
  const done = status.type === 'done' || status.type === 'closed'
  return (
    <span className="inline-flex shrink-0 items-center justify-center rounded-full" style={{ width: size + 4, height: size + 4, border: `2px solid ${status.color}`, background: done ? status.color : 'transparent' }}>
      {done && <Check size={size - 2} className="text-white" strokeWidth={3} />}
    </span>
  )
}

export function PriorityFlag({ p, label = false, size = 14 }) {
  if (!p) return <span className="inline-flex items-center gap-1 text-zinc-300 dark:text-zinc-600"><Flag size={size} />{label && <span className="text-zinc-400">—</span>}</span>
  const pr = PRIORITIES[p]
  return <span className="inline-flex items-center gap-1" style={{ color: pr.color }}><Flag size={size} fill={pr.color} />{label && <span className="text-zinc-600 dark:text-zinc-300">{pr.label}</span>}</span>
}

export function TagChip({ name, onRemove }) {
  const color = useStore((s) => s.tags.find((t) => t.name === name)?.color || '#a1a1aa')
  return (
    <span className="inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-medium" style={{ background: color + '22', color }}>
      {name}
      {onRemove && <X size={10} className="cursor-pointer" onClick={(e) => { e.stopPropagation(); onRemove() }} />}
    </span>
  )
}

export function Toggle({ checked, onChange, small }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className={cx('relative inline-flex shrink-0 rounded-full transition-colors', small ? 'h-4 w-7' : 'h-5 w-9', checked ? 'bg-accent' : 'bg-zinc-300 dark:bg-zinc-700')}>
      <span className={cx('absolute top-0.5 rounded-full bg-white shadow transition-all', small ? 'h-3 w-3' : 'h-4 w-4', checked ? (small ? 'left-3.5' : 'left-[18px]') : 'left-0.5')} />
    </button>
  )
}

export function ColorPicker({ value, onChange }) {
  return (
    <div className="grid grid-cols-6 gap-1.5 p-2">
      {PALETTE.map((c) => (
        <button key={c} onClick={() => onChange(c)} className="flex h-6 w-6 items-center justify-center rounded-full" style={{ background: c }}>
          {value === c && <Check size={12} className="text-white" />}
        </button>
      ))}
    </div>
  )
}

export function SearchInput({ value, onChange, placeholder = 'Buscar...', autoFocus }) {
  return (
    <div className="relative">
      <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-zinc-400" />
      <input autoFocus={autoFocus} className="input !pl-7" value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  )
}

// ---------- pickers ----------
export function UserPickerMenu({ value = [], onChange, multiple = true, close }) {
  const members = useStore((s) => s.members)
  const me = useStore((s) => s.currentUserId)
  const [q, setQ] = useState('')
  const list = members.filter((m) => m.name.toLowerCase().includes(q.toLowerCase())).sort((a, b) => (b.id === me) - (a.id === me))
  return (
    <div className="menu w-64">
      <div className="p-1"><SearchInput value={q} onChange={setQ} autoFocus placeholder="Buscar pessoas" /></div>
      <div className="max-h-64 overflow-y-auto">
        {list.map((m) => {
          const on = value.includes(m.id)
          return (
            <button key={m.id} className="menu-item" onClick={() => {
              if (multiple) onChange(on ? value.filter((x) => x !== m.id) : [...value, m.id])
              else { onChange(on ? [] : [m.id]); close?.() }
            }}>
              <Avatar userId={m.id} size={20} />
              <span className="flex-1 truncate">{m.name}{m.id === me && <span className="text-zinc-400"> (eu)</span>}</span>
              {on && <Check size={14} className="text-accent" />}
            </button>
          )
        })}
      </div>
      {value.length > 0 && <button className="menu-item text-red-500" onClick={() => { onChange([]); close?.() }}><X size={14} />Remover todos</button>}
    </div>
  )
}

export function StatusMenu({ listId, statuses: given, value, onChange, close }) {
  const statuses = useStore((s) => given || getStatusesForList(s, listId))
  const groups = [['notstarted', 'Não iniciado'], ['active', 'Ativo'], ['done', 'Concluído'], ['closed', 'Fechado']]
  return (
    <div className="menu w-56">
      {groups.map(([type, label]) => {
        const items = statuses.filter((x) => x.type === type)
        if (!items.length) return null
        return (
          <div key={type}>
            <div className="label px-2 pb-0.5 pt-1.5">{label}</div>
            {items.map((st) => (
              <button key={st.id} className="menu-item" onClick={() => { onChange(st.id); close?.() }}>
                <StatusDot status={st} />
                <span className="flex-1 font-medium uppercase">{st.name}</span>
                {value === st.id && <Check size={14} className="text-accent" />}
              </button>
            ))}
          </div>
        )
      })}
    </div>
  )
}

export function PriorityMenu({ value, onChange, close }) {
  return (
    <div className="menu w-44">
      {[1, 2, 3, 4].map((p) => (
        <button key={p} className="menu-item" onClick={() => { onChange(p); close?.() }}>
          <PriorityFlag p={p} label />
          {value === p && <Check size={14} className="ml-auto text-accent" />}
        </button>
      ))}
      <button className="menu-item text-zinc-500" onClick={() => { onChange(null); close?.() }}><X size={14} />Limpar</button>
    </div>
  )
}

export function TagMenu({ value = [], onChange }) {
  const tags = useStore((s) => s.tags)
  const [q, setQ] = useState('')
  const list = tags.filter((t) => t.name.includes(q.toLowerCase()))
  const exists = tags.some((t) => t.name === q.trim().toLowerCase())
  return (
    <div className="menu w-60">
      <div className="p-1">
        <input autoFocus className="input" placeholder="Buscar ou criar tag" value={q} onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && q.trim()) { const n = q.trim().toLowerCase(); if (!value.includes(n)) onChange([...value, n]); setQ('') } }} />
      </div>
      <div className="max-h-60 overflow-y-auto">
        {list.map((t) => {
          const on = value.includes(t.name)
          return (
            <button key={t.name} className="menu-item" onClick={() => onChange(on ? value.filter((x) => x !== t.name) : [...value, t.name])}>
              <TagChip name={t.name} />
              {on && <Check size={14} className="ml-auto text-accent" />}
            </button>
          )
        })}
        {q.trim() && !exists && <button className="menu-item text-accent" onClick={() => { onChange([...value, q.trim().toLowerCase()]); setQ('') }}>+ Criar tag "{q.trim().toLowerCase()}"</button>}
      </div>
    </div>
  )
}

export function DatePickerMenu({ value, onChange, close, allowClear = true }) {
  const [month, setMonth] = useState(parseDay(value) || new Date())
  const start = startOfWeek(startOfMonth(month), { weekStartsOn: 0 })
  const end = endOfWeek(endOfMonth(month), { weekStartsOn: 0 })
  const days = []
  for (let d = start; d <= end; d = addDays(d, 1)) days.push(d)
  const pick = (d) => { onChange(d ? dayStr(d) : null); close?.() }
  const quick = [
    ['Hoje', 0], ['Amanhã', 1], ['Fim de semana', (6 - new Date().getDay() + 7) % 7 || 7], ['Próxima semana', 7], ['Em 2 semanas', 14], ['Em 1 mês', 30],
  ]
  return (
    <div className="menu flex w-[430px] p-0">
      <div className="w-36 border-r border-zinc-200 p-1 dark:border-zinc-800">
        {quick.map(([l, n]) => (
          <button key={l} className="menu-item justify-between" onClick={() => pick(addDays(new Date(), n))}>
            <span>{l}</span><span className="text-[11px] text-zinc-400">{format(addDays(new Date(), n), 'EEE', { locale: ptBR })}</span>
          </button>
        ))}
        {allowClear && value && <button className="menu-item text-red-500" onClick={() => pick(null)}><X size={13} />Remover data</button>}
      </div>
      <div className="flex-1 p-2">
        <div className="mb-1 flex items-center justify-between">
          <span className="font-semibold capitalize">{format(month, 'MMMM yyyy', { locale: ptBR })}</span>
          <div className="flex">
            <button className="btn btn-ghost !p-1" onClick={() => setMonth(addMonths(month, -1))}><ChevronLeft size={14} /></button>
            <button className="btn btn-ghost !p-1" onClick={() => setMonth(addMonths(month, 1))}><ChevronRight size={14} /></button>
          </div>
        </div>
        <div className="grid grid-cols-7 text-center text-[11px] text-zinc-400">{['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((x, i) => <div key={i}>{x}</div>)}</div>
        <div className="grid grid-cols-7 text-center">
          {days.map((d) => {
            const sel = value && isSameDay(d, parseDay(value))
            const today = isSameDay(d, new Date())
            return (
              <button key={d.toISOString()} onClick={() => pick(d)} className={cx('m-0.5 h-7 rounded-md text-[12px] hover:bg-zinc-100 dark:hover:bg-zinc-800', !isSameMonth(d, month) && 'text-zinc-300 dark:text-zinc-600', today && 'font-bold text-accent', sel && '!bg-accent !text-white')}>
                {format(d, 'd')}
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export function DateButton({ value, onChange, placeholder, className = '', tone }) {
  return (
    <Popover trigger={
      <button className={cx('inline-flex items-center gap-1 rounded px-1 py-0.5 hover:bg-zinc-100 dark:hover:bg-zinc-800', tone, className)}>
        {value ? format(parseDay(value), 'd MMM', { locale: ptBR }) : <span className="flex items-center gap-1 text-zinc-300 dark:text-zinc-600"><CalIcon size={13} />{placeholder}</span>}
      </button>
    }>
      {(close) => <DatePickerMenu value={value} onChange={onChange} close={close} />}
    </Popover>
  )
}

export function Empty({ icon: I = Box, title, text, children }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center text-zinc-500">
      <I size={36} className="mb-3 text-zinc-300 dark:text-zinc-600" />
      <div className="font-semibold text-zinc-700 dark:text-zinc-200">{title}</div>
      {text && <div className="mt-1 max-w-sm">{text}</div>}
      {children && <div className="mt-4">{children}</div>}
    </div>
  )
}

export function InlineEdit({ value, onSave, className = '', placeholder, multiline = false, autoFocus = false }) {
  const [v, setV] = useState(value)
  const [editing, setEditing] = useState(autoFocus)
  useEffect(() => setV(value), [value])
  if (!editing) return <span className={cx('cursor-text', className, !value && 'text-zinc-400')} onClick={(e) => { e.stopPropagation(); setEditing(true) }}>{value || placeholder}</span>
  const commit = () => { setEditing(false); if (v.trim() && v !== value) onSave(v.trim()); else setV(value) }
  const Tag = multiline ? 'textarea' : 'input'
  return <Tag autoFocus className={cx('w-full rounded bg-transparent outline-none ring-2 ring-accent/30', className)} value={v} onChange={(e) => setV(e.target.value)} onBlur={commit} onClick={(e) => e.stopPropagation()}
    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); commit() } if (e.key === 'Escape') { setV(value); setEditing(false) } }} />
}

export function Confirm({ open, title, text, onConfirm, onClose, danger = true, label = 'Excluir' }) {
  return (
    <Modal open={open} onClose={onClose} width={400}>
      <div className="p-5">
        <div className="text-[15px] font-semibold">{title}</div>
        {text && <div className="mt-1 text-zinc-500">{text}</div>}
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn btn-outline" onClick={onClose}>Cancelar</button>
          <button className={cx('btn', danger ? 'btn-danger' : 'btn-primary')} onClick={() => { onConfirm(); onClose() }}>{label}</button>
        </div>
      </div>
    </Modal>
  )
}

export function Tabs({ tabs, value, onChange }) {
  return (
    <div className="flex gap-1 border-b border-zinc-200 dark:border-zinc-800">
      {tabs.map(([k, l, count]) => (
        <button key={k} onClick={() => onChange(k)} className={cx('-mb-px border-b-2 px-3 py-2 font-medium', value === k ? 'border-accent text-accent' : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200')}>
          {l}{count ? <span className="ml-1.5 rounded-full bg-zinc-100 px-1.5 text-[11px] dark:bg-zinc-800">{count}</span> : null}
        </button>
      ))}
    </div>
  )
}

export function ProgressBar({ pct, color = '#10b981', h = 6 }) {
  return (
    <div className="w-full overflow-hidden rounded-full bg-zinc-200 dark:bg-zinc-800" style={{ height: h }}>
      <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(100, Math.max(0, pct))}%`, background: color }} />
    </div>
  )
}
