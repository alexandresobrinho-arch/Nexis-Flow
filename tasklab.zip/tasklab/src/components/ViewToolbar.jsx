import React, { useState } from 'react'
import { Filter, Layers, ArrowUpDown, CornerDownRight, Eye, EyeOff, User, Columns3, Plus, X, Check, ChevronDown, Trash2 } from 'lucide-react'
import { useStore } from '../store/store'
import { Popover, Avatar, StatusDot, PriorityFlag, TagChip, Toggle } from './ui'
import { filterFields, OPS, NO_VALUE_OPS, groupOptions, SORT_FIELDS } from '../lib/query'
import { getStatusesForLocation, getFieldsForLocation, listsInLocation } from '../lib/selectors'
import { PRIORITIES, STATUS_TYPES, cx, uid } from '../lib/utils'

function MultiValue({ options, value = [], onChange, render }) {
  return (
    <Popover trigger={
      <button className="input flex min-h-[32px] items-center gap-1 text-left">
        <span className="flex flex-1 flex-wrap gap-1">{value.length ? value.map((v) => <span key={v}>{render ? render(v) : options.find((o) => o[0] === v)?.[1] || v}</span>) : <span className="text-zinc-400">Selecionar…</span>}</span>
        <ChevronDown size={13} className="text-zinc-400" />
      </button>
    }>
      <div className="menu max-h-72 w-60 overflow-y-auto">
        {options.map(([k, l, node]) => {
          const on = value.includes(k)
          return <button key={k} className="menu-item" onClick={() => onChange(on ? value.filter((x) => x !== k) : [...value, k])}>{node || l}{on && <Check size={13} className="ml-auto text-accent" />}</button>
        })}
      </div>
    </Popover>
  )
}

function ValueInput({ field, rule, onChange, locType, locId }) {
  const s = useStore()
  if (!field || NO_VALUE_OPS.includes(rule.op)) return <div className="flex-1" />
  const v = rule.value
  switch (field.kind) {
    case 'status': {
      const sts = getStatusesForLocation(s, locType, locId)
      return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={sts.map((x) => [x.name, x.name, <span className="flex items-center gap-2"><StatusDot status={x} size={8} />{x.name}</span>])} /></div>
    }
    case 'statusType': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={Object.entries(STATUS_TYPES)} /></div>
    case 'people': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={[['me', 'Eu (usuário atual)'], ...s.members.map((m) => [m.id, m.name, <span className="flex items-center gap-2"><Avatar userId={m.id} size={18} />{m.name}</span>])]} render={(id) => id === 'me' ? 'Eu' : <Avatar userId={id} size={18} />} /></div>
    case 'priority': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={[...[1, 2, 3, 4].map((p) => [String(p), PRIORITIES[p].label, <PriorityFlag p={p} label />]), ['none', 'Sem prioridade']]} /></div>
    case 'tags': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={s.tags.map((t) => [t.name, t.name, <TagChip name={t.name} />])} render={(n) => <TagChip name={n} />} /></div>
    case 'list': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={listsInLocation(s, locType, locId).map((l) => [l.id, l.name])} /></div>
    case 'type': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={s.taskTypes.map((t) => [t.id, t.name])} /></div>
    case 'select':
    case 'labels': return <div className="flex-1"><MultiValue value={v} onChange={onChange} options={(field.field.config.options || []).map((o) => [o.id, o.name, <span className="rounded px-1.5 text-white" style={{ background: o.color }}>{o.name}</span>])} /></div>
    case 'date': return <input type="date" className="input flex-1" value={v || ''} onChange={(e) => onChange(e.target.value)} />
    case 'number': return <input type="number" className="input flex-1" value={v ?? ''} onChange={(e) => onChange(e.target.value)} />
    default: return <input className="input flex-1" value={v || ''} onChange={(e) => onChange(e.target.value)} placeholder="Valor" />
  }
}

export function FilterBuilder({ config, update, locType, locId }) {
  const s = useStore()
  const fields = filterFields(s, locType, locId)
  const f = config.filters || { match: 'and', rules: [] }
  const setRules = (rules) => update({ filters: { ...f, rules } })
  const addRule = () => setRules([...f.rules, { id: uid('fr'), field: 'status', op: 'is', value: [] }])
  return (
    <div className="menu w-[640px] p-3">
      <div className="mb-2 flex items-center gap-2">
        <span className="font-semibold">Filtros</span>
        {f.rules.length > 1 && (
          <select className="input !w-auto !py-0.5" value={f.match} onChange={(e) => update({ filters: { ...f, match: e.target.value } })}>
            <option value="and">Todas as condições (E)</option><option value="or">Qualquer condição (OU)</option>
          </select>
        )}
        <div className="flex-1" />
        {f.rules.length > 0 && <button className="text-[12px] text-zinc-400 hover:text-red-500" onClick={() => setRules([])}>Limpar tudo</button>}
      </div>
      <div className="space-y-2">
        {f.rules.map((r, i) => {
          const fd = fields.find((x) => x.key === r.field)
          const ops = OPS[fd?.kind] || OPS.text
          return (
            <div key={r.id || i} className="flex items-start gap-2">
              <span className="w-10 pt-1.5 text-right text-[11px] text-zinc-400">{i === 0 ? 'Onde' : f.match === 'or' ? 'ou' : 'e'}</span>
              <select className="input !w-44" value={r.field} onChange={(e) => { const nf = fields.find((x) => x.key === e.target.value); setRules(f.rules.map((x, j) => (j === i ? { ...x, field: e.target.value, op: (OPS[nf.kind] || OPS.text)[0][0], value: undefined } : x))) }}>
                <optgroup label="Campos">{fields.filter((x) => !x.key.startsWith('cf:')).map((x) => <option key={x.key} value={x.key}>{x.label}</option>)}</optgroup>
                {fields.some((x) => x.key.startsWith('cf:')) && <optgroup label="Campos personalizados">{fields.filter((x) => x.key.startsWith('cf:')).map((x) => <option key={x.key} value={x.key}>{x.label}</option>)}</optgroup>}
              </select>
              <select className="input !w-40" value={r.op} onChange={(e) => setRules(f.rules.map((x, j) => (j === i ? { ...x, op: e.target.value } : x)))}>
                {ops.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
              <ValueInput field={fd} rule={r} locType={locType} locId={locId} onChange={(value) => setRules(f.rules.map((x, j) => (j === i ? { ...x, value } : x)))} />
              <button className="btn btn-ghost !p-1.5" onClick={() => setRules(f.rules.filter((_, j) => j !== i))}><Trash2 size={14} /></button>
            </div>
          )
        })}
      </div>
      <button className="btn btn-ghost mt-2 text-accent" onClick={addRule}><Plus size={14} />Adicionar filtro</button>
    </div>
  )
}

export default function ViewToolbar({ view, config, update, locType, locId, search, setSearch, extra }) {
  const s = useStore()
  const nFilters = (config.filters?.rules || []).length
  const groups = groupOptions(s, locType, locId)
  const supportsGroup = ['list', 'board', 'table', 'timeline'].includes(view.type)
  const supportsCols = ['list', 'table'].includes(view.type)
  const cfs = getFieldsForLocation(s, locType, locId)
  const columns = [
    ['status', 'Status'], ['assignee', 'Responsáveis'], ['dueDate', 'Entrega'], ['startDate', 'Início'], ['priority', 'Prioridade'], ['tags', 'Tags'],
    ['timeEstimate', 'Estimativa'], ['timeTracked', 'Tempo rastreado'], ['points', 'Sprint points'], ['progress', 'Progresso'], ['list', 'Lista'],
    ['createdAt', 'Criada em'], ['updatedAt', 'Atualizada em'], ['createdBy', 'Criado por'], ['type', 'Tipo'], ['dependencies', 'Dependências'],
    ...cfs.map((f) => [`cf:${f.id}`, f.name]),
  ]
  const Btn = ({ icon: I, label, active, ...p }) => <button {...p} className={cx('btn !py-1', active ? 'bg-accent-50 text-accent dark:bg-accent/15' : 'btn-ghost')}><I size={14} />{label}</button>
  if (view.type === 'form') return null
  return (
    <div className="flex flex-wrap items-center gap-1 border-b border-zinc-200 px-4 py-1.5 dark:border-zinc-800">
      <input className="input !w-48 !py-1" placeholder="Buscar nesta view…" value={search} onChange={(e) => setSearch(e.target.value)} />
      <Popover trigger={<span><Btn icon={Filter} label={nFilters ? `Filtros · ${nFilters}` : 'Filtro'} active={nFilters > 0} /></span>}>
        <FilterBuilder config={config} update={update} locType={locType} locId={locId} />
      </Popover>
      {supportsGroup && (
        <Popover trigger={<span><Btn icon={Layers} label={`Agrupar: ${groups.find((g) => g[0] === config.groupBy)?.[1] || 'Status'}`} /></span>}>
          {(close) => (
            <div className="menu w-56">
              {groups.map(([k, l]) => <button key={k} className="menu-item" onClick={() => { update({ groupBy: k }); close() }}>{l}{config.groupBy === k && <Check size={13} className="ml-auto text-accent" />}</button>)}
            </div>
          )}
        </Popover>
      )}
      {['list', 'board', 'table', 'timeline', 'gantt'].includes(view.type) && (
        <Popover trigger={<span><Btn icon={ArrowUpDown} label={config.sorts?.length ? `Ordenar · ${config.sorts.length}` : 'Ordenar'} active={config.sorts?.length > 0} /></span>}>
          <div className="menu w-80 p-2">
            <div className="mb-2 font-semibold">Ordenação</div>
            {(config.sorts || []).map((so, i) => (
              <div key={i} className="mb-1 flex gap-1">
                <select className="input" value={so.key} onChange={(e) => update({ sorts: config.sorts.map((x, j) => (j === i ? { ...x, key: e.target.value } : x)) })}>
                  {[...SORT_FIELDS, ...cfs.filter((f) => ['number', 'money', 'date', 'rating', 'text', 'formula'].includes(f.type)).map((f) => [`cf:${f.id}`, f.name])].map(([k, l]) => <option key={k} value={k}>{l}</option>)}
                </select>
                <select className="input !w-24" value={so.dir} onChange={(e) => update({ sorts: config.sorts.map((x, j) => (j === i ? { ...x, dir: e.target.value } : x)) })}><option value="asc">Asc</option><option value="desc">Desc</option></select>
                <button className="btn btn-ghost !p-1" onClick={() => update({ sorts: config.sorts.filter((_, j) => j !== i) })}><X size={14} /></button>
              </div>
            ))}
            <button className="btn btn-ghost text-accent" onClick={() => update({ sorts: [...(config.sorts || []), { key: 'dueDate', dir: 'asc' }] })}><Plus size={14} />Adicionar ordenação</button>
          </div>
        </Popover>
      )}
      {['list', 'board', 'table'].includes(view.type) && (
        <Popover trigger={<span><Btn icon={CornerDownRight} label={{ collapsed: 'Subtarefas: recolhidas', expanded: 'Subtarefas: expandidas', separate: 'Subtarefas: separadas' }[config.subtasks]} /></span>}>
          {(close) => (
            <div className="menu w-64">
              {[['collapsed', 'Recolhidas', 'Mostra contagem; expanda por tarefa'], ['expanded', 'Expandidas', 'Aninhadas abaixo da tarefa pai'], ['separate', 'Como tarefas separadas', 'Cada subtarefa vira uma linha']].map(([k, l, d]) => (
                <button key={k} className="menu-item !items-start" onClick={() => { update({ subtasks: k }); close() }}>
                  <div><div>{l}</div><div className="text-[11px] text-zinc-400">{d}</div></div>{config.subtasks === k && <Check size={13} className="ml-auto text-accent" />}
                </button>
              ))}
            </div>
          )}
        </Popover>
      )}
      <Btn icon={config.showClosed ? Eye : EyeOff} label={config.showClosed ? 'Fechadas visíveis' : 'Fechadas ocultas'} active={config.showClosed} onClick={() => update({ showClosed: !config.showClosed })} />
      <Btn icon={User} label="Eu" active={config.me} onClick={() => update({ me: !config.me })} />
      {supportsCols && (
        <Popover align="end" trigger={<span><Btn icon={Columns3} label="Colunas" /></span>}>
          <div className="menu max-h-96 w-64 overflow-y-auto">
            <div className="label px-2 py-1">Mostrar colunas</div>
            {columns.map(([k, l]) => {
              const on = (config.columns || []).includes(k)
              return (
                <label key={k} className="menu-item cursor-pointer">
                  <span className="flex-1">{l}</span>
                  <Toggle small checked={on} onChange={() => update({ columns: on ? config.columns.filter((x) => x !== k) : [...(config.columns || []), k] })} />
                </label>
              )
            })}
            <button className="menu-item text-accent" onClick={() => s.setModal({ type: 'fields', locType: locType === 'everything' ? 'space' : locType, locId: locType === 'everything' ? s.spaces[0]?.id : locId })}><Plus size={13} />Novo campo personalizado</button>
          </div>
        </Popover>
      )}
      <div className="flex-1" />
      {extra}
    </div>
  )
}
